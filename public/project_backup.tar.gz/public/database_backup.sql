-- Nabkul Cooperative Society - MySQL Database Backup
-- Generated for offline use

CREATE DATABASE IF NOT EXISTS nabkul_pos;
USE nabkul_pos;

-- Products Table
DROP TABLE IF EXISTS products;
CREATE TABLE products (
  id INT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  category VARCHAR(100),
  barcode VARCHAR(50),
  unit VARCHAR(20),
  sellingPrice DECIMAL(10,2),
  costPrice DECIMAL(10,2),
  stock DECIMAL(10,2),
  minStockLevel DECIMAL(10,2),
  batchNo VARCHAR(50),
  expiryDate DATE,
  image VARCHAR(255),
  description TEXT,
  featured BOOLEAN DEFAULT FALSE
);

-- Seed Products
INSERT INTO products (id, name, category, barcode, unit, sellingPrice, costPrice, stock, minStockLevel, batchNo, expiryDate, image, description, featured) VALUES
(101, 'Basmati Rice (Premium)', 'Grains & Staples', '890100100101', 'KG', 100, 84, 135.5, 30, 'B-RICE-26A', '2027-06-30', '/Piem Img/basmati_rice.jpg', 'Aromatic extra long grain premium Basmati Rice directly sourced from cooperative mill.', 1),
(102, 'Sona Masoori Rice (Boiled)', 'Grains & Staples', '890100100102', 'KG', 62, 52, 210, 50, 'B-SONA-26B', '2027-08-15', '/Piem Img/sona_masoori_rice.jpg', 'Lightweight, healthy daily boiled rice favorite across Bengal households.', 0),
(103, 'Sharbati Wheat Flour (Atta)', 'Grains & Staples', '890100200201', 'KG', 45, 38, 75, 25, 'B-ATTA-26C', '2027-03-31', '/Piem Img/wheat_flour.jpg', '100% stone-ground Sharbati whole wheat chakki fresh atta for soft rotis.', 1),
(104, 'Refined Sugar (S-30 Grade)', 'Grocery & Essentials', '890100300301', 'KG', 44, 39.5, 94, 20, 'B-SUG-26D', '2027-12-31', '/Piem Img/refined_sugar.jpg', 'Sparkling white sulfurless refined sugar crystals from cooperative sugar federation.', 0),
(105, 'Sunflower Oil 1L Pouch', 'Edible Oils', '890100400401', 'PKT', 130, 114, 32, 15, 'B-OIL-SUN26', '2027-05-20', '/Piem Img/sunflower_oil.jpg', 'Refined light sunflower cooking oil fortified with Vitamin A & D.', 1),
(106, 'Mustard Oil 1L Bottle (Kachi Ghani)', 'Edible Oils', '890100400402', 'LTR', 160, 138, 47, 15, 'B-OIL-MUST26', '2027-07-10', '/Piem Img/mustard_oil.jpg', 'Cold pressed pungent pure Mustard oil ideal for traditional Kolkata fish and curries.', 1),
(107, 'Parle-G Biscuit 100g', 'Snacks & Biscuits', '890100500501', 'PCS', 10, 8.5, 145, 40, 'B-SNK-PARLE', '2027-04-18', '/Piem Img/parle_g_biscuit.jpg', 'India’s favorite glucose biscuit for morning chai.', 0),
(108, 'Chana Dal (Desi Polished)', 'Pulses & Dal', '890100600601', 'KG', 88, 74, 65, 20, 'B-DAL-CHANA26', '2027-09-30', '/Piem Img/chana_dal.jpg', 'High protein unpolished Bengal gram dal for luchi and cholar dal recipes.', 0),
(109, 'Tata Iodised Salt 1kg', 'Grocery & Essentials', '890100700701', 'PKT', 28, 24, 110, 30, 'B-SALT-TATA', '2028-01-01', '/Piem Img/tata_salt.jpg', 'Desh Ka Namak vacuum evaporated iodised salt.', 0),
(110, 'Darjeeling Tea (Leaf Blend) 250g', 'Tea & Beverages', '890100800801', 'PKT', 145, 118, 42, 12, 'B-TEA-DARJ26', '2027-11-20', '/Piem Img/darjeeling_tea.jpg', 'Selected fragrant high-grown Darjeeling orthodox leaf blend.', 1),
(111, 'Pure Cow Ghee 500ml', 'Dairy & Ghee', '890100900901', 'JAR', 320, 275, 24, 8, 'B-GHEE-COW26', '2027-08-30', '/Piem Img/pure_cow_ghee.jpg', 'Traditional granular aromatic pure cow clarified butter.', 0),
(112, 'Turmeric Powder (Haldi) 200g', 'Spices & Masala', '890101001001', 'PKT', 52, 42, 60, 15, 'B-SPICE-HLD26', '2027-10-15', '/Piem Img/turmeric_powder.jpg', 'High-curcumin golden yellow pure turmeric ground hygienically.', 0);

-- Cashiers Table
DROP TABLE IF EXISTS cashiers;
CREATE TABLE cashiers (
  id VARCHAR(50) PRIMARY KEY,
  loginId VARCHAR(50) UNIQUE NOT NULL,
  passwordHash VARCHAR(255) NOT NULL,
  name VARCHAR(255) NOT NULL,
  staffCode VARCHAR(50),
  role VARCHAR(50),
  assignedCounter VARCHAR(100),
  isActive BOOLEAN DEFAULT TRUE,
  createdAt DATE
);

-- Seed Cashiers
INSERT INTO cashiers (id, loginId, passwordHash, name, staffCode, role, assignedCounter, isActive, createdAt) VALUES
('admin-001', 'admin', 'admin@nabkul', 'Society Administrator', 'ADMIN #01', 'System Admin', 'ADMIN DESK (CENTRAL)', 1, '2026-10-25'),
('cashier-402', 'subrata', 'nabkul@123', 'Subrata Roy', 'Staff #402', 'Senior Cashier', 'COUNTER-01 (KOL-NORTH)', 1, '2026-10-26'),
('cashier-405', 'priya', 'nabkul@123', 'Priya Ghosh', 'Staff #405', 'POS Cashier', 'COUNTER-02 (KOL-NORTH)', 1, '2026-10-27'),
('cashier-101', 'manager', 'admin@nabkul', 'Bimalendu Sarkar', 'Staff #101', 'Society Manager', 'CENTRAL DESK', 1, '2026-10-25');

-- Transactions Table
DROP TABLE IF EXISTS sale_transactions;
CREATE TABLE sale_transactions (
  saleItemId INT PRIMARY KEY,
  saleId INT,
  invoiceNo VARCHAR(50),
  saleDate DATETIME,
  customerName VARCHAR(255),
  paymentMode VARCHAR(20),
  productId INT,
  productName VARCHAR(255),
  barcode VARCHAR(50),
  quantity DECIMAL(10,2),
  unitType VARCHAR(20),
  sellingPrice DECIMAL(10,2),
  lineTotal DECIMAL(10,2),
  cashierName VARCHAR(255)
);

-- Seed Transactions
INSERT INTO sale_transactions (saleItemId, saleId, invoiceNo, saleDate, customerName, paymentMode, productId, productName, barcode, quantity, unitType, sellingPrice, lineTotal, cashierName) VALUES
(9001, 8001, 'POS-2026-0001', '2026-10-28 09:15', 'Ramesh Sharma', 'CASH', 101, 'Basmati Rice (Premium)', '890100100101', 5.5, 'KG', 100, 550, 'Subrata Roy'),
(9002, 8001, 'POS-2026-0001', '2026-10-28 09:15', 'Ramesh Sharma', 'CASH', 104, 'Refined Sugar', '890100300301', 2, 'KG', 44, 88, 'Subrata Roy'),
(9004, 8002, 'POS-2026-0002', '2026-10-28 10:45', 'Walk-in Customer', 'UPI', 105, 'Sunflower Oil 1L Pouch', '890100400401', 2, 'PKT', 130, 260, 'Priya Ghosh'),
(9006, 8003, 'POS-2026-0003', '2026-10-29 16:30', 'Amitabh Joshi', 'CASH', 106, 'Mustard Oil 1L Bottle', '890100400402', 1, 'LTR', 160, 160, 'Subrata Roy'),
(9007, 8004, 'POS-2026-0004', '2026-10-30 11:20', 'Sujata Sen', 'UPI', 110, 'Darjeeling Tea 250g', '890100800801', 1, 'PKT', 145, 145, 'Subrata Roy'),
(9008, 8005, 'POS-2026-0005', '2026-10-31 14:15', 'Pradip Das', 'CASH', 111, 'Pure Cow Ghee 500ml', '890100900901', 1, 'JAR', 320, 320, 'Priya Ghosh'),
(9009, 8006, 'POS-2026-0006', '2026-11-01 10:05', 'Tapan Kumar', 'CASH', 102, 'Sona Masoori Rice (Boiled)', '890100100102', 10, 'KG', 62, 620, 'Subrata Roy'),
(9010, 8006, 'POS-2026-0006', '2026-11-01 10:05', 'Tapan Kumar', 'CASH', 112, 'Turmeric Powder 200g', '890101001001', 2, 'PKT', 52, 104, 'Subrata Roy');
