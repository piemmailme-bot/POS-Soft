export type PaymentMode = 'UPI' | 'CASH';

export type UnitType = 'KG' | 'GM' | 'LTR' | 'ML' | 'PKT' | 'PCS' | 'JAR';

export interface Product {
  id: number;
  name: string;
  category: string;
  barcode: string;
  unit: UnitType;
  sellingPrice: number;
  costPrice: number;
  stock: number;
  minStockLevel: number;
  batchNo: string;
  expiryDate?: string;
  image: string;
  description?: string;
  featured?: boolean;
}

export interface LoosePacket {
  id: string; // e.g. "pack-1710000000"
  productId: number;
  productName: string;
  baseBarcode: string;
  uniqueBarcode: string; // Guaranteed unique barcode e.g. "890100100101-250G-1001"
  measuredGramsOrMl: number;
  weightText: string; // e.g. "250 GM" or "500 ML"
  quantityInBaseUnit: number; // e.g. 0.25
  unitPrice: number; // rate e.g. 100
  calculatedPrice: number; // e.g. 25.00
  unit: UnitType;
  createdAt: string;
  status: 'UNSOLD' | 'SOLD';
  soldAtInvoiceNo?: string;
  soldDate?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  sellingPrice: number;
  lineTotal: number;
  packetBarcode?: string; // If this cart item is from a measured loose packet
}

export interface SaleTransactionItem {
  saleItemId: number;
  saleId: number;
  invoiceNo: string;
  saleDate: string;
  customerName: string; // e.g. "Ramesh Sharma" or "Walk-in Customer"
  paymentMode: PaymentMode;
  productId: number;
  productName: string;
  barcode: string;
  quantity: number;
  unitType: UnitType;
  sellingPrice: number;
  lineTotal: number;
  cashierName?: string;
}

export interface CompleteInvoice {
  saleId: number;
  invoiceNo: string;
  saleDate: string;
  customerName: string;
  customerPhone?: string;
  paymentMode: PaymentMode;
  items: {
    productId: number;
    productName: string;
    barcode: string;
    quantity: number;
    unitType: UnitType;
    sellingPrice: number;
    lineTotal: number;
  }[];
  subtotal: number;
  discount: number;
  grandTotal: number;
  tenderedCash?: number;
  changeDue?: number;
  upiTxnRef?: string;
  cashier: string;
}

export interface SocietyProfile {
  name: string;
  address: string;
  phone: string;
  email: string;
  regNo: string;
  upiId: string;
  merchantName?: string;
  qrImage?: string;
  counterId: string;
  cashierName: string;
}

export interface CashierUser {
  id: string;
  loginId: string;
  passwordHash: string; // login password
  name: string;
  staffCode: string;
  role: 'Senior Cashier' | 'POS Cashier' | 'Society Manager' | 'System Admin';
  assignedCounter: string;
  isActive?: boolean;
  createdAt?: string;
  lastLogin?: string;
}

export interface AdminStoreSettings {
  transactionsEnabled: boolean; // Master toggle to stop/halt transactions
  upiPaymentsEnabled: boolean; // Enable/disable UPI payments
  cashPaymentsEnabled: boolean; // Enable/disable cash payments
  memberDiscountPercent?: number; // legacy optional
  emergencyNotice: string;
  haltReason?: string;
}

export interface AdminAuditLog {
  id: string;
  timestamp: string;
  action: string;
  performedBy: string;
  details: string;
}



