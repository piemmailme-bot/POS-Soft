/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  INITIAL_PRODUCTS,
  INITIAL_LEDGER,
  INITIAL_CASHIERS,
  INITIAL_ADMIN_SETTINGS,
  INITIAL_AUDIT_LOGS,
  SOCIETY_INFO,
  CATEGORIES,
} from './data/initialData';
import {
  Product,
  CartItem,
  SaleTransactionItem,
  CompleteInvoice,
  PaymentMode,
  SocietyProfile,
  CashierUser,
  AdminStoreSettings,
  AdminAuditLog,
  LoosePacket,
} from './types';
import { getStoredLoosePackets, saveLoosePackets } from './utils/looseBarcode';
import { Navbar } from './components/Navbar';
import { PosTerminal } from './components/PosTerminal';
import { InventoryManager } from './components/InventoryManager';
import { DayCashierSummary } from './components/DayCashierSummary';
import { CashDrawerSummary } from './components/CashDrawerSummary';
import { QrScannerModal } from './components/QrScannerModal';
import { PaymentModal } from './components/PaymentModal';
import { ReceiptModal } from './components/ReceiptModal';
import { ProductQrModal } from './components/ProductQrModal';
import { BarcodePrintModal } from './components/BarcodePrintModal';
import { CashierLogin } from './components/CashierLogin';
import { AdminControlPanel } from './components/AdminControlPanel';
import { LooseWeighingModal } from './components/LooseWeighingModal';
import { BackupModal } from './components/BackupModal';

const STORAGE_KEYS = {
  PRODUCTS: 'nabkul_coop_products_v1',
  LEDGER: 'nabkul_coop_ledger_v1',
  CASHIERS: 'nabkul_coop_cashiers_v1',
  CASHIER: 'nabkul_logged_cashier_v1',
  ADMIN_SETTINGS: 'nabkul_admin_settings_v1',
  AUDIT_LOGS: 'nabkul_audit_logs_v1',
  CATEGORIES: 'nabkul_coop_categories_v1',
  LOOSE_PACKETS: 'nabkul_coop_loose_packets_v1',
};

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState<'pos' | 'inventory' | 'ledger' | 'drawer' | 'admin'>('pos');

  // Categories with LocalStorage persistence
  const [categories, setCategories] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('nabkul_coop_categories_v1');
      if (saved) return JSON.parse(saved);
    } catch {}
    return CATEGORIES;
  });

  // Core Data with LocalStorage Persistence
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
      return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
    } catch {
      return INITIAL_PRODUCTS;
    }
  });

  const [ledger, setLedger] = useState<SaleTransactionItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.LEDGER);
      return saved ? JSON.parse(saved) : INITIAL_LEDGER;
    } catch {
      return INITIAL_LEDGER;
    }
  });

  const [cashiers, setCashiers] = useState<CashierUser[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CASHIERS);
      return saved ? JSON.parse(saved) : INITIAL_CASHIERS;
    } catch {
      return INITIAL_CASHIERS;
    }
  });

  const [adminSettings, setAdminSettings] = useState<AdminStoreSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ADMIN_SETTINGS);
      return saved ? JSON.parse(saved) : INITIAL_ADMIN_SETTINGS;
    } catch {
      return INITIAL_ADMIN_SETTINGS;
    }
  });

  const [auditLogs, setAuditLogs] = useState<AdminAuditLog[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS);
      return saved ? JSON.parse(saved) : INITIAL_AUDIT_LOGS;
    } catch {
      return INITIAL_AUDIT_LOGS;
    }
  });

  const [loosePackets, setLoosePackets] = useState<LoosePacket[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.LOOSE_PACKETS);
      return saved ? JSON.parse(saved) : getStoredLoosePackets();
    } catch {
      return getStoredLoosePackets();
    }
  });

  // Auth state: check localStorage for remembered session
  const [currentCashier, setCurrentCashier] = useState<CashierUser | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CASHIER);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [society, setSociety] = useState<SocietyProfile>(() => {
    try {
      const savedCashier = localStorage.getItem(STORAGE_KEYS.CASHIER);
      if (savedCashier) {
        const parsed = JSON.parse(savedCashier) as CashierUser;
        return {
          ...SOCIETY_INFO,
          cashierName: `${parsed.name} (${parsed.staffCode})`,
          counterId: parsed.assignedCounter,
        };
      }
    } catch {
      // ignore
    }
    return SOCIETY_INFO;
  });

  // Cart & Active Sale
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<string>('Walk-in Customer');

  // Modals
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [isWeighingStationOpen, setIsWeighingStationOpen] = useState(false);
  const [isPaymentOpen, setIsPaymentOpen] = useState(false);
  const [paymentModeForModal, setPaymentModeForModal] = useState<'UPI' | 'CASH'>('UPI');
  const [currentReceiptInvoice, setCurrentReceiptInvoice] = useState<CompleteInvoice | null>(null);
  const [selectedProductForQr, setSelectedProductForQr] = useState<Product | null>(null);
  const [isBarcodePrintOpen, setIsBarcodePrintOpen] = useState(false);
  const [barcodePrintSelectedProduct, setBarcodePrintSelectedProduct] = useState<Product | null>(null);
  const [isBackupOpen, setIsBackupOpen] = useState(false);

  const handleOpenBarcodePrint = (product?: Product | null) => {
    setBarcodePrintSelectedProduct(product || null);
    setIsBarcodePrintOpen(true);
  };

  const addAuditLog = (action: string, details: string) => {
    const now = new Date();
    const timestamp = now.toISOString().slice(0, 10) + ' ' + now.toTimeString().slice(0, 5);
    const newLog: AdminAuditLog = {
      id: `audit-${Date.now()}`,
      timestamp,
      action,
      performedBy: currentCashier ? `${currentCashier.name} (${currentCashier.staffCode})` : 'SYSTEM ADMIN',
      details,
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  const handleLoginSuccess = (cashier: CashierUser, counter: string) => {
    setCurrentCashier(cashier);
    setSociety((prev) => ({
      ...prev,
      cashierName: `${cashier.name} (${cashier.staffCode})`,
      counterId: counter,
    }));
    const isUserAdmin = cashier.role === 'System Admin' || cashier.loginId === 'admin';
    setActiveTab(isUserAdmin ? 'admin' : 'pos');
    try {
      localStorage.setItem(STORAGE_KEYS.CASHIER, JSON.stringify(cashier));
    } catch {
      // ignore
    }
  };

  const handleLogout = () => {
    setCurrentCashier(null);
    setActiveTab('pos');
    try {
      localStorage.removeItem(STORAGE_KEYS.CASHIER);
    } catch {
      // ignore
    }
  };

  // Persist data updates
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
    } catch {
      // ignore
    }
  }, [products]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.LEDGER, JSON.stringify(ledger));
    } catch {
      // ignore
    }
  }, [ledger]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.CASHIERS, JSON.stringify(cashiers));
    } catch {
      // ignore
    }
  }, [cashiers]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.ADMIN_SETTINGS, JSON.stringify(adminSettings));
    } catch {
      // ignore
    }
  }, [adminSettings]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(auditLogs));
    } catch {
      // ignore
    }
  }, [auditLogs]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
    } catch {
      // ignore
    }
  }, [categories]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.LOOSE_PACKETS, JSON.stringify(loosePackets));
    } catch {
      // ignore
    }
  }, [loosePackets]);

  // Category management handlers
  const handleAddCategory = (newCat: string) => {
    const trimmed = newCat.trim();
    if (!trimmed) return;
    setCategories((prev) => {
      if (prev.includes(trimmed)) return prev;
      return [...prev, trimmed];
    });
    addAuditLog('CATEGORY_ADDED', `Created new product category "${trimmed}"`);
  };

  const handleRenameCategory = (oldCat: string, newCat: string) => {
    const trimmedOld = oldCat.trim();
    const trimmedNew = newCat.trim();
    if (!trimmedNew || trimmedOld === trimmedNew) return;
    setCategories((prev) => prev.map((c) => (c === trimmedOld ? trimmedNew : c)));
    setProducts((prev) =>
      prev.map((p) => (p.category === trimmedOld ? { ...p, category: trimmedNew } : p))
    );
    addAuditLog('CATEGORY_RENAMED', `Renamed category "${trimmedOld}" to "${trimmedNew}"`);
  };

  // Cashier staff management
  const handleAddCashier = (newCashierData: Omit<CashierUser, 'id'>) => {
    const newId = `cashier-${Date.now()}`;
    const newCashier: CashierUser = {
      ...newCashierData,
      id: newId,
    };
    setCashiers((prev) => [...prev, newCashier]);
    addAuditLog(
      'CASHIER_CREATED',
      `Registered new staff ${newCashier.name} (${newCashier.staffCode}), login: "${newCashier.loginId}", counter: ${newCashier.assignedCounter}`
    );
  };

  const handleRemoveCashier = (cashierId: string) => {
    const target = cashiers.find((c) => c.id === cashierId);
    if (!target) return;
    setCashiers((prev) => prev.filter((c) => c.id !== cashierId));
    addAuditLog(
      'CASHIER_REMOVED',
      `Deleted cashier profile: ${target.name} (${target.staffCode}, ID: ${target.loginId})`
    );
  };

  const handleToggleCashierStatus = (cashierId: string) => {
    const target = cashiers.find((c) => c.id === cashierId);
    if (!target) return;
    const nextStatus = !target.isActive;
    setCashiers((prev) =>
      prev.map((c) => (c.id === cashierId ? { ...c, isActive: nextStatus } : c))
    );
    addAuditLog(
      nextStatus ? 'CASHIER_ACTIVATED' : 'CASHIER_DEACTIVATED',
      `${nextStatus ? 'Activated' : 'Deactivated'} staff login for ${target.name} (${target.staffCode})`
    );
  };

  const handleResetPassword = (cashierId: string, newPass: string) => {
    const target = cashiers.find((c) => c.id === cashierId);
    if (!target) return;
    setCashiers((prev) =>
      prev.map((c) => (c.id === cashierId ? { ...c, passwordHash: newPass } : c))
    );
    addAuditLog(
      'PASSWORD_RESET',
      `Updated credentials for ${target.name} (${target.staffCode})`
    );
  };

  const handleUpdateAdminSettings = (newSettings: AdminStoreSettings) => {
    const wasStopped = !adminSettings.transactionsEnabled;
    const isStoppedNow = !newSettings.transactionsEnabled;
    setAdminSettings(newSettings);
    if (!wasStopped && isStoppedNow) {
      addAuditLog(
        'TRANSACTIONS_HALTED',
        `Emergency STOP placed on store transactions. Reason: ${newSettings.haltReason || 'Administrative freeze'}`
      );
    } else if (wasStopped && !isStoppedNow) {
      addAuditLog('TRANSACTIONS_RESUMED', 'Store transactions RESUMED across all POS registers.');
    } else {
      addAuditLog('SETTINGS_UPDATED', 'Updated store administrative settings and payment channels.');
    }
  };

  // Next Invoice Number generator
  const getNextInvoiceNo = () => {
    const existingNumbers = ledger
      .map((item) => {
        const match = item.invoiceNo.match(/POS-2026-(\d+)/);
        return match ? parseInt(match[1]) : 0;
      })
      .filter(Boolean);
    const maxNum = existingNumbers.length > 0 ? Math.max(...existingNumbers) : 3;
    const nextNum = maxNum + 1;
    return `POS-2026-${nextNum.toString().padStart(4, '0')}`;
  };

  // Cart operations
  const addToCart = (product: Product, quantity = 1, packetBarcode?: string) => {
    setCart((prev) => {
      const existing = prev.find(
        (item) =>
          item.product.id === product.id &&
          (!packetBarcode || item.packetBarcode === packetBarcode)
      );
      if (existing) {
        const newQty = Math.min(product.stock, existing.quantity + quantity);
        return prev.map((item) =>
          item.product.id === product.id &&
          (!packetBarcode || item.packetBarcode === packetBarcode)
            ? {
                ...item,
                quantity: newQty,
                lineTotal: newQty * item.sellingPrice,
              }
            : item
        );
      } else {
        const qty = Math.min(product.stock, quantity);
        return [
          ...prev,
          {
            product,
            quantity: qty,
            sellingPrice: product.sellingPrice,
            lineTotal: qty * product.sellingPrice,
            packetBarcode,
          },
        ];
      }
    });
  };

  const updateQuantity = (productId: number, qty: number) => {
    if (qty <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => {
        if (item.product.id === productId) {
          const clampedQty = Math.min(item.product.stock, qty);
          return {
            ...item,
            quantity: clampedQty,
            lineTotal: clampedQty * item.sellingPrice,
          };
        }
        return item;
      })
    );
  };

  const removeFromCart = (productId: number) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const clearCart = () => {
    setCart([]);
  };

  // Scanned item handler from the QR / Barcode reader modal
  const handleProductScanned = (product: Product, quantity = 1, packetBarcode?: string) => {
    addToCart(product, quantity, packetBarcode);
    setActiveTab('pos');
  };

  // Initiate Payment
  const handleProceedToPayment = (mode: 'UPI' | 'CASH') => {
    if (!adminSettings.transactionsEnabled) {
      return;
    }
    if (cart.length === 0) return;
    setPaymentModeForModal(mode);
    setIsPaymentOpen(true);
  };

  // Complete Payment & Finalize Invoice
  const handlePaymentComplete = (details: {
    paymentMode: PaymentMode;
    customerName: string;
    tenderedCash?: number;
    changeDue?: number;
    upiTxnRef?: string;
  }) => {
    if (!adminSettings.transactionsEnabled) {
      setIsPaymentOpen(false);
      return;
    }

    const invNo = getNextInvoiceNo();
    const now = new Date();
    const dateFormatted = `${now.toLocaleDateString('en-CA')} ${now.toTimeString().slice(0, 5)}`;

    const subtotal = cart.reduce((sum, item) => sum + item.lineTotal, 0);
    const discount = 0;
    const grandTotal = subtotal;

    // Max sale item id and sale id from existing ledger
    const maxSaleItemId = ledger.reduce((max, it) => Math.max(max, it.saleItemId), 9000);
    const maxSaleId = ledger.reduce((max, it) => Math.max(max, it.saleId), 8000);
    const nextSaleId = maxSaleId + 1;

    // Create ledger items (Stock Output)
    const newLedgerItems: SaleTransactionItem[] = cart.map((item, idx) => ({
      saleItemId: maxSaleItemId + idx + 1,
      saleId: nextSaleId,
      invoiceNo: invNo,
      saleDate: dateFormatted,
      customerName: details.customerName,
      paymentMode: details.paymentMode,
      productId: item.product.id,
      productName: item.product.name,
      barcode: item.packetBarcode || item.product.barcode,
      quantity: item.quantity,
      unitType: item.product.unit,
      sellingPrice: item.sellingPrice,
      lineTotal: item.lineTotal,
      cashierName: currentCashier?.name || 'Subrata Roy',
    }));

    // Update real-time inventory: decrement available stock ON SALE COMPLETION
    setProducts((prev) =>
      prev.map((prod) => {
        const soldItem = cart.find((c) => c.product.id === prod.id);
        if (soldItem) {
          return {
            ...prod,
            stock: Math.max(0, prod.stock - soldItem.quantity),
          };
        }
        return prod;
      })
    );

    // Mark any scanned unique loose packets as SOLD in Loose Packet Registry
    setLoosePackets((prev) =>
      prev.map((pk) => {
        const matchingCartItem = cart.find((c) => c.packetBarcode === pk.uniqueBarcode);
        if (matchingCartItem) {
          return {
            ...pk,
            status: 'SOLD',
            soldAtInvoiceNo: invNo,
            soldDate: dateFormatted,
          };
        }
        return pk;
      })
    );

    // Append to ledger
    setLedger((prev) => [...prev, ...newLedgerItems]);

    // Build complete invoice object
    const completeInvoice: CompleteInvoice = {
      saleId: nextSaleId,
      invoiceNo: invNo,
      saleDate: dateFormatted,
      customerName: details.customerName,
      paymentMode: details.paymentMode,
      items: cart.map((c) => ({
        productId: c.product.id,
        productName: c.product.name,
        barcode: c.product.barcode,
        quantity: c.quantity,
        unitType: c.product.unit,
        sellingPrice: c.sellingPrice,
        lineTotal: c.lineTotal,
      })),
      subtotal,
      discount,
      grandTotal,
      cashier: society.cashierName,
      tenderedCash: details.tenderedCash,
      changeDue: details.changeDue,
      upiTxnRef: details.upiTxnRef,
    };

    // Close payment modal, clear cart, open receipt
    setIsPaymentOpen(false);
    setCart([]);
    setCurrentReceiptInvoice(completeInvoice);
  };

  // Inventory update handlers
  const handleUpdateProduct = (updated: Product) => {
    setProducts((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
  };

  const handleAddProduct = (newProd: Omit<Product, 'id'>) => {
    const nextId = products.reduce((max, p) => Math.max(max, p.id), 100) + 1;
    setProducts((prev) => [...prev, { ...newProd, id: nextId }]);
  };

  // Low stock count for navbar badge
  const lowStockCount = products.filter((p) => p.stock <= p.minStockLevel).length;

  // Active totals
  const subtotal = cart.reduce((sum, item) => sum + item.lineTotal, 0);
  const discount = 0;
  const grandTotal = subtotal;

  const isAdmin = currentCashier?.role === 'System Admin' || currentCashier?.loginId === 'admin';

  // Security guard: If a cashier logs in and activeTab is 'admin', automatically redirect to 'pos'
  useEffect(() => {
    if (currentCashier && !isAdmin && activeTab === 'admin') {
      setActiveTab('pos');
    }
  }, [currentCashier, isAdmin, activeTab]);

  if (!currentCashier) {
    return (
      <CashierLogin
        cashiers={cashiers}
        society={society}
        onLoginSuccess={handleLoginSuccess}
        adminSettings={adminSettings}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 flex flex-col font-sans">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        society={society}
        cartCount={cart.reduce((sum, i) => sum + i.quantity, 0)}
        lowStockCount={lowStockCount}
        onOpenScanner={() => setIsScannerOpen(true)}
        onOpenBarcodePrint={() => handleOpenBarcodePrint(null)}
        onOpenWeighingStation={() => setIsWeighingStationOpen(true)}
        currentCashier={currentCashier}
        onLogout={handleLogout}
        adminSettings={adminSettings}
        onOpenBackup={() => setIsBackupOpen(true)}
      />

      {/* Main View Area */}
      <main className="flex-1 pb-16">
        {activeTab === 'pos' && (
          <PosTerminal
            products={products}
            cart={cart}
            loosePackets={loosePackets}
            addToCart={addToCart}
            updateQuantity={updateQuantity}
            removeFromCart={removeFromCart}
            clearCart={clearCart}
            onOpenScanner={() => setIsScannerOpen(true)}
            onOpenWeighingStation={() => setIsWeighingStationOpen(true)}
            onOpenProductQr={(product) => setSelectedProductForQr(product)}
            onProceedToPayment={handleProceedToPayment}
            selectedCustomer={selectedCustomer}
            setSelectedCustomer={setSelectedCustomer}
            society={society}
            adminSettings={adminSettings}
            categories={categories}
          />
        )}

        {activeTab === 'inventory' && (
          <InventoryManager
            products={products}
            onUpdateProduct={handleUpdateProduct}
            onAddProduct={handleAddProduct}
            onOpenProductQr={(product) => setSelectedProductForQr(product)}
            onOpenBarcodePrint={handleOpenBarcodePrint}
            society={society}
            categories={categories.filter((c) => c !== 'All Items')}
            onAddCategory={handleAddCategory}
            onRenameCategory={handleRenameCategory}
          />
        )}

        {activeTab === 'ledger' && (
          <DayCashierSummary
            ledger={ledger}
            cashiers={cashiers}
            onViewInvoice={(inv) => setCurrentReceiptInvoice(inv)}
            societyName={society.name}
          />
        )}

        {activeTab === 'drawer' && (
          <CashDrawerSummary ledger={ledger} society={society} />
        )}

        {activeTab === 'admin' && isAdmin && (
          <AdminControlPanel
            cashiers={cashiers}
            currentCashier={currentCashier}
            adminSettings={adminSettings}
            auditLogs={auditLogs}
            onAddCashier={handleAddCashier}
            onRemoveCashier={handleRemoveCashier}
            onToggleCashierStatus={handleToggleCashierStatus}
            onResetPassword={handleResetPassword}
            onUpdateAdminSettings={handleUpdateAdminSettings}
            society={society}
            onExitAdminToPos={() => setActiveTab('pos')}
          />
        )}
      </main>

      {/* Modals */}
      <QrScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        products={products}
        currentCart={cart}
        loosePackets={loosePackets}
        onProductScanned={handleProductScanned}
        onUpdateCartItem={updateQuantity}
        onRemoveCartItem={removeFromCart}
        onProceedToCheckout={() => {
          setIsScannerOpen(false);
          setIsPaymentOpen(true);
        }}
      />

      <LooseWeighingModal
        isOpen={isWeighingStationOpen}
        onClose={() => setIsWeighingStationOpen(false)}
        products={products}
        society={society}
        loosePackets={loosePackets}
        setLoosePackets={setLoosePackets}
        onAddToCart={(product, qtyInBase, packetBarcode) => {
          addToCart(product, qtyInBase, packetBarcode);
        }}
      />

      <PaymentModal
        isOpen={isPaymentOpen}
        onClose={() => setIsPaymentOpen(false)}
        cart={cart}
        grandTotal={grandTotal}
        discount={discount}
        invoiceNo={getNextInvoiceNo()}
        selectedCustomer={selectedCustomer}
        setSelectedCustomer={setSelectedCustomer}
        society={society}
        onPaymentComplete={handlePaymentComplete}
      />

      <ReceiptModal
        isOpen={Boolean(currentReceiptInvoice)}
        onClose={() => setCurrentReceiptInvoice(null)}
        invoice={currentReceiptInvoice}
        society={society}
        onNewSale={() => {
          setCurrentReceiptInvoice(null);
          setActiveTab('pos');
        }}
      />

      <ProductQrModal
        isOpen={Boolean(selectedProductForQr)}
        onClose={() => setSelectedProductForQr(null)}
        product={selectedProductForQr}
        society={society}
      />

      <BarcodePrintModal
        isOpen={isBarcodePrintOpen}
        onClose={() => {
          setIsBarcodePrintOpen(false);
          setBarcodePrintSelectedProduct(null);
        }}
        products={products}
        society={society}
        initialSelectedProduct={barcodePrintSelectedProduct}
      />

      <BackupModal
        isOpen={isBackupOpen}
        onClose={() => setIsBackupOpen(false)}
        societyName={society.name}
      />
    </div>
  );
}
