import React from 'react';
import { ShoppingBag, PackageCheck, FileSpreadsheet, Users, Wallet, QrCode, Store, Clock, LogOut, UserCheck, ShieldAlert, AlertTriangle, Barcode, Scale, Database } from 'lucide-react';
import { SocietyProfile, CashierUser, AdminStoreSettings } from '../types';

interface NavbarProps {
  activeTab: 'pos' | 'inventory' | 'ledger' | 'drawer' | 'admin';
  setActiveTab: (tab: 'pos' | 'inventory' | 'ledger' | 'drawer' | 'admin') => void;
  society: SocietyProfile;
  cartCount: number;
  lowStockCount: number;
  onOpenScanner: () => void;
  onOpenBarcodePrint: () => void;
  onOpenWeighingStation?: () => void;
  currentCashier: CashierUser | null;
  onLogout: () => void;
  adminSettings?: AdminStoreSettings;
  onOpenBackup: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  society,
  cartCount,
  lowStockCount,
  onOpenScanner,
  onOpenBarcodePrint,
  onOpenWeighingStation,
  currentCashier,
  onLogout,
  adminSettings,
  onOpenBackup,
}) => {
  const [dateTime, setDateTime] = React.useState({ time: '', date: '' });

  React.useEffect(() => {
    const updateDateTime = () => {
      const now = new Date();
      setDateTime({
        time: now.toLocaleTimeString('en-IN', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: true,
        }),
        date: now.toLocaleDateString('en-IN'),
      });
    };
    updateDateTime();
    const interval = setInterval(updateDateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-30 shadow-md">
      {/* Emergency Transaction Halt Banner */}
      {adminSettings && !adminSettings.transactionsEnabled && (
        <div className="bg-rose-600 text-white px-4 py-1.5 text-xs font-bold text-center flex items-center justify-center gap-2 shadow-inner">
          <AlertTriangle className="w-4 h-4 text-amber-200 animate-pulse" />
          <span>EMERGENCY: Store Transactions are currently STOPPED by Administrator ({adminSettings.haltReason || 'Sales on hold'})</span>
        </div>
      )}

      {/* Top micro-bar: Address, Reg, Cashier info */}
      <div className="bg-slate-950 px-4 py-1.5 text-xs text-slate-400 flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/60">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5 font-medium text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            Online POS Terminal Active
          </span>
          <span className="text-slate-600">|</span>
          <span className="text-slate-300">Reg: {society.regNo}</span>
          <span className="text-slate-600">|</span>
          <span className="text-slate-300">📍 {society.address}</span>
          <span className="text-slate-600">|</span>
          <button
            onClick={onOpenBackup}
            className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 transition-all font-bold"
            title="Download Full Project Backup Archive"
          >
            <Database className="w-3 h-3" />
            <span>SYSTEM BACKUP</span>
          </button>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-slate-300 flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-mono-code text-slate-200">{dateTime.date} · {dateTime.time || '10:30:00 AM'}</span>
          </span>
          <span className="text-slate-600">|</span>
          <div className="flex items-center gap-1.5 text-slate-200">
            <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>
              {currentCashier ? (
                <>
                  <strong className="text-white">{currentCashier.name}</strong>{' '}
                  <span className="text-emerald-400 font-mono-code">({currentCashier.staffCode})</span>
                </>
              ) : (
                society.cashierName
              )}
            </span>
            {currentCashier && (
              <span className={`text-[10px] px-1.5 py-0.2 rounded font-medium border ${
                currentCashier.role === 'System Admin'
                  ? 'bg-purple-950 border-purple-500/40 text-purple-300'
                  : 'bg-emerald-950 border-emerald-500/40 text-emerald-300'
              }`}>
                {currentCashier.role}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
        {/* Brand identity */}
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-800 border border-emerald-400/40 flex items-center justify-center shadow-lg text-emerald-100 flex-shrink-0">
            <Store className="w-6 h-6 text-emerald-300" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-xl font-bold tracking-tight text-white leading-tight">
                {society.name}
              </h1>
              <span className="hidden md:inline-block text-[11px] font-semibold uppercase tracking-wider text-amber-300 bg-amber-950/60 border border-amber-500/30 px-2 py-0.5 rounded">
                Kolkata Co-op Store
              </span>
            </div>
            <p className="text-xs text-slate-400 flex items-center gap-1.5">
              <span>Counter: {society.counterId}</span>
              <span>·</span>
              <span className="text-emerald-400 font-mono-code font-medium">UPI: {society.upiId}</span>
            </p>
          </div>
        </div>

        {/* Action Buttons: Scale Station + Print Barcodes + Scan Barcode + Logout */}
        <div className="flex items-center gap-2">
          {onOpenWeighingStation && (
            <button
              onClick={onOpenWeighingStation}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-amber-950/70 hover:bg-amber-900 text-amber-300 text-xs font-bold border border-amber-500/40 transition-colors shadow-sm"
              title="Open Loose Item Weighing & Package Barcode Station"
            >
              <Scale className="w-4 h-4 text-amber-400" />
              <span className="hidden sm:inline">Weigh & Print Barcode</span>
            </button>
          )}

          <button
            onClick={onOpenBarcodePrint}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors"
            title="Open Product Barcode & QR Sticker Printing Center"
          >
            <Barcode className="w-4 h-4 text-emerald-400" />
            <span className="hidden sm:inline">Print Barcodes</span>
          </button>

          <button
            onClick={onOpenScanner}
            className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold shadow-md shadow-emerald-950/50 transition-all hover:scale-[1.02] active:scale-[0.98]"
            title="Open camera or handheld barcode/QR reader"
          >
            <QrCode className="w-4 h-4 text-emerald-200" />
            <span className="hidden sm:inline">Scan QR / Barcode</span>
            <span className="sm:hidden">Scan</span>
          </button>

          <button
            onClick={onLogout}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-rose-950/60 text-slate-300 hover:text-rose-300 text-xs font-semibold border border-slate-700/80 hover:border-rose-500/40 transition-colors"
            title="Lock register and logout cashier"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Lock / Log Out</span>
          </button>
        </div>
      </div>

      {/* Navigation tabs */}
      <nav className="border-t border-slate-800/80 bg-slate-900/90 px-4 sm:px-6 overflow-x-auto scrollbar-none">
        <div className="max-w-7xl mx-auto flex items-center gap-1 sm:gap-2 py-1 text-sm font-medium">
          <button
            onClick={() => setActiveTab('pos')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'pos'
                ? 'bg-emerald-600/20 text-emerald-300 font-semibold border border-emerald-500/30'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Smart POS & Billing</span>
            {cartCount > 0 && (
              <span className="bg-emerald-500 text-slate-950 font-bold text-xs px-1.5 py-0.2 rounded-full font-mono-code">
                {cartCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('inventory')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'inventory'
                ? 'bg-emerald-600/20 text-emerald-300 font-semibold border border-emerald-500/30'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <PackageCheck className="w-4 h-4" />
            <span>Product & Stock Catalog</span>
            {lowStockCount > 0 && (
              <span className="bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs px-1.5 rounded font-mono-code">
                {lowStockCount} low
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('ledger')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'ledger'
                ? 'bg-emerald-600/20 text-emerald-300 font-semibold border border-emerald-500/30'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Day & Cashier Summary</span>
          </button>

          <button
            onClick={() => setActiveTab('drawer')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'drawer'
                ? 'bg-emerald-600/20 text-emerald-300 font-semibold border border-emerald-500/30'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Wallet className="w-4 h-4" />
            <span>Cash Register & Day Closing</span>
          </button>

          {/* Admin Control Center Tab - ONLY visible when Administrator is logged in */}
          {currentCashier && (currentCashier.role === 'System Admin' || currentCashier.loginId === 'admin') && (
            <button
              onClick={() => setActiveTab('admin')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap ${
                activeTab === 'admin'
                  ? 'bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/40'
                  : 'text-amber-400 hover:text-amber-200 hover:bg-amber-950/40'
              }`}
            >
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              <span>Admin Center</span>
              {!adminSettings?.transactionsEnabled && (
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
              )}
            </button>
          )}
        </div>
      </nav>
    </header>
  );
};

