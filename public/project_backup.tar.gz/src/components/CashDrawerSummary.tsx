import React, { useState } from 'react';
import {
  Wallet,
  Banknote,
  QrCode,
  Calculator,
  CheckCircle2,
  AlertCircle,
  Printer,
  Download,
  X,
  FileText,
  Building2,
  UserCheck
} from 'lucide-react';
import { SaleTransactionItem, SocietyProfile } from '../types';

interface CashDrawerSummaryProps {
  ledger: SaleTransactionItem[];
  society: SocietyProfile;
}

export const CashDrawerSummary: React.FC<CashDrawerSummaryProps> = ({
  ledger,
  society,
}) => {
  const [openingFloat, setOpeningFloat] = useState(2500); // Morning opening cash float in drawer
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  
  // Note counts
  const [counts, setCounts] = useState<{ [denom: number]: number }>({
    500: 4,
    200: 5,
    100: 10,
    50: 8,
    20: 10,
    10: 20,
  });

  const cashSalesTotal = ledger
    .filter((i) => i.paymentMode === 'CASH')
    .reduce((sum, item) => sum + item.lineTotal, 0);

  const upiSalesTotal = ledger
    .filter((i) => i.paymentMode === 'UPI')
    .reduce((sum, item) => sum + item.lineTotal, 0);


  const expectedCashInDrawer = openingFloat + cashSalesTotal;

  const actualCountedCash = Object.entries(counts).reduce((sum, [denom, count]) => {
    return sum + Number(denom) * (count || 0);
  }, 0);

  const variance = actualCountedCash - expectedCashInDrawer;
  const nowStr = new Date().toLocaleString('en-IN', {
    dateStyle: 'medium',
    timeStyle: 'short',
  });

  const handleNoteChange = (denom: number, value: string) => {
    const val = parseInt(value) || 0;
    setCounts((prev) => ({ ...prev, [denom]: val }));
  };

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadTxt = () => {
    const lines = [
      '===========================================================',
      `             ${society.name.toUpperCase()}            `,
      `          ${society.address}         `,
      `Reg: ${society.regNo} | Tel: ${society.phone}`,
      '===========================================================',
      '     CASHIER DAILY SETTLEMENT REPORT (Z-REPORT)    ',
      '===========================================================',
      `Date & Time:      ${nowStr}`,
      `Counter:          ${society.counterId}`,
      `Cashier:          ${society.cashierName}`,
      `UPI ID:           ${society.upiId} (${society.merchantName || 'PIEM PANDEY'})`,
      '-----------------------------------------------------------',
      'REVENUE & COLLECTIONS SUMMARY:',
      `Opening Cash Float:            ₹${openingFloat.toFixed(2)}`,
      `Cash Sales (I Cash):           ₹${cashSalesTotal.toFixed(2)}`,
      `Expected Cash in Drawer:       ₹${expectedCashInDrawer.toFixed(2)}`,
      `Actual Cash Counted:           ₹${actualCountedCash.toFixed(2)}`,
      `Cash Variance:                 ${variance >= 0 ? '+' : ''}₹${variance.toFixed(2)} (${
        variance === 0 ? 'Balanced' : variance > 0 ? 'Excess' : 'Shortage'
      })`,
      '-----------------------------------------------------------',
      `Online QR / UPI Collections:   ₹${upiSalesTotal.toFixed(2)}`,
      `GROSS DAY TURNOVER:            ₹${(cashSalesTotal + upiSalesTotal).toFixed(2)}`,
      '-----------------------------------------------------------',
      'PHYSICAL CASH DENOMINATIONS IN DRAWER:',
      ...[500, 200, 100, 50, 20, 10].map(
        (denom) =>
          `  ₹${denom.toString().padEnd(4)} x ${(counts[denom] || 0)
            .toString()
            .padStart(3)} = ₹${(denom * (counts[denom] || 0)).toFixed(2)}`
      ),
      '-----------------------------------------------------------',
      'Cashier Signature: ___________________________',
      '',
      'Manager / Secretary Signature: ________________',
      '===========================================================',
    ].join('\n');

    const blob = new Blob([lines], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Z_Report_${new Date().toISOString().slice(0, 10)}.txt`;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        <div>
          <h3 className="font-extrabold text-xl text-slate-900">
            Cash Register & Daily Day-End Settlement (Z-Report)
          </h3>
          <p className="text-xs text-slate-500">
            {society.name} · Counter: {society.counterId} · Cashier: {society.cashierName}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsPreviewOpen(true)}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors border border-slate-300"
          >
            <FileText className="w-4 h-4 text-emerald-600" />
            <span>Preview Voucher</span>
          </button>
          <button
            onClick={handlePrint}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow transition-colors"
          >
            <Printer className="w-4 h-4 text-emerald-400" />
            <span>Print Cashier Day-End Summary</span>
          </button>
        </div>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase">
              Physical Cash in Drawer
            </span>
            <Banknote className="w-5 h-5 text-amber-600" />
          </div>
          <div className="text-2xl font-extrabold text-slate-900 mt-2 font-mono-code">
            ₹{actualCountedCash.toFixed(2)}
          </div>
          <div className="text-xs text-slate-500 mt-1">
            Opening Float: ₹{openingFloat.toFixed(2)} + Cash Sales: ₹{cashSalesTotal.toFixed(2)}
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase">
              Online QR / UPI Settled
            </span>
            <QrCode className="w-5 h-5 text-emerald-600" />
          </div>
          <div className="text-2xl font-extrabold text-emerald-700 mt-2 font-mono-code">
            ₹{upiSalesTotal.toFixed(2)}
          </div>
          <div className="text-xs text-slate-500 mt-1">
            PhonePe UPI: <strong className="font-mono-code">{society.upiId}</strong>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase">
              Cash Drawer Reconciliation
            </span>
            {Math.abs(variance) < 1 ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            ) : (
              <AlertCircle className="w-5 h-5 text-amber-500" />
            )}
          </div>
          <div
            className={`text-2xl font-extrabold mt-2 font-mono-code ${
              variance === 0
                ? 'text-emerald-700'
                : variance > 0
                ? 'text-blue-700'
                : 'text-rose-600'
            }`}
          >
            {variance >= 0 ? `+₹${variance.toFixed(2)}` : `-₹${Math.abs(variance).toFixed(2)}`}
          </div>
          <div className="text-xs font-semibold mt-1">
            {Math.abs(variance) < 1 ? (
              <span className="text-emerald-700">Perfect Match (Balanced)</span>
            ) : variance > 0 ? (
              <span className="text-blue-700">Cash Excess / Tip</span>
            ) : (
              <span className="text-rose-600">Cash Shortage</span>
            )}
          </div>
        </div>
      </div>

      {/* Denomination Counter Box */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-4">
          <h4 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
            <Calculator className="w-4 h-4 text-emerald-600" />
            <span>Cash Denomination Counter (Currency Notes in Drawer)</span>
          </h4>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-500">Morning Float: ₹</span>
            <input
              type="number"
              step="100"
              value={openingFloat}
              onChange={(e) => setOpeningFloat(parseFloat(e.target.value) || 0)}
              className="w-24 px-2 py-1 bg-slate-50 border border-slate-300 rounded font-bold font-mono-code text-slate-800"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {[500, 200, 100, 50, 20, 10].map((denom) => {
            const count = counts[denom] || 0;
            const subtotal = denom * count;

            return (
              <div
                key={denom}
                className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5"
              >
                <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                  <span>₹{denom} Note</span>
                  <span className="text-[10px] text-slate-400 font-mono-code">× count</span>
                </div>
                <input
                  type="number"
                  min="0"
                  value={count}
                  onChange={(e) => handleNoteChange(denom, e.target.value)}
                  className="w-full px-2 py-1.5 text-center font-bold text-sm bg-white border border-slate-300 rounded-lg font-mono-code focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <div className="text-center font-mono-code text-xs font-extrabold text-emerald-800">
                  = ₹{subtotal.toLocaleString()}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ============================================================== */}
      {/* ALWAYS IN DOM: PRINTABLE Z-REPORT (Visible when print triggered) */}
      {/* ============================================================== */}
      <div
        id="printable-receipt"
        className="hidden print:block printable-area bg-white text-black p-8 font-mono-code max-w-2xl mx-auto"
      >
        <div className="text-center pb-4 border-b-2 border-black">
          <h1 className="text-lg font-black uppercase tracking-wider">{society.name}</h1>
          <p className="text-xs font-bold mt-0.5">{society.address}</p>
          <p className="text-[11px]">Reg: {society.regNo} | Tel: {society.phone}</p>
          <div className="mt-2 inline-block px-3 py-1 border border-black font-extrabold text-xs uppercase tracking-wide">
            DAILY CASHIER DAY-END SETTLEMENT (Z-REPORT)
          </div>
        </div>

        {/* Audit Details */}
        <div className="py-3 border-b border-black text-xs space-y-1">
          <div className="flex justify-between">
            <span>Report Generated:</span>
            <span className="font-bold">{nowStr}</span>
          </div>
          <div className="flex justify-between">
            <span>Counter ID:</span>
            <span className="font-bold">{society.counterId}</span>
          </div>
          <div className="flex justify-between">
            <span>Cashier / Staff:</span>
            <span className="font-bold">{society.cashierName}</span>
          </div>
          <div className="flex justify-between">
            <span>UPI ID / Payee:</span>
            <span>{society.upiId} ({society.merchantName || 'PIEM PANDEY'})</span>
          </div>
        </div>

        {/* Collections Breakdown Table */}
        <div className="py-3 border-b border-black text-xs space-y-1.5">
          <div className="font-bold uppercase tracking-wider mb-1 text-[11px]">
            1. Cash Drawer Reconciliation:
          </div>
          <div className="flex justify-between">
            <span>(+) Opening Cash Float:</span>
            <span className="font-bold">₹{openingFloat.toFixed(2)}</span>
          </div>
          <div className="flex justify-between">
            <span>(+) Today Cash Sales (I Cash):</span>
            <span className="font-bold">₹{cashSalesTotal.toFixed(2)}</span>
          </div>
          <div className="flex justify-between border-t border-dashed border-gray-400 pt-1">
            <span>Expected Physical Cash in Drawer:</span>
            <span className="font-bold">₹{expectedCashInDrawer.toFixed(2)}</span>
          </div>
          <div className="flex justify-between">
            <span>Actual Counted Cash in Drawer:</span>
            <span className="font-black text-sm">₹{actualCountedCash.toFixed(2)}</span>
          </div>
          <div className="flex justify-between font-bold border-t border-black pt-1">
            <span>Drawer Variance (Excess / Shortage):</span>
            <span>
              {variance >= 0 ? `+₹${variance.toFixed(2)}` : `-₹${Math.abs(variance).toFixed(2)}`} (
              {variance === 0 ? 'Balanced' : variance > 0 ? 'Excess' : 'Shortage'})
            </span>
          </div>
        </div>

        {/* Other Payments Breakdown */}
        <div className="py-3 border-b border-black text-xs space-y-1.5">
          <div className="font-bold uppercase tracking-wider mb-1 text-[11px]">
            2. Digital & Credit Summary:
          </div>
          <div className="flex justify-between font-black text-sm border-t border-black pt-1">
            <span>TOTAL GROSS DAY REVENUE:</span>
            <span>₹{(cashSalesTotal + upiSalesTotal).toFixed(2)}</span>
          </div>
        </div>

        {/* Physical Notes Table */}
        <div className="py-3 border-b border-black text-xs">
          <div className="font-bold uppercase tracking-wider mb-2 text-[11px]">
            3. Physical Currency Denominations Counted:
          </div>
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-gray-400">
                <th className="pb-1">Denomination</th>
                <th className="pb-1 text-center">Count</th>
                <th className="pb-1 text-right">Subtotal</th>
              </tr>
            </thead>
            <tbody>
              {[500, 200, 100, 50, 20, 10].map((denom) => (
                <tr key={denom} className="border-b border-gray-200">
                  <td className="py-1">₹{denom} Currency Note</td>
                  <td className="py-1 text-center">{counts[denom] || 0}</td>
                  <td className="py-1 text-right font-bold">
                    ₹{((counts[denom] || 0) * denom).toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="font-bold">
                <td className="pt-2">TOTAL COUNTED CASH</td>
                <td className="pt-2 text-center">
                  {Object.values(counts).reduce((a, b) => a + (b || 0), 0)} Notes
                </td>
                <td className="pt-2 text-right">₹{actualCountedCash.toFixed(2)}</td>
              </tr>
            </tfoot>
          </table>
        </div>

        {/* Signatures */}
        <div className="pt-8 pb-4 text-xs grid grid-cols-2 gap-8">
          <div>
            <div className="border-t border-black pt-1 text-center">
              Cashier Signature ({society.cashierName})
            </div>
          </div>
          <div>
            <div className="border-t border-black pt-1 text-center">
              Secretary / Manager Signature
            </div>
          </div>
        </div>

        <div className="text-center text-[10px] text-gray-500 pt-2 border-t border-dashed border-gray-400">
          Nabkul Cooperative Society · 61 A/238, Kolkata: 700028 · Official Audit Copy
        </div>
      </div>

      {/* Preview Modal for Screen */}
      {isPreviewOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
            {/* Header */}
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-sm">Cashier Day-End Settlement (Z-Report) Preview</h3>
              </div>
              <button
                onClick={() => setIsPreviewOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Document preview */}
            <div className="p-6 overflow-y-auto bg-slate-50 flex-1">
              <div className="bg-white p-6 rounded-xl border border-slate-300 shadow-sm font-mono-code text-xs space-y-4">
                <div className="text-center pb-3 border-b border-slate-300">
                  <h4 className="font-extrabold text-sm uppercase text-slate-900">
                    {society.name}
                  </h4>
                  <p className="text-[11px] text-slate-600">{society.address}</p>
                  <p className="text-[10px] text-slate-500">Reg: {society.regNo}</p>
                  <span className="inline-block mt-2 px-2.5 py-0.5 rounded bg-slate-100 border border-slate-300 font-bold text-[10px] text-slate-800 uppercase">
                    Daily Settlement Audit Voucher
                  </span>
                </div>

                <div className="text-[11px] space-y-1 text-slate-700">
                  <div className="flex justify-between">
                    <span>Date: {nowStr}</span>
                    <span>Counter: {society.counterId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Cashier: {society.cashierName}</span>
                    <span>UPI: {society.upiId}</span>
                  </div>
                </div>

                <div className="border-t border-slate-200 pt-3 space-y-1.5 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-600">Opening Cash Float:</span>
                    <span className="font-bold">₹{openingFloat.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Today Cash Sales:</span>
                    <span className="font-bold text-emerald-700">₹{cashSalesTotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between border-t border-slate-200 pt-1">
                    <span className="font-semibold text-slate-800">Expected in Drawer:</span>
                    <span className="font-bold text-slate-900">₹{expectedCashInDrawer.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-semibold text-slate-800">Actual Cash Counted:</span>
                    <span className="font-extrabold text-slate-900">₹{actualCountedCash.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between font-bold border-t border-slate-200 pt-1 text-emerald-800">
                    <span>Reconciliation Variance:</span>
                    <span>
                      {variance >= 0 ? `+₹${variance.toFixed(2)}` : `-₹${Math.abs(variance).toFixed(2)}`} (
                      {variance === 0 ? 'Balanced' : variance > 0 ? 'Excess' : 'Shortage'})
                    </span>
                  </div>
                  <div className="flex justify-between font-black text-sm pt-1 border-t-2 border-slate-900">
                    <span>GROSS DAY TURNOVER:</span>
                    <span className="text-emerald-800">
                      ₹{(cashSalesTotal + upiSalesTotal).toFixed(2)}
                    </span>
                  </div>
                </div>

                {/* Denominations */}
                <div className="border-t border-slate-200 pt-3">
                  <span className="font-bold text-[11px] text-slate-700 block mb-1">
                    Currency Notes in Drawer:
                  </span>
                  <div className="grid grid-cols-2 gap-1 text-[11px] text-slate-600">
                    {[500, 200, 100, 50, 20, 10].map((d) => (
                      <div key={d} className="flex justify-between bg-slate-50 p-1 rounded">
                        <span>₹{d} × {counts[d] || 0}</span>
                        <span className="font-bold">₹{((counts[d] || 0) * d).toFixed(0)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="p-4 bg-slate-100 border-t border-slate-200 flex items-center justify-between">
              <button
                onClick={() => setIsPreviewOpen(false)}
                className="px-3.5 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800"
              >
                Close
              </button>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleDownloadTxt}
                  className="px-3.5 py-2 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold flex items-center gap-1.5 text-slate-700"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Text</span>
                </button>
                <button
                  onClick={() => {
                    handlePrint();
                  }}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow"
                >
                  <Printer className="w-3.5 h-3.5 text-emerald-300" />
                  <span>Print Document</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
