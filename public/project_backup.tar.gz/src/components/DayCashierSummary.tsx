import React, { useState } from 'react';
import {
  Calendar,
  Users,
  TrendingUp,
  Banknote,
  QrCode,
  Search,
  Receipt,
  Download,
  ShieldCheck,
  Layers,
  Clock,
  CheckCircle2
} from 'lucide-react';
import { SaleTransactionItem, CashierUser, CompleteInvoice } from '../types';
import { exportLedgerToCsv } from '../utils/csvExporter';

interface DayCashierSummaryProps {
  ledger: SaleTransactionItem[];
  cashiers: CashierUser[];
  onViewInvoice: (invoice: CompleteInvoice) => void;
  societyName: string;
}

export const DayCashierSummary: React.FC<DayCashierSummaryProps> = ({
  ledger,
  cashiers,
  onViewInvoice,
  societyName,
}) => {
  // Extract unique dates from ledger
  const datesSet = Array.from(
    new Set(
      ledger.map((item) => {
        return item.saleDate.split(' ')[0] || item.saleDate;
      })
    )
  ).sort().reverse();

  // Robust Local Date Priority
  const getTodayStr = () => {
    const d = new Date();
    // Using en-CA for YYYY-MM-DD format reliably
    return d.toLocaleDateString('en-CA');
  };

  const todayStr = getTodayStr();
  const currentDate = datesSet.includes(todayStr) ? todayStr : (datesSet[0] || todayStr);

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDateFilter, setSelectedDateFilter] = useState<string>(currentDate);
  const [selectedCashierFilter, setSelectedCashierFilter] = useState<string>('ALL');

  const handleClearFilters = () => {
    setSelectedDateFilter(currentDate);
    setSelectedCashierFilter('ALL');
    setSearchQuery('');
    setDateRangeStart('');
    setDateRangeEnd('');
    setCashierDateRangeStart('');
    setCashierDateRangeEnd('');
  };


  // Filtered ledger rows
  const filteredLedger = ledger.filter((row) => {
    const rowDate = row.saleDate.split(' ')[0] || row.saleDate;
    const matchesDate = selectedDateFilter === 'ALL' || rowDate === selectedDateFilter;
    const matchesCashier =
      selectedCashierFilter === 'ALL' || (row as any).cashierName?.includes(selectedCashierFilter);

    const q = searchQuery.toLowerCase();
    const matchesSearch =
      !q ||
      row.invoiceNo.toLowerCase().includes(q) ||
      row.customerName.toLowerCase().includes(q) ||
      row.productName.toLowerCase().includes(q) ||
      row.barcode.includes(q);

    return matchesDate && matchesCashier && matchesSearch;
  });

  const getFilteredLedgerTotal = () => {
    return filteredLedger.reduce((sum, r) => sum + r.lineTotal, 0);
  };

  // Today's priority metrics (rows matching currentDate)
  const todayRows = ledger.filter((row) => {
    const rowDate = row.saleDate.split(' ')[0] || row.saleDate;
    return rowDate === currentDate;
  });

  const todayTurnover = todayRows.reduce((sum, item) => sum + item.lineTotal, 0);
  const todayUpi = todayRows.filter((i) => i.paymentMode === 'UPI').reduce((sum, i) => sum + i.lineTotal, 0);
  const todayCash = todayRows.filter((i) => i.paymentMode === 'CASH').reduce((sum, i) => sum + i.lineTotal, 0);
  const todayInvoiceCount = new Set(todayRows.map((r) => r.invoiceNo)).size;

  const [dateRangeStart, setDateRangeStart] = useState<string>('');
  const [dateRangeEnd, setDateRangeEnd] = useState<string>('');
  const [cashierDateRangeStart, setCashierDateRangeStart] = useState<string>('');
  const [cashierDateRangeEnd, setCashierDateRangeEnd] = useState<string>('');

  // Group by Date for Day-wise Summary
  const daySummaryMap = new Map<string, { turnover: number; upi: number; cash: number; count: number }>();
  ledger.forEach((item) => {
    const d = item.saleDate.split(' ')[0] || item.saleDate;
    const existing = daySummaryMap.get(d) || { turnover: 0, upi: 0, cash: 0, count: 0 };
    existing.turnover += item.lineTotal;
    if (item.paymentMode === 'UPI') existing.upi += item.lineTotal;
    if (item.paymentMode === 'CASH') existing.cash += item.lineTotal;
    existing.count += 1;
    daySummaryMap.set(d, existing);
  });

  const sortedDates = Array.from(daySummaryMap.keys()).sort().reverse();
  const filteredDates = sortedDates.filter((date) => {
    if (dateRangeStart && date < dateRangeStart) return false;
    if (dateRangeEnd && date > dateRangeEnd) return false;
    return true;
  });

  const displayDates = (dateRangeStart || dateRangeEnd) ? filteredDates : sortedDates.slice(0, 5);


  // Group by Cashier for Cashier-wise Summary
  const cashierSummaryMap = new Map<string, { turnover: number; upi: number; cash: number; count: number }>();
  cashiers.forEach((c) => {
    cashierSummaryMap.set(c.name, { turnover: 0, upi: 0, cash: 0, count: 0 });
  });

  const activeSummaryDate = selectedDateFilter === 'ALL' ? currentDate : selectedDateFilter;

  ledger.forEach((item) => {
    const rowDate = item.saleDate.split(' ')[0] || item.saleDate;
    
    let inRange = false;
    if (cashierDateRangeStart || cashierDateRangeEnd) {
      inRange = true;
      if (cashierDateRangeStart && rowDate < cashierDateRangeStart) inRange = false;
      if (cashierDateRangeEnd && rowDate > cashierDateRangeEnd) inRange = false;
    } else {
      inRange = (rowDate === activeSummaryDate);
    }

    if (inRange) {
      const cName = item.cashierName || 'Subrata Roy';
      const existing = cashierSummaryMap.get(cName) || { turnover: 0, upi: 0, cash: 0, count: 0 };
      existing.turnover += item.lineTotal;
      if (item.paymentMode === 'UPI') existing.upi += item.lineTotal;
      if (item.paymentMode === 'CASH') existing.cash += item.lineTotal;
      existing.count += 1;
      cashierSummaryMap.set(cName, existing);
    }
  });

  const getInvoiceTotal = (invoiceNo: string) => {
    return ledger.filter((r) => r.invoiceNo === invoiceNo).reduce((sum, r) => sum + r.lineTotal, 0);
  };

  const handleExport = () => {
    exportLedgerToCsv(ledger, societyName);
  };

  const handleInspectInvoice = (invoiceNo: string) => {
    const matchingRows = ledger.filter((r) => r.invoiceNo === invoiceNo);
    if (matchingRows.length === 0) return;

    const first = matchingRows[0];
    const total = matchingRows.reduce((sum, r) => sum + r.lineTotal, 0);

    const inv: CompleteInvoice = {
      saleId: first.saleId,
      invoiceNo: first.invoiceNo,
      saleDate: first.saleDate,
      customerName: first.customerName,
      paymentMode: first.paymentMode,
      items: matchingRows.map((r) => ({
        productId: r.productId,
        productName: r.productName,
        barcode: r.barcode,
        quantity: r.quantity,
        unitType: r.unitType,
        sellingPrice: r.sellingPrice,
        lineTotal: r.lineTotal,
      })),
      subtotal: total,
      discount: 0,
      grandTotal: total,
      cashier: (first as any).cashierName || 'Subrata Roy (Staff #402)',
      tenderedCash: first.paymentMode === 'CASH' ? total : undefined,
      changeDue: 0,
    };

    onViewInvoice(inv);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 space-y-4">
      {/* ========================================================= */}
      {/* PRIORITY SECTION: CURRENT DATE SUMMARY (TODAY)            */}
      {/* ========================================================= */}
      <div className="bg-gradient-to-br from-slate-900 to-slate-950 text-white rounded-2xl p-5 sm:p-6 shadow-xl border border-slate-800 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800 relative z-10">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-bold rounded-full text-[10px] flex items-center gap-1 font-mono-code">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                CURRENT DATE PRIORITY SUMMARY
              </span>
              <span className="text-slate-400 text-[10px] font-mono-code flex items-center gap-1">
                <Calendar className="w-3 h-3 text-amber-400" />
                {currentDate}
              </span>
            </div>
            <h2 className="text-lg sm:text-xl font-black tracking-tight text-white mt-1">
              Today's Live Business Performance
            </h2>
            <p className="text-[9px] text-slate-400 mt-0.5">
              Real-time turnover and cashier activity for the current business date.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExport}
              className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-[10px] font-bold flex items-center gap-1.5 shadow-lg transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        {/* Today's Metrics Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-4 relative z-10">
          <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-xl shadow-inner">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Today's Total Turnover
            </span>
            <div className="text-xl font-black text-emerald-400 mt-1 font-mono-code">
              ₹{todayTurnover.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </div>
            <p className="text-[10px] text-slate-400 mt-0.5">
              {todayInvoiceCount} Invoices
            </p>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-xl shadow-inner">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1 text-emerald-300">
              <QrCode className="w-3 h-3" />
              UPI / Online
            </span>
            <div className="text-lg font-extrabold text-emerald-200 mt-1 font-mono-code">
              ₹{todayUpi.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </div>
            <p className="text-[10px] text-slate-400 mt-0.5">Bank deposit</p>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-xl shadow-inner">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1 text-amber-300">
              <Banknote className="w-3 h-3" />
              Cash In Hand
            </span>
            <div className="text-lg font-extrabold text-amber-200 mt-1 font-mono-code">
              ₹{todayCash.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </div>
            <p className="text-[10px] text-slate-400 mt-0.5">Physical drawer</p>
          </div>
        </div>
      </div>

      {/* ========================================================= */}
      {/* DAY-WISE & CASHIER-WISE ANALYTICS CARDS                     */}
      {/* ========================================================= */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Day-wise Summary Table */}
        <div className="lg:col-span-6 bg-white rounded-2xl border border-slate-200 shadow-sm p-4 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-200">
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-emerald-600" />
              <h3 className="font-extrabold text-base text-slate-900">Day-wise Summary</h3>
            </div>
            <span className="text-xs text-slate-500 font-semibold">
              {displayDates.length} Business Days
            </span>
          </div>

          <div className="flex items-center gap-2 text-[10px] pb-1">
            <input
              type="date"
              value={dateRangeStart}
              onChange={(e) => setDateRangeStart(e.target.value)}
              className="border border-slate-300 rounded px-1.5 py-0.5"
            />
            <span className="text-slate-400">to</span>
            <input
              type="date"
              value={dateRangeEnd}
              onChange={(e) => setDateRangeEnd(e.target.value)}
              className="border border-slate-300 rounded px-1.5 py-0.5"
            />
          </div>

          <div className="overflow-x-auto max-h-64">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 text-slate-700 font-bold uppercase tracking-wider font-mono-code">
                <tr>
                  <th className="py-1.5 px-2">Date</th>
                  <th className="py-1.5 px-2 text-right">Turnover</th>
                  <th className="py-1.5 px-2 text-right">UPI</th>
                  <th className="py-1.5 px-2 text-right">Cash</th>
                  <th className="py-1.5 px-2 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono-code">
                {displayDates.map((dateStr) => {
                  const metrics = daySummaryMap.get(dateStr)!;
                  return (
                    <tr key={dateStr} className={`hover:bg-slate-50 ${dateStr === currentDate ? 'bg-emerald-50/60 font-bold' : ''}`}>
                      <td className="py-1.5 px-2 text-slate-900 flex items-center gap-1">
                        {dateStr === currentDate && <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>}
                        {dateStr}
                      </td>
                      <td className="py-1.5 px-2 text-right font-extrabold text-emerald-800">
                        ₹{metrics.turnover.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="py-1.5 px-2 text-right text-slate-600 text-[10px]">
                        ₹{metrics.upi.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="py-1.5 px-2 text-right text-slate-600 text-[10px]">
                        ₹{metrics.cash.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="py-1.5 px-2 text-center">
                        <button
                          onClick={() => setSelectedDateFilter(dateStr)}
                          className="px-2 py-1 bg-slate-900 text-white rounded text-[10px] font-bold hover:bg-emerald-700 transition-colors"
                        >
                          Filter
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Cashier-wise Summary Table */}
        <div className="lg:col-span-6 bg-white rounded-2xl border border-slate-200 shadow-sm p-4 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-200">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-emerald-600" />
              <div>
                <h3 className="font-extrabold text-base text-slate-900">
                  { (cashierDateRangeStart || cashierDateRangeEnd) ? 'Cashier-wise Range Summary' : "Cashier-wise Today's Summary" }
                </h3>
                <p className="text-[10px] text-slate-400 font-mono-code">
                  { (cashierDateRangeStart || cashierDateRangeEnd) ? `${cashierDateRangeStart || '...'} to ${cashierDateRangeEnd || '...'}` : activeSummaryDate }
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-[10px]">
              <input
                type="date"
                value={cashierDateRangeStart}
                onChange={(e) => setCashierDateRangeStart(e.target.value)}
                className="border border-slate-300 rounded px-1.5 py-0.5"
              />
              <span className="text-slate-400">to</span>
              <input
                type="date"
                value={cashierDateRangeEnd}
                onChange={(e) => setCashierDateRangeEnd(e.target.value)}
                className="border border-slate-300 rounded px-1.5 py-0.5"
              />
            </div>
          </div>

          <div className="overflow-x-auto max-h-64">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 text-slate-700 font-bold uppercase tracking-wider font-mono-code">
                <tr>
                  <th className="py-2.5 px-3">Cashier Name</th>
                  <th className="py-2.5 px-3 text-right">Total Sales</th>
                  <th className="py-2.5 px-3 text-right">UPI</th>
                  <th className="py-2.5 px-3 text-right">Cash</th>
                  <th className="py-2.5 px-3 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono-code">
                {cashiers.map((c) => {
                  const data = cashierSummaryMap.get(c.name) || { turnover: 0, upi: 0, cash: 0, count: 0 };
                  return (
                    <tr key={c.staffCode} className="hover:bg-slate-50">
                      <td className="py-2 px-3 font-sans font-bold text-slate-900">
                        {c.name} <span className="text-[10px] font-mono-code text-slate-500">({c.staffCode})</span>
                      </td>
                      <td className="py-2 px-3 text-right font-extrabold text-emerald-800">
                        ₹{data.turnover.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="py-2 px-3 text-right text-slate-600">
                        ₹{data.upi.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="py-2 px-3 text-right text-slate-600">
                        ₹{data.cash.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="py-2 px-3 text-center">
                        <button
                          onClick={() => setSelectedCashierFilter(c.name)}
                          className="px-2 py-1 bg-slate-900 text-white rounded text-[10px] font-bold hover:bg-emerald-700 transition-colors"
                        >
                          Filter
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* ========================================================= */}
      {/* DETAILED TRANSACTIONS LEDGER TABLE                        */}
      {/* ========================================================= */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex flex-col md:flex-row items-center justify-between gap-3">
          <div>
            <h3 className="font-extrabold text-lg text-slate-900">
              Detailed Transaction Ledger
            </h3>
            <div className="flex items-center gap-4 mt-1">
              <p className="text-xs text-slate-500">
                Filtered by Date: <strong className="text-slate-800">{selectedDateFilter}</strong> | Cashier: <strong className="text-slate-800">{selectedCashierFilter}</strong>
              </p>
              <div className="bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-lg">
                <span className="text-[10px] font-bold text-emerald-800 uppercase">Filtered Total:</span>
                <span className="text-sm font-black text-emerald-900 ml-2 font-mono-code">
                  ₹{getFilteredLedgerTotal().toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {(selectedDateFilter !== currentDate || selectedCashierFilter !== 'ALL' || dateRangeStart || dateRangeEnd || cashierDateRangeStart || cashierDateRangeEnd) && (
              <button
                onClick={handleClearFilters}
                className="px-2 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-lg text-[10px] font-bold"
              >
                Clear Filters (Today)
              </button>
            )}
          </div>
        </div>

        {/* Search & Filters Bar */}
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search invoice no, member, item name..."
              className="w-full pl-9 pr-4 py-2 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
            />
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-500 font-bold">Date Filter:</span>
            <select
              value={selectedDateFilter}
              onChange={(e) => setSelectedDateFilter(e.target.value)}
              className="bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 font-mono-code font-bold text-slate-800"
            >
              <option value="ALL">All Dates (Chronological)</option>
              {datesSet.map((d) => (
                <option key={d} value={d}>
                  {d} {d === currentDate ? '(Today - Priority)' : ''}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono-code">
            <thead className="bg-slate-100 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider font-sans text-[10px]">
              <tr>
                <th className="py-2 px-2">Invoice No</th>
                <th className="py-2 px-2">Date / Time</th>
                <th className="py-2 px-2">Cashier</th>
                <th className="py-2 px-2">Customer / Member</th>
                <th className="py-2 px-2 text-center">Mode</th>
                <th className="py-2 px-2">Product Name</th>
                <th className="py-2 px-2 text-right">Qty</th>
                <th className="py-2 px-2 text-right">Total</th>
                <th className="py-2 px-2 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredLedger.map((row) => (
                <tr key={row.saleItemId} className="hover:bg-slate-50 transition-colors">
                  <td className="py-1.5 px-2 font-bold text-slate-900">{row.invoiceNo}</td>
                  <td className="py-1.5 px-2 text-slate-500 whitespace-nowrap">{row.saleDate}</td>
                  <td className="py-1.5 px-2 text-slate-700 font-sans">{row.cashierName || 'Subrata Roy'}</td>
                  <td className="py-1.5 px-2 font-sans font-medium text-slate-800 max-w-[120px] truncate">
                    {row.customerName}
                  </td>
                  <td className="py-1.5 px-2 text-center">
                    <span
                      className={`inline-block px-1.5 py-0.5 rounded text-[9px] font-bold ${
                        row.paymentMode === 'UPI'
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          : 'bg-amber-100 text-amber-800 border border-amber-300'
                      }`}
                    >
                      {row.paymentMode}
                    </span>
                  </td>
                  <td className="py-1.5 px-2 font-sans font-semibold text-slate-900 max-w-[150px] truncate">
                    {row.productName}
                  </td>
                  <td className="py-1.5 px-2 text-right font-bold text-slate-700">
                    {row.quantity.toFixed(3)}
                  </td>
                  <td className="py-1.5 px-2 text-right font-extrabold text-emerald-800">
                    ₹{row.lineTotal.toFixed(2)}
                  </td>
                  <td className="py-1.5 px-2 text-center">
                    <button
                      onClick={() => handleInspectInvoice(row.invoiceNo)}
                      className="p-1 rounded hover:bg-slate-200 text-slate-600 hover:text-slate-900"
                      title="View Invoice"
                    >
                      <Receipt className="w-3 h-3 text-emerald-600" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredLedger.length === 0 && (
          <div className="p-12 text-center text-slate-400 text-xs">
            No transactions match the selected day and cashier filter.
          </div>
        )}
      </div>
    </div>
  );
};
