import React, { useState } from 'react';
import {
  Search,
  Plus,
  Minus,
  Trash2,
  QrCode,
  Banknote,
  ShoppingCart,
  Tag,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  Barcode as BarcodeIcon,
  Check,
  Package,
  ShieldAlert
} from 'lucide-react';
import { Product, CartItem, SocietyProfile, AdminStoreSettings, LoosePacket } from '../types';
import { CATEGORIES } from '../data/initialData';
import { playScannerBeep } from '../utils/audio';
import { getProductImage, getDefaultCategoryImage } from '../utils/productImages';
import { parseLooseBarcode, formatQuantityWithSubunit } from '../utils/looseBarcode';
import { Scale, X as CloseIcon } from 'lucide-react';

interface PosTerminalProps {
  products: Product[];
  cart: CartItem[];
  loosePackets?: LoosePacket[];
  addToCart: (product: Product, quantity?: number, packetBarcode?: string) => void;
  updateQuantity: (productId: number, qty: number) => void;
  removeFromCart: (productId: number) => void;
  clearCart: () => void;
  onOpenScanner: () => void;
  onOpenWeighingStation?: () => void;
  onOpenProductQr: (product: Product) => void;
  onProceedToPayment: (mode: 'UPI' | 'CASH') => void;
  selectedCustomer: string;
  setSelectedCustomer: (cust: string) => void;
  society: SocietyProfile;
  adminSettings?: AdminStoreSettings;
  categories?: string[];
}

export const PosTerminal: React.FC<PosTerminalProps> = ({
  products,
  cart,
  loosePackets,
  addToCart,
  updateQuantity,
  removeFromCart,
  clearCart,
  onOpenScanner,
  onOpenWeighingStation,
  onOpenProductQr,
  onProceedToPayment,
  selectedCustomer,
  setSelectedCustomer,
  society,
  adminSettings,
  categories,
}) => {
  const [selectedCategory, setSelectedCategory] = useState('All Items');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLooseProduct, setSelectedLooseProduct] = useState<Product | null>(null);
  const [customLooseGramInput, setCustomLooseGramInput] = useState<string>('250');
  const [searchWarning, setSearchWarning] = useState<string | null>(null);

  // Handle barcode search / scan input change
  const handleSearchChange = (val: string) => {
    setSearchQuery(val);
    if (val.trim()) {
      const looseResult = parseLooseBarcode(val.trim(), products, loosePackets);
      if (looseResult) {
        if (looseResult.alreadySold) {
          setSearchWarning(looseResult.alreadySoldInfo || `⚠️ Package #${val.trim()} was ALREADY SOLD!`);
          setTimeout(() => setSearchWarning(null), 4000);
          return;
        }

        playScannerBeep();
        addToCart(looseResult.product, looseResult.quantityInBaseUnit, looseResult.packet?.uniqueBarcode);
        setSearchQuery('');
      }
    }
  };

  // Helper to add loose quantity (e.g. 250 grams -> 0.25 KG)
  const addLooseQuantityToCart = (product: Product, gramsOrMl: number) => {
    let qtyInBaseUnit = 1;
    if (product.unit === 'KG' || product.unit === 'LTR') {
      qtyInBaseUnit = gramsOrMl / 1000;
    } else if (product.unit === 'GM' || product.unit === 'ML') {
      qtyInBaseUnit = gramsOrMl;
    }
    playScannerBeep();
    addToCart(product, qtyInBaseUnit);
    setSelectedLooseProduct(null);
  };

  // Filter products
  const filteredProducts = products.filter((item) => {
    const matchesCategory =
      selectedCategory === 'All Items' || item.category === selectedCategory;
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      item.name.toLowerCase().includes(q) ||
      item.barcode.includes(q) ||
      item.id.toString() === q ||
      item.category.toLowerCase().includes(q);
    return matchesCategory && matchesSearch;
  });

  // Calculate totals
  const subtotal = cart.reduce((sum, item) => sum + item.lineTotal, 0);
  const grandTotal = subtotal;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
      {/* Admin Halt Warning Banner if active */}
      {adminSettings && !adminSettings.transactionsEnabled && (
        <div className="mb-5 p-4 bg-rose-50 border-2 border-rose-500 rounded-2xl flex items-center justify-between gap-3 text-rose-900 shadow-sm animate-fadeIn">
          <div className="flex items-center gap-3">
            <ShieldAlert className="w-6 h-6 text-rose-600 flex-shrink-0" />
            <div>
              <h4 className="font-extrabold text-sm">Store Transactions are Currently STOPPED by Admin</h4>
              <p className="text-xs text-rose-700 mt-0.5">
                {adminSettings.haltReason || 'Billing has been temporarily paused by Administration. Cashiers cannot finalize sales.'}
              </p>
            </div>
          </div>
          <span className="text-xs font-mono-code font-bold bg-rose-200 px-2.5 py-1 rounded-lg">
            HALT ACTIVE
          </span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Product Catalog & Search (7 cols on lg) */}
        <div className="lg:col-span-7 xl:col-span-8 space-y-4">
          {/* Top Search & Filter Bar */}
          <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 space-y-3">
            {searchWarning && (
              <div className="p-3 bg-amber-50 border border-amber-300 rounded-xl text-xs font-bold text-amber-900 flex items-center gap-2 animate-fadeIn">
                <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0" />
                <span>{searchWarning}</span>
              </div>
            )}

            <div className="flex flex-col sm:flex-row items-center gap-3">
              <div className="relative flex-1 w-full">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => handleSearchChange(e.target.value)}
                  placeholder="Search products by name, barcode (e.g. 890100...), or SKU..."
                  className="w-full pl-10 pr-4 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600"
                  >
                    Clear
                  </button>
                )}
              </div>

              {/* Action Buttons: Weighing Station & Scanner */}
              <div className="flex items-center gap-2 flex-shrink-0 w-full sm:w-auto">
                {onOpenWeighingStation && (
                  <button
                    onClick={onOpenWeighingStation}
                    className="flex-1 sm:flex-initial px-3.5 py-2.5 bg-amber-50 hover:bg-amber-100 text-amber-950 border border-amber-300 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all shadow-xs"
                    title="Open Loose Item Weighing & Package Barcode Station"
                  >
                    <Scale className="w-4 h-4 text-amber-600" />
                    <span>Weigh & Print Pack Barcode</span>
                  </button>
                )}

                <button
                  onClick={onOpenScanner}
                  className="flex-1 sm:flex-initial px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all shadow hover:shadow-md"
                >
                  <BarcodeIcon className="w-4 h-4 text-emerald-400" />
                  <span>Open Scanner</span>
                </button>
              </div>
            </div>

            {/* Category Filter Pills (Functional Buttons) */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
              {(categories || CATEGORIES).map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
                    selectedCategory === cat
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Product Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3.5">
            {filteredProducts.map((product) => {
              const inStock = product.stock > 0;
              const isLowStock = product.stock <= product.minStockLevel && inStock;
              const cartItem = cart.find((c) => c.product.id === product.id);
              const isLoose = ['KG', 'LTR', 'GM', 'ML'].includes(product.unit);

              return (
                <div
                  key={product.id}
                  className={`bg-white rounded-2xl border transition-all duration-200 overflow-hidden flex flex-col justify-between hover:shadow-md ${
                    cartItem
                      ? 'border-emerald-500 ring-2 ring-emerald-500/20'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  {/* Image & Badges */}
                  <div className="relative h-36 bg-slate-100 overflow-hidden">
                    <img
                      src={getProductImage(product)}
                      alt={product.name}
                      className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                      loading="lazy"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = getDefaultCategoryImage(product.category);
                      }}
                    />
                    {/* Stock available badge */}
                    <div className="absolute top-2.5 left-2.5">
                      <span
                        className={`text-[11px] font-mono-code font-bold px-2 py-0.5 rounded shadow-sm ${
                          !inStock
                            ? 'bg-rose-600 text-white'
                            : isLowStock
                            ? 'bg-amber-500 text-slate-950 font-bold'
                            : 'bg-emerald-700/90 text-white'
                        }`}
                      >
                        {!inStock
                          ? 'Out of Stock'
                          : `${product.stock} ${product.unit} Available`}
                      </span>
                    </div>

                    {/* QR Code Tag Button */}
                    <button
                      onClick={() => onOpenProductQr(product)}
                      className="absolute top-2.5 right-2.5 p-1.5 bg-black/60 hover:bg-black/80 text-white rounded-lg backdrop-blur-sm transition-colors"
                      title="View Shelf QR Tag"
                    >
                      <QrCode className="w-3.5 h-3.5 text-emerald-300" />
                    </button>
                  </div>

                  {/* Body */}
                  <div className="p-3.5 flex-1 flex flex-col justify-between">
                    <div>
                      {/* Quiet metadata line */}
                      <div className="flex items-center gap-1.5 text-[11px] text-slate-500 font-mono-code">
                        <span>SKU: {product.id}</span>
                        <span>·</span>
                        <span>{product.barcode}</span>
                      </div>

                      <h4 className="font-bold text-sm text-slate-900 mt-1 leading-snug line-clamp-1">
                        {product.name}
                      </h4>

                      <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                        {product.description || product.category}
                      </p>
                    </div>

                    {/* Pricing & Add to Cart button */}
                    <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between gap-1.5">
                      <div>
                        <div className="text-base font-extrabold text-slate-900 font-mono-code">
                          ₹{product.sellingPrice.toFixed(2)}
                        </div>
                        <div className="text-[10px] text-slate-500">per {product.unit}</div>
                      </div>

                      <div className="flex items-center gap-1">
                        {isLoose && inStock && (
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedLooseProduct(product);
                              setCustomLooseGramInput('250');
                            }}
                            className="px-2 py-1.5 rounded-lg text-xs font-bold bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 flex items-center gap-1 transition-all"
                            title="Select Loose Packet Weight/Volume (Grams / ML)"
                          >
                            <Scale className="w-3.5 h-3.5 text-amber-700" />
                            <span>Loose Wt</span>
                          </button>
                        )}

                        {cartItem ? (
                          <div className="flex items-center border border-emerald-500 rounded-lg bg-emerald-50 overflow-hidden">
                            <button
                              onClick={() => updateQuantity(product.id, cartItem.quantity - 1)}
                              className="px-2 py-1 text-emerald-800 hover:bg-emerald-100 font-bold text-xs"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="px-2 text-xs font-bold text-emerald-900 font-mono-code">
                              {formatQuantityWithSubunit(cartItem.quantity, product.unit)}
                            </span>
                            <button
                              onClick={() => {
                                if (cartItem.quantity < product.stock) {
                                  updateQuantity(product.id, cartItem.quantity + 1);
                                }
                              }}
                              disabled={cartItem.quantity >= product.stock}
                              className="px-2 py-1 text-emerald-800 hover:bg-emerald-100 font-bold text-xs disabled:opacity-30"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => {
                              addToCart(product);
                              playScannerBeep();
                            }}
                            disabled={!inStock}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                              inStock
                                ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-sm'
                                : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                            }`}
                          >
                            <Plus className="w-3.5 h-3.5" />
                            <span>Add</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {filteredProducts.length === 0 && (
            <div className="p-12 text-center bg-white rounded-2xl border border-slate-200">
              <Package className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h4 className="font-bold text-slate-700">No products match your search</h4>
              <p className="text-xs text-slate-500 mt-1">
                Try searching with a different term or clear the category filter.
              </p>
            </div>
          )}
        </div>

        {/* Right Column: Billing & Cart Drawer (5 cols on lg) */}
        <div className="lg:col-span-5 xl:col-span-4 sticky top-20">
          <div className="bg-white rounded-2xl shadow-lg border border-slate-200 overflow-hidden flex flex-col">
            {/* Cart Header */}
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShoppingCart className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-sm">Active Sales Bill</h3>
              </div>
              <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono-code border border-emerald-500/30">
                {cart.length} {cart.length === 1 ? 'item' : 'items'}
              </span>
            </div>

            {/* Customer selector bar */}
            <div className="p-3 bg-slate-50 border-b border-slate-200 space-y-1.5">
              <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block">
                Billing Customer:
              </label>
              <input
                type="text"
                value={selectedCustomer}
                onChange={(e) => setSelectedCustomer(e.target.value)}
                placeholder="e.g. Walk-in Customer or Customer Name"
                className="w-full text-xs font-semibold bg-white border border-slate-300 rounded-lg p-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {/* Cart Items List */}
            <div className="p-3 max-h-[340px] overflow-y-auto divide-y divide-slate-100 flex-1">
              {cart.length === 0 ? (
                <div className="py-12 text-center text-slate-400">
                  <ShoppingCart className="w-10 h-10 mx-auto mb-2 text-slate-300 opacity-60" />
                  <p className="text-xs font-medium text-slate-600">Cart is empty</p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Scan a product QR/barcode or select items from catalog to start billing.
                  </p>
                </div>
              ) : (
                cart.map((item) => (
                  <div key={item.product.id} className="py-2.5 flex items-center justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <h5 className="font-bold text-xs text-slate-900 truncate">
                        {item.product.name}
                      </h5>
                      <div className="text-[10px] text-slate-500 font-mono-code flex items-center gap-1.5">
                        <span>₹{item.sellingPrice.toFixed(2)}</span>
                        <span>×</span>
                        <span className="font-bold text-emerald-800">
                          {formatQuantityWithSubunit(item.quantity, item.product.unit)}
                        </span>
                      </div>
                    </div>

                    {/* Qty controls */}
                    <div className="flex items-center gap-1">
                      <div className="flex items-center border border-slate-200 rounded-lg bg-slate-50">
                        <button
                          onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                          className="px-1.5 py-0.5 text-slate-600 hover:bg-slate-200 text-xs font-bold"
                        >
                          -
                        </button>
                        <span className="px-2 text-xs font-bold text-slate-800 font-mono-code">
                          {formatQuantityWithSubunit(item.quantity, item.product.unit)}
                        </span>
                        <button
                          onClick={() => {
                            if (item.quantity < item.product.stock) {
                              updateQuantity(item.product.id, item.quantity + 1);
                            }
                          }}
                          disabled={item.quantity >= item.product.stock}
                          className="px-1.5 py-0.5 text-slate-600 hover:bg-slate-200 text-xs font-bold disabled:opacity-30"
                        >
                          +
                        </button>
                      </div>

                      <div className="text-right min-w-[65px]">
                        <span className="font-mono-code font-bold text-xs text-slate-900">
                          ₹{item.lineTotal.toFixed(2)}
                        </span>
                      </div>

                      <button
                        onClick={() => removeFromCart(item.product.id)}
                        className="text-slate-400 hover:text-rose-600 p-1"
                        title="Remove"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Bill Summary & Total */}
            {cart.length > 0 && (
              <div className="p-4 bg-slate-50 border-t border-slate-200 space-y-2">
                <div className="flex justify-between items-baseline border-b border-slate-200 pb-2">
                  <span className="font-extrabold text-sm text-slate-900">Net Payable:</span>
                  <span className="text-2xl font-extrabold text-emerald-700 font-mono-code">
                    ₹{grandTotal.toFixed(2)}
                  </span>
                </div>

                {/* Primary Payment Buttons: ONLINE (QR Code) & I CASH */}
                {adminSettings && !adminSettings.transactionsEnabled ? (
                  <div className="pt-2 p-3 bg-rose-50 border border-rose-300 rounded-xl text-xs text-rose-800 space-y-1 text-center">
                    <div className="font-bold flex items-center justify-center gap-1.5 text-rose-900">
                      <ShieldAlert className="w-4 h-4 text-rose-600 flex-shrink-0" />
                      <span>Billing Stopped by Admin</span>
                    </div>
                    <p className="text-[11px] text-rose-700">
                      {adminSettings.haltReason || 'Transactions are currently blocked by Society Administration.'}
                    </p>
                  </div>
                ) : (
                  <div className="pt-2 space-y-2">
                    <button
                      onClick={() => onProceedToPayment('UPI')}
                      disabled={adminSettings && !adminSettings.upiPaymentsEnabled}
                      className={`w-full py-3 px-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2 shadow-md transition-all ${
                        adminSettings && !adminSettings.upiPaymentsEnabled
                          ? 'bg-slate-300 text-slate-500 cursor-not-allowed'
                          : 'bg-emerald-600 hover:bg-emerald-500 text-white hover:scale-[1.01] active:scale-[0.99]'
                      }`}
                    >
                      <QrCode className="w-4 h-4 text-emerald-200" />
                      <span>
                        {adminSettings && !adminSettings.upiPaymentsEnabled
                          ? 'Online QR Paused by Admin'
                          : 'Pay with Online (QR Code only)'}
                      </span>
                    </button>

                    <button
                      onClick={() => onProceedToPayment('CASH')}
                      disabled={adminSettings && !adminSettings.cashPaymentsEnabled}
                      className={`w-full py-2.5 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-colors ${
                        adminSettings && !adminSettings.cashPaymentsEnabled
                          ? 'bg-slate-300 text-slate-500 cursor-not-allowed'
                          : 'bg-slate-900 hover:bg-slate-800 text-white'
                      }`}
                    >
                      <Banknote className="w-4 h-4 text-amber-400" />
                      <span>
                        {adminSettings && !adminSettings.cashPaymentsEnabled
                          ? 'Cash Payments Paused by Admin'
                          : 'Pay with I Cash (Cash Transaction)'}
                      </span>
                    </button>
                  </div>
                )}

                <div className="pt-2 flex items-center justify-between">
                  <button
                    onClick={clearCart}
                    className="text-xs text-slate-400 hover:text-rose-600 flex items-center gap-1"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Clear Cart</span>
                  </button>
                  <span className="text-[10px] text-slate-400">{society.counterId}</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Loose Weight / Volume Packet Selector Modal */}
      {selectedLooseProduct && (
        <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl border border-slate-200 space-y-4 animate-fadeIn">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <Scale className="w-5 h-5 text-amber-600" />
                <div>
                  <h4 className="font-extrabold text-sm text-slate-900">
                    Select Loose Package Weight / Volume
                  </h4>
                  <p className="text-[11px] text-slate-500">{selectedLooseProduct.name}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedLooseProduct(null)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <CloseIcon className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 flex items-center justify-between text-xs text-amber-900 font-mono-code">
              <span>Unit Rate:</span>
              <strong className="text-sm text-slate-900 font-extrabold">
                ₹{selectedLooseProduct.sellingPrice.toFixed(2)} / {selectedLooseProduct.unit}
              </strong>
            </div>

            {/* Preset Buttons */}
            <div className="space-y-2">
              <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block">
                Quick Pack Presets:
              </label>
              <div className="grid grid-cols-3 gap-2 text-xs">
                {(selectedLooseProduct.unit === 'LTR' || selectedLooseProduct.unit === 'ML'
                  ? [100, 250, 500, 750, 1000]
                  : [100, 250, 500, 750, 1000]
                ).map((gram) => {
                  const unitLabel =
                    selectedLooseProduct.unit === 'LTR' || selectedLooseProduct.unit === 'ML'
                      ? gram >= 1000
                        ? '1 LTR'
                        : `${gram} ML`
                      : gram >= 1000
                      ? '1 KG'
                      : `${gram} GM`;
                  const calcPrice =
                    selectedLooseProduct.unit === 'KG' || selectedLooseProduct.unit === 'LTR'
                      ? (selectedLooseProduct.sellingPrice * gram) / 1000
                      : selectedLooseProduct.sellingPrice * gram;

                  return (
                    <button
                      key={gram}
                      type="button"
                      onClick={() => addLooseQuantityToCart(selectedLooseProduct, gram)}
                      className="p-2.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-emerald-50 hover:border-emerald-500 transition-all flex flex-col items-center justify-center font-mono-code text-center group"
                    >
                      <span className="font-extrabold text-slate-900 group-hover:text-emerald-700">
                        {unitLabel}
                      </span>
                      <span className="text-[10px] text-slate-500 group-hover:text-emerald-800 font-semibold">
                        ₹{calcPrice.toFixed(2)}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Custom Input */}
            <div className="pt-2 border-t border-slate-200 space-y-2">
              <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block">
                Or Custom Amount ({selectedLooseProduct.unit === 'LTR' || selectedLooseProduct.unit === 'ML' ? 'ML' : 'Grams'}):
              </label>
              <div className="flex gap-2">
                <input
                  type="number"
                  value={customLooseGramInput}
                  onChange={(e) => setCustomLooseGramInput(e.target.value)}
                  placeholder="e.g. 350"
                  className="flex-1 px-3 py-2 text-xs font-mono-code font-bold bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <button
                  type="button"
                  onClick={() => {
                    const num = parseFloat(customLooseGramInput);
                    if (!isNaN(num) && num > 0) {
                      addLooseQuantityToCart(selectedLooseProduct, num);
                    }
                  }}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow transition-colors"
                >
                  Add Custom Wt
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

