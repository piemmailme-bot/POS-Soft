import React from 'react';
import {
  Download,
  ShieldCheck,
  X,
  FileArchive,
  Database,
  CloudLightning,
  Info,
  Server,
  Terminal
} from 'lucide-react';

interface BackupModalProps {
  isOpen: boolean;
  onClose: () => void;
  societyName: string;
}

export const BackupModal: React.FC<BackupModalProps> = ({ isOpen, onClose, societyName }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col animate-fadeIn">
        {/* Header */}
        <div className="px-6 py-5 bg-slate-900 text-white flex items-center justify-between relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl -mr-16 -mt-16 pointer-events-none"></div>
          <div className="flex items-center gap-3 relative z-10">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Server className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-black text-lg tracking-tight">System Backup Center</h3>
              <p className="text-xs text-slate-400 font-medium">Export Full Application Code & Data</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-xl hover:bg-slate-800 transition-colors relative z-10"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-8 space-y-6">
          <div className="text-center space-y-2">
            <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-2 border border-slate-200">
              <FileArchive className="w-8 h-8 text-slate-600" />
            </div>
            <h4 className="text-xl font-bold text-slate-900">Download Full Archive</h4>
            <p className="text-sm text-slate-500 max-w-sm mx-auto">
              Prepare to download a complete snapshot of the **{societyName}** POS system. This includes all React components, assets, and a **MySQL-compatible backend database export**.
            </p>
          </div>

          {/* Backup Details Grid */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Format</span>
              <div className="flex items-center gap-1.5 font-bold text-slate-700 text-sm">
                <Terminal className="w-3.5 h-3.5 text-emerald-600" />
                <span>TAR.GZ (Compressed)</span>
              </div>
            </div>
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Database</span>
              <div className="flex items-center gap-1.5 font-bold text-slate-700 text-sm">
                <Database className="w-3.5 h-3.5 text-blue-600" />
                <span>MySQL (.sql) Export</span>
              </div>
            </div>
          </div>

          {/* Info Box */}
          <div className="bg-amber-50 border border-amber-200 p-4 rounded-2xl flex items-start gap-3">
            <Info className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h5 className="text-xs font-bold text-amber-900">Separate Deployment Ready</h5>
              <p className="text-[11px] text-amber-800/80 leading-relaxed">
                This backup is compatible with any Node.js environment. To restore, extract the file and run <code>npm install</code> followed by <code>npm run dev</code>.
              </p>
            </div>
          </div>

          {/* Download Button */}
          <div className="pt-2">
            <a
              href="/project_backup.tar.gz"
              download="nabkul_pos_full_system_backup.tar.gz"
              className="w-full py-4 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl font-black text-base flex items-center justify-center gap-3 shadow-xl transition-all hover:scale-[1.01] active:scale-[0.99] group"
              onClick={() => {
                // Potential telemetry or audit log call here
              }}
            >
              <Download className="w-5 h-5 text-emerald-400 group-hover:animate-bounce" />
              <span>DOWNLOAD FULL SYSTEM BACKUP</span>
            </a>
            <p className="text-[10px] text-slate-400 text-center mt-3 font-medium uppercase tracking-widest">
              Last generated: {new Date().toLocaleDateString('en-IN')}
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-center gap-2">
          <CloudLightning className="w-3.5 h-3.5 text-emerald-600" />
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-tighter">
            Nabkul Cooperative Society · Secure System Export
          </span>
        </div>
      </div>
    </div>
  );
};
