import React, { useState } from 'react';
import {
  Lock,
  User,
  KeyRound,
  Eye,
  EyeOff,
  ShieldCheck,
  Store,
  ArrowRight,
  AlertCircle,
  Building2,
  ShieldAlert,
  ArrowLeft,
} from 'lucide-react';
import { CashierUser, SocietyProfile, AdminStoreSettings } from '../types';

interface CashierLoginProps {
  cashiers: CashierUser[];
  onLoginSuccess: (cashier: CashierUser, counter: string) => void;
  society: SocietyProfile;
  adminSettings?: AdminStoreSettings;
}

export const CashierLogin: React.FC<CashierLoginProps> = ({
  cashiers,
  onLoginSuccess,
  society,
  adminSettings,
}) => {
  // Mode: default strictly to cashier so admin controls are never exposed to cashiers
  const [loginMode, setLoginMode] = useState<'cashier' | 'admin'>('cashier');
  const [loginId, setLoginId] = useState('');
  const [password, setPassword] = useState('');
  const [selectedCounter, setSelectedCounter] = useState('COUNTER-01 (KOL-NORTH)');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Cashier staff list EXCLUDES system administrators
  const cashierStaffList = cashiers.filter(
    (c) => c.role !== 'System Admin' && c.loginId !== 'admin'
  );

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const user = cashiers.find(
      (c) =>
        c.loginId.toLowerCase() === loginId.trim().toLowerCase() ||
        c.staffCode.toLowerCase() === loginId.trim().toLowerCase()
    );

    if (!user) {
      setErrorMessage(
        loginMode === 'admin'
          ? 'Invalid Administrator ID. Access is restricted to Society Executives.'
          : 'Invalid Staff ID or Code. Please check your cashier credentials.'
      );
      return;
    }

    if (user.isActive === false) {
      setErrorMessage('This cashier account is currently deactivated by the Administrator.');
      return;
    }

    if (user.passwordHash !== password) {
      setErrorMessage(
        loginMode === 'admin'
          ? 'Incorrect Administrator security password / PIN.'
          : 'Incorrect password. Please verify your cashier access PIN.'
      );
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      onLoginSuccess(user, selectedCounter);
      setIsLoading(false);
    }, 350);
  };

  const handleQuickFillCashier = (cashier: CashierUser) => {
    setLoginId(cashier.loginId);
    setPassword(cashier.passwordHash);
    setSelectedCounter(cashier.assignedCounter);
    setErrorMessage(null);
  };

  const switchToAdminPortal = () => {
    setLoginMode('admin');
    setLoginId('');
    setPassword('');
    setSelectedCounter('ADMIN DESK (CENTRAL)');
    setErrorMessage(null);
  };

  const switchToCashierPortal = () => {
    setLoginMode('cashier');
    setLoginId('');
    setPassword('');
    setSelectedCounter('COUNTER-01 (KOL-NORTH)');
    setErrorMessage(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Cooperative Brand Header */}
        <div className="text-center mb-6 space-y-2">
          <div className="inline-flex w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 border-2 border-emerald-400/40 items-center justify-center shadow-xl shadow-emerald-950/60 mb-2">
            <Store className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-black text-white tracking-tight">
            {society.name}
          </h1>
          <p className="text-xs text-emerald-400 font-medium">
            📍 {society.address} · Reg: {society.regNo}
          </p>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800/80 border border-slate-700/80 text-[11px] text-slate-300">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>
              {loginMode === 'admin'
                ? 'Society Secretary & Admin Office'
                : 'Authorized Cashier POS Terminal'}
            </span>
          </div>
        </div>

        {/* Login Card */}
        <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
          {/* Header styling varies if Admin mode is explicitly toggled */}
          {loginMode === 'admin' ? (
            <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <ShieldAlert className="w-5 h-5 text-amber-400" />
                <div>
                  <h3 className="font-bold text-sm text-white">Administrator Portal</h3>
                  <p className="text-[11px] text-slate-400">Cashier registry & security management</p>
                </div>
              </div>
              <button
                type="button"
                onClick={switchToCashierPortal}
                className="text-xs text-slate-400 hover:text-white flex items-center gap-1 bg-slate-800 hover:bg-slate-700 px-2.5 py-1 rounded-lg transition-colors"
              >
                <ArrowLeft className="w-3 h-3" />
                <span>Cashier Login</span>
              </button>
            </div>
          ) : (
            <div className="bg-emerald-800 text-white px-6 py-4 flex items-center justify-between border-b border-emerald-900">
              <div className="flex items-center gap-2.5">
                <Store className="w-5 h-5 text-emerald-200" />
                <div>
                  <h3 className="font-bold text-sm text-white">Cashier Staff Sign In</h3>
                  <p className="text-[11px] text-emerald-200">Point of Sale & Billing Register</p>
                </div>
              </div>
              <span className="text-[10px] font-bold uppercase tracking-wider bg-emerald-900/80 px-2 py-0.5 rounded text-emerald-300 border border-emerald-700/50">
                Counter Staff
              </span>
            </div>
          )}

          <div className="p-6 sm:p-8 space-y-4">
            <div>
              <h2 className="text-lg font-bold text-slate-900">
                {loginMode === 'admin' ? 'Administrator Login' : 'Open POS Register'}
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                {loginMode === 'admin'
                  ? 'Enter administrator credentials to register/manage cashiers and control store transactions'
                  : 'Enter your authorized cashier credentials to start billing customers'}
              </p>
            </div>

            {adminSettings && !adminSettings.transactionsEnabled && (
              <div className="p-2.5 bg-rose-50 border border-rose-300 rounded-xl text-rose-800 text-[11px] font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
                <span>Notice: POS Transactions are currently halted by Administrator ({adminSettings.haltReason || 'Sales on hold'}).</span>
              </div>
            )}

            {errorMessage && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-2.5 text-xs text-rose-800 animate-fadeIn">
                <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0 mt-0.5" />
                <span className="font-medium">{errorMessage}</span>
              </div>
            )}

            <form onSubmit={handleLogin} className="space-y-4">
              {/* Cashier / Admin ID */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  {loginMode === 'admin' ? 'Administrator ID' : 'Cashier ID / Staff Code'}
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={loginId}
                    onChange={(e) => setLoginId(e.target.value)}
                    placeholder={loginMode === 'admin' ? 'e.g. admin' : 'e.g. subrata or priya'}
                    className="w-full pl-10 pr-4 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                    required
                    autoFocus
                  />
                </div>
              </div>

              {/* Password */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  {loginMode === 'admin' ? 'Master Admin Password' : 'Password / Access PIN'}
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder={loginMode === 'admin' ? 'Enter admin password...' : 'Enter your cashier PIN...'}
                    className="w-full pl-10 pr-10 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono-code"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
                    tabIndex={-1}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Counter Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Assigned POS Counter
                </label>
                <select
                  value={selectedCounter}
                  onChange={(e) => setSelectedCounter(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-semibold bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800"
                >
                  <option value="COUNTER-01 (KOL-NORTH)">COUNTER-01 (Kolkata North Store)</option>
                  <option value="COUNTER-02 (KOL-NORTH)">COUNTER-02 (Express Billing)</option>
                  <option value="CENTRAL DESK">CENTRAL DESK (Society Office)</option>
                </select>
              </div>

              {/* Submit */}
              <button
                type="submit"
                disabled={isLoading}
                className={`w-full py-3 active:scale-[0.99] text-white font-bold text-sm rounded-xl flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer ${
                  loginMode === 'admin'
                    ? 'bg-slate-900 hover:bg-slate-800 shadow-slate-950/20'
                    : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-950/20'
                }`}
              >
                {isLoading ? (
                  <span className="flex items-center gap-2">
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                    <span>Verifying Credentials...</span>
                  </span>
                ) : (
                  <>
                    <Lock className="w-4 h-4" />
                    <span>
                      {loginMode === 'admin'
                        ? 'Unlock Administrator Console'
                        : 'Unlock Register & Start Billing'}
                    </span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>

            {/* Quick Demo Cashier Staff Logins (ONLY Cashiers, Admin is NEVER shown here) */}
            {loginMode === 'cashier' && (
              <div className="pt-4 border-t border-slate-200">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-2">
                  Active Cashier Staff (Click to Autofill):
                </span>
                <div className="space-y-1.5">
                  {cashierStaffList.map((cashier) => (
                    <button
                      key={cashier.id}
                      type="button"
                      onClick={() => handleQuickFillCashier(cashier)}
                      className="w-full p-2.5 rounded-xl border border-slate-200 hover:border-emerald-500 hover:bg-emerald-50/50 flex items-center justify-between text-left transition-colors group cursor-pointer"
                    >
                      <div>
                        <div className="text-xs font-bold text-slate-900 group-hover:text-emerald-700">
                          {cashier.name}{' '}
                          <span className="text-[10px] text-slate-400 font-normal">
                            ({cashier.staffCode})
                          </span>
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono-code">
                          Login ID: <strong className="text-slate-700">{cashier.loginId}</strong> · PIN: <strong className="text-slate-700">{cashier.passwordHash}</strong>
                        </div>
                      </div>
                      <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-100/70 px-2 py-0.5 rounded">
                        {cashier.role}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* In Admin Mode: show society admin credential reminder for the administrator */}
            {loginMode === 'admin' && (
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-xs space-y-1">
                <div className="font-bold flex items-center gap-1.5 text-amber-900">
                  <ShieldCheck className="w-4 h-4 text-amber-600" />
                  <span>Authorized Society Executive Credentials:</span>
                </div>
                <div className="text-[11px] font-mono-code text-amber-800">
                  Login ID: <strong>admin</strong> · PIN / Password: <strong>admin@nabkul</strong>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setLoginId('admin');
                    setPassword('admin@nabkul');
                    setSelectedCounter('CENTRAL DESK');
                  }}
                  className="mt-1 text-[11px] font-bold text-amber-800 underline hover:text-amber-950 cursor-pointer block"
                >
                  Autofill Default Administrator Login
                </button>
              </div>
            )}
          </div>

          {/* Footer security banner & discreet Admin Access button */}
          <div className="bg-slate-50 px-6 py-3 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500">
            <span className="flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-emerald-600" />
              <span>Encrypted POS Gateway</span>
            </span>

            {loginMode === 'cashier' ? (
              <button
                type="button"
                onClick={switchToAdminPortal}
                className="text-slate-500 hover:text-slate-900 hover:underline flex items-center gap-1 text-[11px] font-medium transition-colors"
                title="Only authorized society administrators can create or remove cashiers"
              >
                <ShieldAlert className="w-3.5 h-3.5 text-amber-600" />
                <span>Admin Login</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={switchToCashierPortal}
                className="text-emerald-700 hover:text-emerald-900 hover:underline flex items-center gap-1 text-[11px] font-semibold transition-colors"
              >
                <Store className="w-3.5 h-3.5 text-emerald-600" />
                <span>Switch to Cashier Login</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
