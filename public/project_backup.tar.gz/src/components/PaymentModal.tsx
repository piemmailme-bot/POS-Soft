import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import confetti from 'canvas-confetti';
import {
  X,
  QrCode,
  Banknote,
  CheckCircle2,
  Volume2,
  ShieldCheck,
  RotateCcw,
  Sparkles,
  ArrowRight,
  User,
  CreditCard,
  Copy,
  Check
} from 'lucide-react';
import { PaymentMode, CartItem, SocietyProfile } from '../types';
import { playUpiSuccessChime, playCashDrawerSound } from '../utils/audio';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  grandTotal: number;
  discount: number;
  invoiceNo: string;
  selectedCustomer: string;
  setSelectedCustomer: (cust: string) => void;
  society: SocietyProfile;
  onPaymentComplete: (details: {
    paymentMode: PaymentMode;
    customerName: string;
    tenderedCash?: number;
    changeDue?: number;
    upiTxnRef?: string;
  }) => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  cart,
  grandTotal,
  discount,
  invoiceNo,
  selectedCustomer,
  setSelectedCustomer,
  society,
  onPaymentComplete,
}) => {
  const [activeTab, setActiveTab] = useState<'UPI' | 'CASH'>('UPI');
  const [qrViewMode, setQrViewMode] = useState<'phonepe' | 'dynamic'>('phonepe');
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  
  // Cash mode state
  const [tenderedCash, setTenderedCash] = useState<number>(0);
  
  // UPI mode state
  const [upiStatus, setUpiStatus] = useState<'waiting' | 'paid'>('waiting');
  const [upiTxnId, setUpiTxnId] = useState<string>('');
  const [soundboxMuted, setSoundboxMuted] = useState<boolean>(false);

  // Active merchant name & UPI ID
  const activeUpiId = society.upiId || '7602496460@ikwik';
  const activeMerchantName = society.merchantName || 'PIEM PANDEY';
  const phonePeQrImg = society.qrImage || '/public/Piem Img/image_a73ff616.png';

  // Generate real UPI URI & dynamic QR Code
  useEffect(() => {
    if (isOpen && grandTotal > 0) {
      setUpiStatus('waiting');
      setTenderedCash(grandTotal);

      // Standard UPI Payment URI specification:
      // upi://pay?pa=VPA&pn=NAME&am=AMOUNT&cu=INR&tn=NOTE
      const upiUri = `upi://pay?pa=${encodeURIComponent(
        activeUpiId
      )}&pn=${encodeURIComponent(activeMerchantName)}&am=${grandTotal.toFixed(
        2
      )}&cu=INR&tn=${encodeURIComponent('Nabkul Co-op ' + invoiceNo)}`;

      QRCode.toDataURL(upiUri, {
        width: 280,
        margin: 2,
        color: {
          dark: '#0f172a',
          light: '#ffffff',
        },
        errorCorrectionLevel: 'H',
      })
        .then((url) => setQrDataUrl(url))
        .catch((err) => console.error('QR code generation error', err));
    }
  }, [isOpen, grandTotal, invoiceNo, activeUpiId, activeMerchantName]);

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(activeUpiId);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2500);
  };

  if (!isOpen) return null;

  const changeDue = Math.max(0, tenderedCash - grandTotal);
  const isCashSufficient = tenderedCash >= grandTotal;

  // Simulate customer scanning the QR code and completing payment
  const handleSimulateUpiPayment = () => {
    const randomRef = 'UPI' + Math.floor(100000000000 + Math.random() * 900000000000);
    setUpiTxnId(randomRef);
    setUpiStatus('paid');

    if (!soundboxMuted) {
      playUpiSuccessChime(grandTotal);
    }

    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 },
      });
    } catch {
      // ignore
    }
  };

  const handleCompleteUpiSale = () => {
    onPaymentComplete({
      paymentMode: 'UPI',
      customerName: selectedCustomer,
      upiTxnRef: upiTxnId || 'UPI' + Math.floor(100000000000 + Math.random() * 900000000000),
    });
  };

  const handleCompleteCashSale = () => {
    if (!isCashSufficient) return;
    playCashDrawerSound();
    try {
      confetti({
        particleCount: 40,
        spread: 50,
        origin: { y: 0.7 },
      });
    } catch {
      // ignore
    }
    onPaymentComplete({
      paymentMode: 'CASH',
      customerName: selectedCustomer,
      tenderedCash,
      changeDue,
    });
  };

  const addCash = (amount: number) => {
    setTenderedCash((prev) => prev + amount);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600/30 border border-emerald-500/40 flex items-center justify-center text-emerald-300">
              {activeTab === 'UPI' ? <QrCode className="w-5 h-5" /> : <Banknote className="w-5 h-5" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base">Checkout & Payment</h3>
                <span className="text-xs px-2 py-0.5 rounded bg-emerald-900/60 border border-emerald-500/30 text-emerald-300 font-mono-code">
                  {invoiceNo}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {society.name} · {society.address}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Customer Selector & Bill Summary banner */}
        <div className="bg-slate-50 border-b border-slate-200 px-6 py-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <User className="w-4 h-4 text-slate-500" />
            <span className="text-xs font-semibold text-slate-700">Billing Customer:</span>
            <input
              type="text"
              value={selectedCustomer}
              onChange={(e) => setSelectedCustomer(e.target.value)}
              placeholder="e.g. Walk-in Customer"
              className="text-xs font-semibold bg-white border border-slate-300 rounded-lg px-2.5 py-1 text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div className="text-right">
            <span className="text-xs text-slate-500">Payable Amount: </span>
            <span className="text-xl font-extrabold text-emerald-700 font-mono-code">
              ₹{grandTotal.toFixed(2)}
            </span>
          </div>
        </div>

        {/* Payment mode switches: ONLINE (QR Code only) vs I CASH */}
        <div className="grid grid-cols-2 p-3 bg-slate-100 gap-2 border-b border-slate-200">
          <button
            type="button"
            onClick={() => setActiveTab('UPI')}
            className={`flex items-center justify-center gap-2.5 py-3 px-4 rounded-xl font-bold text-sm transition-all ${
              activeTab === 'UPI'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200'
            }`}
          >
            <QrCode className="w-4 h-4" />
            <span>Online (QR Code only)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('CASH')}
            className={`flex items-center justify-center gap-2.5 py-3 px-4 rounded-xl font-bold text-sm transition-all ${
              activeTab === 'CASH'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200'
            }`}
          >
            <Banknote className="w-4 h-4" />
            <span>I Cash (Cash Transaction)</span>
          </button>
        </div>

        {/* Content area */}
        <div className="p-6 overflow-y-auto flex-1">
          {activeTab === 'UPI' ? (
            <div className="flex flex-col md:flex-row items-center gap-6">
              {/* QR Code Column */}
              <div className="flex flex-col items-center w-full md:w-auto">
                {/* QR Type Switcher (PhonePe Official Standee vs Dynamic Amount QR) */}
                <div className="flex items-center gap-1 p-1 bg-slate-200/80 rounded-xl mb-3 text-xs">
                  <button
                    type="button"
                    onClick={() => setQrViewMode('phonepe')}
                    className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                      qrViewMode === 'phonepe'
                        ? 'bg-purple-700 text-white shadow-sm'
                        : 'text-slate-700 hover:text-slate-900'
                    }`}
                  >
                    PhonePe QR (Official)
                  </button>
                  <button
                    type="button"
                    onClick={() => setQrViewMode('dynamic')}
                    className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                      qrViewMode === 'dynamic'
                        ? 'bg-emerald-600 text-white shadow-sm'
                        : 'text-slate-700 hover:text-slate-900'
                    }`}
                  >
                    Auto-Amount QR (₹{grandTotal.toFixed(0)})
                  </button>
                </div>

                {qrViewMode === 'phonepe' ? (
                  /* Official PhonePe QR Card matching uploaded standee */
                  <div className="bg-white p-3 rounded-2xl border-2 border-purple-500/80 shadow-xl relative flex flex-col items-center max-w-[280px]">
                    <div className="w-full flex items-center justify-center gap-2 pb-1.5 border-b border-purple-100">
                      <div className="w-6 h-6 rounded-full bg-purple-600 flex items-center justify-center text-white text-xs font-bold">
                        पे
                      </div>
                      <span className="font-extrabold text-slate-900 text-sm tracking-wide">PhonePe</span>
                    </div>

                    <div className="mt-1 text-[11px] font-black uppercase text-purple-700 tracking-wider">
                      ACCEPTED HERE
                    </div>
                    <div className="text-[10px] text-slate-500">Scan & Pay Using Any UPI App</div>

                    {/* Official Uploaded QR image */}
                    <div className="my-2 p-1.5 bg-white rounded-xl border border-slate-200 shadow-inner">
                      <img
                        src={phonePeQrImg}
                        alt="PhonePe QR Code - PIEM PANDEY"
                        className="w-52 h-52 object-contain rounded-lg"
                      />
                    </div>

                    <div className="font-black text-xs text-slate-900 tracking-wider uppercase">
                      {activeMerchantName}
                    </div>

                    <div className="mt-1.5 w-full bg-purple-50 border border-purple-200 rounded-lg p-1.5 text-center">
                      <span className="text-[10px] text-purple-900 block font-semibold">
                        Payable: <strong className="font-mono-code text-xs text-purple-800">₹{grandTotal.toFixed(2)}</strong>
                      </span>
                    </div>
                  </div>
                ) : (
                  /* Dynamic Auto-amount QR */
                  <div className="p-3 bg-white rounded-2xl border-2 border-emerald-500/80 shadow-xl relative flex flex-col items-center max-w-[280px]">
                    <div className="text-center pb-1 border-b border-slate-100 w-full">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded">
                        Dynamic Auto-Bill QR
                      </span>
                    </div>

                    <div className="my-2 p-1 bg-slate-50 rounded-xl">
                      {qrDataUrl ? (
                        <img
                          src={qrDataUrl}
                          alt="Dynamic UPI QR"
                          className="w-52 h-52 rounded-lg object-contain"
                        />
                      ) : (
                        <div className="w-52 h-52 bg-slate-100 rounded-lg flex items-center justify-center">
                          <QrCode className="w-12 h-12 text-slate-400 animate-pulse" />
                        </div>
                      )}
                    </div>

                    <div className="text-center w-full">
                      <span className="text-[10px] font-bold text-slate-500 block uppercase">
                        Amount Pre-filled
                      </span>
                      <span className="text-lg font-black text-emerald-700 font-mono-code">
                        ₹{grandTotal.toFixed(2)}
                      </span>
                    </div>
                  </div>
                )}

                {/* VPA / UPI ID display with Copy Button */}
                <div className="mt-3 flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200/80 px-3 py-1.5 rounded-xl border border-slate-300/80 transition-colors">
                  <span className="text-[11px] text-slate-500 font-medium">UPI ID:</span>
                  <strong className="text-xs font-mono-code text-slate-900">{activeUpiId}</strong>
                  <button
                    type="button"
                    onClick={handleCopyUpi}
                    className="ml-1 p-1 text-slate-500 hover:text-emerald-700 transition-colors"
                    title="Copy UPI ID"
                  >
                    {copiedUpi ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
                {copiedUpi && (
                  <span className="text-[10px] text-emerald-700 font-semibold mt-0.5">
                    UPI ID copied to clipboard!
                  </span>
                )}
              </div>

              {/* UPI Actions & Soundbox Column */}
              <div className="flex-1 w-full space-y-4">
                {/* Soundbox status widget */}
                <div className="p-3.5 bg-slate-900 text-white rounded-xl flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                      <Volume2 className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white flex items-center gap-1.5">
                        <span>Nabkul Co-op Soundbox</span>
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                      </div>
                      <p className="text-[11px] text-slate-400">Voice confirmation active</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setSoundboxMuted(!soundboxMuted)}
                    className="text-xs text-slate-300 hover:text-white px-2 py-1 rounded bg-slate-800"
                  >
                    {soundboxMuted ? 'Unmute' : 'Mute'}
                  </button>
                </div>

                {upiStatus === 'waiting' ? (
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl space-y-3">
                    <div className="flex items-center gap-2 text-amber-900 font-semibold text-xs">
                      <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse"></span>
                      <span>Waiting for customer to scan QR code...</span>
                    </div>
                    <p className="text-xs text-amber-800/80">
                      Customer can point any banking app at the screen to transfer{' '}
                      <strong className="font-mono-code">₹{grandTotal.toFixed(2)}</strong> directly into the
                      society&apos;s account.
                    </p>

                    {/* Quick simulate scan button for seller testing */}
                    <button
                      type="button"
                      onClick={handleSimulateUpiPayment}
                      className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-lg flex items-center justify-center gap-2 shadow transition-all hover:scale-[1.01]"
                    >
                      <Sparkles className="w-4 h-4 text-amber-300" />
                      <span>Simulate Customer Scan & UPI Success</span>
                    </button>
                  </div>
                ) : (
                  <div className="p-4 bg-emerald-50 border-2 border-emerald-500 rounded-xl space-y-3 animate-fadeIn">
                    <div className="flex items-center gap-2 text-emerald-800 font-bold text-sm">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                      <span>UPI Payment Verified Successfully!</span>
                    </div>
                    <div className="text-xs text-emerald-900 space-y-1">
                      <div className="flex justify-between">
                        <span className="text-slate-600">UPI Ref / UTR:</span>
                        <span className="font-mono-code font-bold">{upiTxnId}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-600">Credited To:</span>
                        <span className="font-mono-code">{society.upiId}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-600">Amount Received:</span>
                        <span className="font-bold text-emerald-700">₹{grandTotal.toFixed(2)}</span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={handleCompleteUpiSale}
                      className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm rounded-lg flex items-center justify-center gap-2 shadow-lg transition-all"
                    >
                      <span>Generate & Print Bill Receipt</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          ) : (
            /* Cash Mode */
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Cash Tendered Input */}
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                    Cash Tendered by Customer (₹)
                  </label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-lg font-bold text-slate-500">
                      ₹
                    </span>
                    <input
                      type="number"
                      step="1"
                      min="0"
                      value={tenderedCash || ''}
                      onChange={(e) => setTenderedCash(parseFloat(e.target.value) || 0)}
                      className="w-full pl-8 pr-4 py-3 text-2xl font-bold bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono-code text-slate-900"
                      placeholder="0.00"
                    />
                  </div>

                  {/* Quick Cash Buttons */}
                  <div>
                    <span className="text-[11px] font-semibold text-slate-500 block mb-1.5">
                      Fast Tender Denominations:
                    </span>
                    <div className="grid grid-cols-3 gap-1.5">
                      <button
                        type="button"
                        onClick={() => setTenderedCash(grandTotal)}
                        className="py-1.5 px-2 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700"
                      >
                        Exact (₹{grandTotal.toFixed(0)})
                      </button>
                      <button
                        type="button"
                        onClick={() => addCash(100)}
                        className="py-1.5 px-2 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700"
                      >
                        +₹100
                      </button>
                      <button
                        type="button"
                        onClick={() => addCash(200)}
                        className="py-1.5 px-2 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700"
                      >
                        +₹200
                      </button>
                      <button
                        type="button"
                        onClick={() => setTenderedCash(500)}
                        className="py-1.5 px-2 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700"
                      >
                        ₹500 Note
                      </button>
                      <button
                        type="button"
                        onClick={() => setTenderedCash(1000)}
                        className="py-1.5 px-2 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700"
                      >
                        ₹1,000
                      </button>
                      <button
                        type="button"
                        onClick={() => setTenderedCash(2000)}
                        className="py-1.5 px-2 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700"
                      >
                        ₹2,000 Note
                      </button>
                    </div>
                  </div>
                </div>

                {/* Return Change Calculator */}
                <div className="p-4 bg-emerald-50/60 rounded-xl border border-emerald-200 flex flex-col justify-between">
                  <div>
                    <span className="text-xs font-bold text-emerald-900 uppercase tracking-wider block">
                      Change Due to Return
                    </span>
                    <div className="mt-2 text-3xl font-extrabold text-emerald-800 font-mono-code">
                      ₹{changeDue.toFixed(2)}
                    </div>
                    {tenderedCash < grandTotal && (
                      <p className="mt-1 text-xs text-rose-600 font-medium">
                        Short by ₹{(grandTotal - tenderedCash).toFixed(2)}
                      </p>
                    )}
                    {changeDue > 0 && (
                      <div className="mt-2 text-[11px] text-emerald-700 bg-white/80 p-2 rounded-lg border border-emerald-200">
                        Give customer ₹{changeDue.toFixed(2)} from cash drawer.
                      </div>
                    )}
                  </div>

                  <div className="pt-4 border-t border-emerald-200/60 text-xs text-slate-600 space-y-1">
                    <div className="flex justify-between">
                      <span>Total Items:</span>
                      <span className="font-bold">{cart.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Grand Total:</span>
                      <span className="font-bold text-slate-900">₹{grandTotal.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Complete Cash Button */}
              <button
                type="button"
                disabled={!isCashSufficient}
                onClick={handleCompleteCashSale}
                className={`w-full py-3.5 px-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2 shadow-lg transition-all ${
                  isCashSufficient
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer hover:scale-[1.01]'
                    : 'bg-slate-300 text-slate-500 cursor-not-allowed'
                }`}
              >
                <Banknote className="w-5 h-5" />
                <span>
                  {isCashSufficient
                    ? `Accept ₹${tenderedCash.toFixed(2)} Cash & Complete Sale`
                    : `Tender at least ₹${grandTotal.toFixed(2)}`}
                </span>
              </button>
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="px-6 py-2.5 bg-slate-50 border-t border-slate-200 text-center text-xs text-slate-500 flex items-center justify-center gap-2">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
          <span>Nabkul Cooperative Society Registered POS Ledger · Instant Stock Output Sync</span>
        </div>
      </div>
    </div>
  );
};
