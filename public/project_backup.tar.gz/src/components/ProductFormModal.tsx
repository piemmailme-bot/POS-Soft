import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Plus,
  Save,
  AlertTriangle,
  CheckCircle,
  Upload,
  Trash2,
  Sparkles,
  Link as LinkIcon,
  RotateCcw,
  Zap,
  Edit3,
  Check,
  Image as ImageIcon,
  ChevronDown,
  ChevronUp,
  Lock,
} from 'lucide-react';
import { Product, UnitType } from '../types';
import {
  getDefaultCategoryImage,
  getProductImage,
  validateImageFile,
  fileToDataUrl,
  formatFileSize,
  checkDuplicateBarcode,
  generateUniqueBarcode,
  MAX_IMAGE_SIZE_LABEL,
} from '../utils/productImages';

interface ProductFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  productToEdit?: Product | null;
  existingProducts: Product[];
  categories: string[];
  onSaveProduct: (productData: Omit<Product, 'id'>, existingId?: number) => void;
  onAddNewCategory?: (newCategoryName: string) => void;
  onRenameCategory?: (oldCategoryName: string, newCategoryName: string) => void;
}

export const ProductFormModal: React.FC<ProductFormModalProps> = ({
  isOpen,
  onClose,
  productToEdit,
  existingProducts,
  categories,
  onSaveProduct,
  onAddNewCategory,
  onRenameCategory,
}) => {
  const isEditing = !!productToEdit;
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const dropdownRef = useRef<HTMLDivElement | null>(null);
  const categoryDropdownRef = useRef<HTMLDivElement | null>(null);

  // Form Fields - support empty string state so fields can be completely cleared
  const [name, setName] = useState('');
  const [barcode, setBarcode] = useState('');
  const [category, setCategory] = useState('Grains & Staples');
  const [unit, setUnit] = useState<UnitType>('KG');
  const [stock, setStock] = useState<number | ''>('');
  const [minStockLevel, setMinStockLevel] = useState<number | ''>('');
  const [sellingPrice, setSellingPrice] = useState<number | ''>('');
  const [costPrice, setCostPrice] = useState<number | ''>('');
  const [batchNo, setBatchNo] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [description, setDescription] = useState('');

  // Dropdown combobox state for Product Name & Category
  const [isDropdownOpen, setIsDropdownOpen] = useState<boolean>(false);
  const [isCategoryDropdownOpen, setIsCategoryDropdownOpen] = useState<boolean>(false);
  
  // Image handling state
  const [imageUrl, setImageUrl] = useState<string>('');
  const [imageSizeFormatted, setImageSizeFormatted] = useState<string>('');
  const [imageError, setImageError] = useState<string | null>(null);
  const [showUrlInput, setShowUrlInput] = useState<boolean>(false);

  // Category in-modal editing state
  const [isAddingNewCategory, setIsAddingNewCategory] = useState<boolean>(false);
  const [newCategoryInput, setNewCategoryInput] = useState<string>('');
  const [isRenamingCategory, setIsRenamingCategory] = useState<boolean>(false);
  const [renameCategoryInput, setRenameCategoryInput] = useState<string>('');
  const [categoryFeedback, setCategoryFeedback] = useState<string | null>(null);

  // Products belonging to the selected category
  const categoryProducts = existingProducts.filter(
    (p) => p.category.trim().toLowerCase() === category.trim().toLowerCase()
  );

  // Check if current name matches any existing product in catalog
  const matchedExistingProduct = existingProducts.find(
    (p) => p.name.trim().toLowerCase() === name.trim().toLowerCase()
  );

  // When an existing product is selected (or when name is empty):
  // Show ALL products in this category so the user can easily switch to another item!
  // Only filter if the user is actively typing a query that doesn't match an already selected product.
  const isSelectedProductMatch =
    !!matchedExistingProduct &&
    matchedExistingProduct.name.trim().toLowerCase() === name.trim().toLowerCase();

  const filteredDropdownProducts =
    isSelectedProductMatch || !name.trim()
      ? categoryProducts
      : categoryProducts.filter((p) =>
          p.name.toLowerCase().includes(name.trim().toLowerCase())
        );

  // Barcode uniqueness check:
  // If product name is the same as existing product, sharing the same barcode is intentionally valid.
  // Conflict only happens if the barcode belongs to a completely different product!
  const duplicateCheck = checkDuplicateBarcode(
    barcode,
    existingProducts,
    productToEdit ? productToEdit.id : undefined
  );
  const isConflictingDuplicate =
    duplicateCheck.isDuplicate &&
    duplicateCheck.duplicateProduct?.name.trim().toLowerCase() !== name.trim().toLowerCase();

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsDropdownOpen(false);
      }
      if (categoryDropdownRef.current && !categoryDropdownRef.current.contains(e.target as Node)) {
        setIsCategoryDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Initialize or reset form on open / change
  useEffect(() => {
    if (productToEdit) {
      setName(productToEdit.name || '');
      setBarcode(productToEdit.barcode || '');
      setCategory(productToEdit.category || 'Grains & Staples');
      setUnit(productToEdit.unit || 'KG');
      setStock(productToEdit.stock ?? '');
      setMinStockLevel(productToEdit.minStockLevel ?? '');
      setSellingPrice(productToEdit.sellingPrice ?? '');
      setCostPrice(productToEdit.costPrice ?? '');
      setBatchNo(productToEdit.batchNo || '');
      setExpiryDate(productToEdit.expiryDate || '');
      setDescription(productToEdit.description || '');
      setImageUrl(productToEdit.image || '');
      setImageSizeFormatted(productToEdit.image?.startsWith('data:') ? 'Custom Photo' : '');
    } else {
      // Defaults for brand new product: ALL fields start completely empty and refreshed
      const initialCat = categories[0] || 'Grains & Staples';
      setName('');
      setBarcode('');
      setCategory(initialCat);
      setUnit('KG');
      setStock('');
      setMinStockLevel('');
      setSellingPrice('');
      setCostPrice('');
      setBatchNo('');
      setExpiryDate('');
      setDescription('');
      setImageUrl('');
      setImageSizeFormatted('');
    }
    setIsDropdownOpen(false);
    setIsCategoryDropdownOpen(false);
    setImageError(null);
    setIsAddingNewCategory(false);
    setIsRenamingCategory(false);
    setShowUrlInput(false);
    setCategoryFeedback(null);
  }, [productToEdit, isOpen]);

  if (!isOpen) return null;

  // Handle typing in product name
  const handleNameInputChange = (typedName: string) => {
    setName(typedName);
    setIsDropdownOpen(true);

    const trimmed = typedName.trim();
    if (!trimmed) {
      // If product name is empty, barcode also becomes empty
      setBarcode('');
      return;
    }

    const matched = existingProducts.find(
      (p) => p.name.trim().toLowerCase() === trimmed.toLowerCase()
    );

    if (matched) {
      // If product name is same then bar code will be same for this product
      setBarcode(matched.barcode);
    } else {
      // Product is not found, then auto generated bar code will be added
      // If current barcode was linked to an existing product or empty, generate a fresh unique barcode
      const isLinkedToExisting = existingProducts.some((p) => p.barcode === barcode);
      if (isLinkedToExisting || !barcode) {
        setBarcode(generateUniqueBarcode(existingProducts));
      }
    }
  };

  // Handle selecting an existing product from the dropdown list
  const handleSelectProduct = (prod: Product) => {
    setName(prod.name);
    // If product name is same then bar code will be same for this product
    setBarcode(prod.barcode);
    setCategory(prod.category);
    setUnit(prod.unit || 'KG');
    setSellingPrice(prod.sellingPrice ?? '');
    setCostPrice(prod.costPrice ?? '');
    setStock(prod.stock ?? '');
    setMinStockLevel(prod.minStockLevel ?? '');
    setBatchNo(prod.batchNo || '');
    setExpiryDate(prod.expiryDate || '');
    if (prod.image) {
      setImageUrl(prod.image);
      setImageSizeFormatted('Existing Product Asset');
    } else {
      setImageUrl('');
      setImageSizeFormatted('');
    }
    if (prod.description) {
      setDescription(prod.description);
    } else {
      setDescription('');
    }
    setIsDropdownOpen(false);
  };

  // Handle user explicitly confirming a new product from the combobox
  const handleConfirmNewProduct = () => {
    setIsDropdownOpen(false);
    if (existingProducts.some((p) => p.barcode === barcode) || !barcode) {
      setBarcode(generateUniqueBarcode(existingProducts));
    }
  };

  // Handle category change or re-select:
  // "if product category is change or re-select then product name, images, bar code will gain be empty and refresh"
  // "this portion is not getting empty after refresh and changes"
  const handleCategorySelect = (newCat: string) => {
    setCategory(newCat);
    setIsCategoryDropdownOpen(false);

    // Empty and refresh product name
    setName('');
    setIsDropdownOpen(false);

    // Empty and refresh product image & file input
    setImageUrl('');
    setImageSizeFormatted('');
    setImageError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }

    // Empty and refresh barcode
    setBarcode('');

    // Empty and refresh entire portion: unit, stock, min alert, prices, batch, expiry, description
    setStock('');
    setMinStockLevel('');
    setSellingPrice('');
    setCostPrice('');
    setBatchNo('');
    setExpiryDate('');
    setDescription('');
    setUnit('KG');

    setCategoryFeedback(`Category "${newCat}" active · All fields refreshed & emptied`);
    setTimeout(() => setCategoryFeedback(null), 3000);
  };

  // Handle Image File Selection with Strict Size Limit
  const handleImageFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    setImageError(null);
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate size (< 2MB) and MIME type
    const validation = validateImageFile(file);
    if (!validation.valid) {
      setImageError(validation.error || 'Invalid image file.');
      // Reset file input
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    try {
      const dataUrl = await fileToDataUrl(file);
      setImageUrl(dataUrl);
      setImageSizeFormatted(formatFileSize(file.size));
      setImageError(null);
    } catch {
      setImageError('Failed to read image file. Please try another file.');
    }
  };

  // Remove uploaded image -> reverts back to default category SVG
  const handleClearImage = () => {
    setImageUrl('');
    setImageSizeFormatted('');
    setImageError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Auto-Generate Unique Barcode helper (for new product)
  const handleGenerateBarcode = () => {
    const unique = generateUniqueBarcode(existingProducts);
    setBarcode(unique);
  };

  // Add new Category from modal
  const handleApplyNewCategory = () => {
    const trimmed = newCategoryInput.trim();
    if (!trimmed) return;
    if (onAddNewCategory) {
      onAddNewCategory(trimmed);
    }
    setCategory(trimmed);
    setIsAddingNewCategory(false);
    setNewCategoryInput('');

    // Empty and refresh product name, images, barcode, and entire inventory/price portion
    setName('');
    setIsDropdownOpen(false);
    setImageUrl('');
    setImageSizeFormatted('');
    setImageError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
    setBarcode('');
    setStock('');
    setMinStockLevel('');
    setSellingPrice('');
    setCostPrice('');
    setBatchNo('');
    setExpiryDate('');
    setDescription('');
    setUnit('KG');

    setCategoryFeedback(`Created & selected "${trimmed}" · Fields refreshed`);
    setTimeout(() => setCategoryFeedback(null), 3000);
  };

  // Rename selected Category from modal
  const handleApplyRenameCategory = () => {
    const trimmed = renameCategoryInput.trim();
    if (!trimmed || trimmed === category) {
      setIsRenamingCategory(false);
      return;
    }
    if (onRenameCategory) {
      onRenameCategory(category, trimmed);
    }
    setCategory(trimmed);
    setIsRenamingCategory(false);
    setRenameCategoryInput('');
    setCategoryFeedback(`Renamed to "${trimmed}"`);
    setTimeout(() => setCategoryFeedback(null), 3000);
  };

  // Form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    if (isConflictingDuplicate) return;

    // Resolve barcode: use current barcode or auto-generate if empty
    const finalBarcode = barcode.trim() || generateUniqueBarcode(existingProducts);

    // If no custom image uploaded, fallback to category default SVG
    const resolvedImage = imageUrl.trim() || getDefaultCategoryImage(category);

    const productPayload: Omit<Product, 'id'> = {
      name: name.trim(),
      category: category.trim(),
      barcode: finalBarcode,
      unit: unit || 'KG',
      sellingPrice: sellingPrice === '' ? 0 : Number(sellingPrice),
      costPrice: costPrice === '' ? 0 : Number(costPrice),
      stock: stock === '' ? 0 : Number(stock),
      minStockLevel: minStockLevel === '' ? 1 : Number(minStockLevel),
      batchNo: batchNo.trim() || `B-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`,
      expiryDate: expiryDate ? expiryDate : undefined,
      image: resolvedImage,
      description: description.trim(),
    };

    onSaveProduct(productPayload, productToEdit ? productToEdit.id : undefined);
    onClose();
  };

  // Active display image: if user has custom imageUrl, show that; otherwise show meaningful category default SVG
  const previewImageSrc = imageUrl.trim() ? imageUrl : getDefaultCategoryImage(category);
  const isUsingDefaultCategoryFallback = !imageUrl.trim();

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between flex-shrink-0">
          <div>
            <h3 className="font-bold text-base flex items-center gap-2">
              {isEditing ? (
                <>
                  <Edit3 className="w-5 h-5 text-emerald-400" />
                  <span>Edit Product &amp; Stock Details</span>
                </>
              ) : (
                <>
                  <Plus className="w-5 h-5 text-emerald-400" />
                  <span>Add New Product to Society Catalog</span>
                </>
              )}
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Select category to view existing products, auto-assign barcodes, and configure inventory
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 overflow-y-auto flex-1">
          {/* STEP 1: Category Section with In-Modal Editing & Custom Creation */}
          <div className="space-y-1.5 p-3.5 rounded-xl bg-slate-50 border border-slate-200">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <span>Product Category *</span>
                <span className="text-[10px] text-slate-500 font-normal">
                  (Links with product list below)
                </span>
              </label>
              {!isAddingNewCategory && !isRenamingCategory && (
                <div className="flex items-center gap-1.5 flex-wrap">
                  <button
                    type="button"
                    onClick={() => handleCategorySelect(category)}
                    className="text-[11px] font-semibold text-slate-600 hover:text-slate-900 bg-white hover:bg-slate-100 px-2 py-0.5 rounded border border-slate-300 flex items-center gap-1 transition-colors"
                    title="Re-select category and refresh product name, images, and barcode to empty"
                  >
                    <RotateCcw className="w-3 h-3 text-slate-500" />
                    <span>Re-select &amp; Refresh</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setRenameCategoryInput(category);
                      setIsRenamingCategory(true);
                      setIsAddingNewCategory(false);
                    }}
                    className="text-[11px] font-semibold text-slate-600 hover:text-slate-900 bg-white hover:bg-slate-100 px-2 py-0.5 rounded border border-slate-300 flex items-center gap-1 transition-colors"
                    title="Rename this category"
                  >
                    <Edit3 className="w-3 h-3 text-slate-500" />
                    <span>Edit Name</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setNewCategoryInput('');
                      setIsAddingNewCategory(true);
                      setIsRenamingCategory(false);
                    }}
                    className="text-[11px] font-semibold text-emerald-700 hover:text-emerald-800 bg-white hover:bg-emerald-50 px-2 py-0.5 rounded border border-emerald-300 flex items-center gap-1 transition-colors"
                    title="Create a new custom category"
                  >
                    <Plus className="w-3 h-3 text-emerald-600" />
                    <span>+ New Category</span>
                  </button>
                </div>
              )}
            </div>

            {/* Category Dropdown with chevron & Re-select support */}
            {!isAddingNewCategory && !isRenamingCategory && (
              <div ref={categoryDropdownRef} className="relative">
                <button
                  type="button"
                  onClick={() => setIsCategoryDropdownOpen(!isCategoryDropdownOpen)}
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm font-semibold bg-white border border-slate-300 rounded-xl text-slate-800 text-left flex items-center justify-between hover:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all shadow-xs"
                  title="Click to change or re-select category"
                  aria-label="Toggle category selection dropdown"
                >
                  <span className="flex items-center gap-2 truncate">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 flex-shrink-0"></span>
                    <span className="truncate">{category}</span>
                    <span className="text-[11px] text-slate-400 font-normal">
                      ({categoryProducts.length} items stored)
                    </span>
                  </span>
                  <span className="flex items-center gap-1 text-slate-500 pl-2 flex-shrink-0">
                    <span className="text-[10px] text-slate-400 hidden sm:inline">Change / Re-select</span>
                    {isCategoryDropdownOpen ? (
                      <ChevronUp className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-slate-600" />
                    )}
                  </span>
                </button>

                {/* Dropdown Menu for Category Selection */}
                {isCategoryDropdownOpen && (
                  <div className="absolute left-0 right-0 top-full mt-1 bg-white rounded-xl shadow-2xl border border-slate-200 z-50 max-h-60 overflow-y-auto divide-y divide-slate-100 animate-fadeIn">
                    <div className="px-3.5 py-2 bg-slate-50 flex items-center justify-between text-[11px] font-bold text-slate-700 sticky top-0 z-10 border-b border-slate-200">
                      <span>Select Category to Refresh Form</span>
                      <button
                        type="button"
                        onClick={() => setIsCategoryDropdownOpen(false)}
                        className="text-slate-400 hover:text-slate-700 text-xs px-1"
                      >
                        ✕
                      </button>
                    </div>
                    <div className="p-1 space-y-0.5">
                      {categories.map((c) => {
                        const isSelected = c.toLowerCase() === category.toLowerCase();
                        const count = existingProducts.filter(
                          (p) => p.category.trim().toLowerCase() === c.trim().toLowerCase()
                        ).length;
                        return (
                          <button
                            key={c}
                            type="button"
                            onClick={() => handleCategorySelect(c)}
                            className={`w-full text-left px-3 py-2 rounded-lg flex items-center justify-between text-xs transition-colors ${
                              isSelected
                                ? 'bg-emerald-50 font-bold text-emerald-900 border border-emerald-200'
                                : 'text-slate-800 hover:bg-slate-50'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <span>{c}</span>
                              {isSelected && (
                                <span className="text-[10px] font-bold text-emerald-700 bg-white px-1.5 py-0.5 rounded border border-emerald-200">
                                  Active · Click to Re-select
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] font-mono-code text-slate-500">
                              {count} items
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Mode 1: Adding a new category inline */}
            {isAddingNewCategory && (
              <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-lg space-y-2">
                <span className="text-[11px] font-bold text-emerald-900 block">
                  Add New Category Name:
                </span>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    placeholder="e.g. Household &amp; Hygiene, Fresh Produce, Organic"
                    value={newCategoryInput}
                    onChange={(e) => setNewCategoryInput(e.target.value)}
                    className="flex-1 px-3 py-1.5 text-xs bg-white border border-emerald-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 font-semibold"
                    autoFocus
                  />
                  <button
                    type="button"
                    onClick={handleApplyNewCategory}
                    disabled={!newCategoryInput.trim()}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-lg text-xs font-bold flex items-center gap-1"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Add</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsAddingNewCategory(false)}
                    className="px-2.5 py-1.5 text-xs text-slate-600 hover:text-slate-800"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}

            {/* Mode 2: Renaming currently selected category inline */}
            {isRenamingCategory && (
              <div className="p-3 bg-amber-50/80 border border-amber-200 rounded-lg space-y-2">
                <span className="text-[11px] font-bold text-amber-900 block">
                  Edit Category Name for "{category}":
                </span>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={renameCategoryInput}
                    onChange={(e) => setRenameCategoryInput(e.target.value)}
                    className="flex-1 px-3 py-1.5 text-xs bg-white border border-amber-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 font-semibold"
                    autoFocus
                  />
                  <button
                    type="button"
                    onClick={handleApplyRenameCategory}
                    disabled={!renameCategoryInput.trim()}
                    className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white rounded-lg text-xs font-bold flex items-center gap-1"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Save Name</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsRenamingCategory(false)}
                    className="px-2.5 py-1.5 text-xs text-slate-600 hover:text-slate-800"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}

            {categoryFeedback && (
              <p className="text-[11px] text-emerald-700 font-medium flex items-center gap-1 mt-1">
                <CheckCircle className="w-3 h-3 text-emerald-600" />
                <span>{categoryFeedback}</span>
              </p>
            )}
          </div>

          {/* STEP 2: Product Name with Dropdown Arrows & Category Linking */}
          <div ref={dropdownRef} className="relative space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <span>Product Name *</span>
                {matchedExistingProduct ? (
                  <span className="text-[10px] font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200 flex items-center gap-1">
                    <Check className="w-3 h-3 text-blue-600" />
                    <span>Existing Product · Same Barcode Linked</span>
                  </span>
                ) : name.trim() ? (
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 flex items-center gap-1">
                    <Zap className="w-3 h-3 text-emerald-600" />
                    <span>New Product · Auto Barcode Assigned</span>
                  </span>
                ) : null}
              </label>
              <span className="text-[11px] text-slate-500">
                In <strong className="text-slate-700">"{category}"</strong> ({categoryProducts.length} stored)
              </span>
            </div>

            {/* Input with Dropdown Arrow */}
            <div className="relative flex items-center">
              <input
                type="text"
                placeholder={`Click dropdown arrow or type product name...`}
                value={name}
                onChange={(e) => handleNameInputChange(e.target.value)}
                onFocus={() => setIsDropdownOpen(true)}
                className={`w-full pl-3.5 pr-11 py-2.5 text-xs sm:text-sm border rounded-xl focus:outline-none transition-all font-semibold text-slate-900 placeholder:font-normal placeholder:text-slate-400 ${
                  matchedExistingProduct
                    ? 'border-blue-400 bg-blue-50/20 focus:ring-2 focus:ring-blue-500'
                    : 'border-slate-300 focus:ring-2 focus:ring-emerald-500'
                }`}
                required
              />
              <button
                type="button"
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                className="absolute right-1.5 top-1/2 -translate-y-1/2 p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors flex items-center justify-center"
                title="Browse existing products in this category"
                aria-label="Toggle existing product dropdown"
              >
                {isDropdownOpen ? (
                  <ChevronUp className="w-4 h-4 text-emerald-600" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-slate-600" />
                )}
              </button>
            </div>

            {/* Searchable Dropdown List of Existing Products in this Category */}
            {isDropdownOpen && (
              <div className="absolute left-0 right-0 top-full mt-1 bg-white rounded-xl shadow-2xl border border-slate-200 z-50 max-h-64 overflow-y-auto divide-y divide-slate-100 animate-fadeIn">
                <div className="px-3.5 py-2 bg-slate-50 flex items-center justify-between text-[11px] font-bold text-slate-700 sticky top-0 z-10 border-b border-slate-200">
                  <div className="flex items-center gap-2">
                    <span>Stored Products in "{category}"</span>
                    <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                      {filteredDropdownProducts.length} items
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {filteredDropdownProducts.length < categoryProducts.length && (
                      <button
                        type="button"
                        onClick={() => {
                          setName('');
                          setBarcode('');
                        }}
                        className="text-[11px] font-semibold text-emerald-700 hover:text-emerald-800 underline"
                      >
                        Show All ({categoryProducts.length})
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => setIsDropdownOpen(false)}
                      className="text-slate-400 hover:text-slate-700 text-xs px-1"
                    >
                      Close ✕
                    </button>
                  </div>
                </div>

                {categoryProducts.length === 0 ? (
                  <div className="p-4 text-center text-xs text-slate-500">
                    <p className="font-semibold text-slate-700">No stored products yet under "{category}".</p>
                    <p className="text-[11px] text-slate-400 mt-1">
                      Type any product name in the box. A unique barcode will be automatically generated.
                    </p>
                  </div>
                ) : filteredDropdownProducts.length === 0 ? (
                  <div className="p-3.5 text-center text-xs text-slate-600 space-y-2">
                    <div>No existing product named "{name}" found in this category.</div>
                    <button
                      type="button"
                      onClick={handleConfirmNewProduct}
                      className="text-xs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 px-3 py-1.5 rounded-lg border border-emerald-200 inline-flex items-center gap-1 shadow-xs"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Create New Product: "{name}"</span>
                    </button>
                  </div>
                ) : (
                  <div className="p-1 space-y-0.5">
                    {filteredDropdownProducts.map((p) => {
                      const isSelected = p.name.trim().toLowerCase() === name.trim().toLowerCase();
                      return (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => handleSelectProduct(p)}
                          className={`w-full text-left px-3 py-2 rounded-lg flex items-center justify-between gap-2.5 transition-colors ${
                            isSelected
                              ? 'bg-blue-50 border border-blue-200 text-blue-950 font-bold'
                              : 'hover:bg-slate-50 text-slate-800'
                          }`}
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <img
                              src={getProductImage(p)}
                              alt=""
                              className="w-8 h-8 rounded-md object-cover border border-slate-200 flex-shrink-0"
                            />
                            <div className="truncate">
                              <div className="text-xs font-bold truncate flex items-center gap-1.5">
                                <span>{p.name}</span>
                                {isSelected && (
                                  <span className="text-[9px] font-bold text-blue-700 bg-blue-100 px-1.5 py-0.5 rounded border border-blue-200 flex items-center gap-0.5">
                                    <Check className="w-2.5 h-2.5 text-blue-600" />
                                    <span>Selected</span>
                                  </span>
                                )}
                              </div>
                              <div className="text-[10px] text-slate-500 font-mono-code flex items-center gap-2">
                                <span>Barcode: {p.barcode}</span>
                                <span>·</span>
                                <span>Stock: {p.stock} {p.unit}</span>
                              </div>
                            </div>
                          </div>
                          <div className="text-right flex-shrink-0">
                            <div className="text-xs font-bold text-emerald-700 font-mono-code">
                              ₹{p.sellingPrice}
                            </div>
                            <div className="text-[10px] text-slate-400">/{p.unit}</div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* STEP 3: Barcode Field (Auto-Generated / Synced · Manual Typing Disabled) */}
          <div className="space-y-1.5 p-3.5 rounded-xl bg-slate-50 border border-slate-200">
            <div className="flex items-center justify-between flex-wrap gap-1">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-slate-500" />
                <span>Barcode (Auto-Assigned · Manual Typing Disabled) *</span>
              </label>

              {matchedExistingProduct ? (
                <span className="text-[10px] font-bold text-blue-700 bg-blue-100/70 px-2 py-0.5 rounded border border-blue-200">
                  Linked to Existing Barcode
                </span>
              ) : barcode ? (
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100/70 px-2 py-0.5 rounded border border-emerald-200">
                    Auto-Generated Unique Barcode
                  </span>
                  <button
                    type="button"
                    onClick={handleGenerateBarcode}
                    className="text-[10px] font-bold text-emerald-700 hover:text-emerald-800 bg-white hover:bg-emerald-50 px-2 py-0.5 rounded border border-emerald-300 flex items-center gap-1 transition-colors"
                    title="Regenerate a different unique 12-digit barcode"
                  >
                    <Zap className="w-3 h-3 text-emerald-600" />
                    <span>Regenerate</span>
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-semibold text-slate-500 bg-slate-200/70 px-2 py-0.5 rounded border border-slate-300">
                    Empty · Ready to Auto-Assign
                  </span>
                  <button
                    type="button"
                    onClick={handleGenerateBarcode}
                    className="text-[10px] font-bold text-emerald-700 hover:text-emerald-800 bg-white hover:bg-emerald-50 px-2 py-0.5 rounded border border-emerald-300 flex items-center gap-1 transition-colors"
                    title="Generate a unique 12-digit barcode now"
                  >
                    <Zap className="w-3 h-3 text-emerald-600" />
                    <span>Auto-Generate Now</span>
                  </button>
                </div>
              )}
            </div>

            <div className="relative">
              <input
                type="text"
                value={barcode}
                placeholder="Auto-assigned on product selection or typing name..."
                readOnly
                tabIndex={-1}
                className="w-full px-3.5 py-2.5 text-xs sm:text-sm font-mono-code font-bold rounded-xl bg-slate-100 text-slate-800 border border-slate-300 cursor-not-allowed select-all focus:outline-none placeholder:text-slate-400 placeholder:font-normal"
                title="Barcode number is automatically generated/linked and cannot be typed manually"
              />
              <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1 text-[11px] font-semibold text-slate-500 pointer-events-none">
                <Lock className="w-3.5 h-3.5 text-slate-400" />
                <span>Auto-Locked</span>
              </div>
            </div>

            <p className="text-[11px] text-slate-500">
              {matchedExistingProduct ? (
                <span>
                  ✓ Product name matches existing <strong>"{matchedExistingProduct.name}"</strong>. Same barcode is automatically used.
                </span>
              ) : barcode ? (
                <span>
                  ⚡ Unique 12-digit barcode automatically generated without manual typing.
                </span>
              ) : (
                <span>
                  ⚡ Type a product name or select from the dropdown above to auto-assign a barcode.
                </span>
              )}
            </p>

            {/* Warning banner ONLY if an unintended barcode collision occurs with a different product */}
            {isConflictingDuplicate && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2.5 animate-fadeIn">
                <AlertTriangle className="w-4 h-4 text-rose-600 flex-shrink-0 mt-0.5" />
                <div className="flex-1 text-[11.5px] leading-relaxed">
                  <div className="font-bold text-rose-900">
                    Duplicate Barcode Detected: Code <span className="font-mono underline">{barcode}</span> is assigned to a different product!
                  </div>
                  <p className="mt-0.5 text-rose-700">
                    Belongs to <strong>"{duplicateCheck.duplicateProduct?.name}"</strong>. Click below to regenerate a new unique barcode.
                  </p>
                  <button
                    type="button"
                    onClick={handleGenerateBarcode}
                    className="mt-2 inline-flex items-center gap-1 px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-lg font-bold text-[11px] shadow-xs"
                  >
                    <Zap className="w-3 h-3" />
                    <span>Assign Available Unique Barcode Now</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Product Image Upload with Limited Size (<2MB) & Meaningful Default Image */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
              <div>
                <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <ImageIcon className="w-4 h-4 text-emerald-600" />
                  <span>Product Image Upload (Limited to {MAX_IMAGE_SIZE_LABEL})</span>
                </label>
                <p className="text-[11px] text-slate-500">
                  Upload a photo or enjoy the category's meaningful default illustration
                </p>
              </div>
              <span className="text-[10px] font-bold text-slate-600 bg-white px-2 py-0.5 rounded-full border border-slate-200 self-start sm:self-auto">
                Max {MAX_IMAGE_SIZE_LABEL} · JPG, PNG, WEBP
              </span>
            </div>

            {/* Layout: Preview box alongside Upload controls */}
            <div className="flex flex-col sm:flex-row items-center gap-4 pt-1">
              {/* Live Preview Box */}
              <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-2xl overflow-hidden border-2 border-slate-200 bg-white shadow-xs flex-shrink-0 flex items-center justify-center group">
                <img
                  src={previewImageSrc}
                  alt="Product preview"
                  className="w-full h-full object-cover transition-transform group-hover:scale-105"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = getDefaultCategoryImage(category);
                  }}
                />
                {/* Fallback vs Custom Badge */}
                <div className="absolute bottom-1 left-1 right-1">
                  <span
                    className={`block text-[9px] font-bold text-center py-0.5 px-1 rounded shadow-xs truncate ${
                      isUsingDefaultCategoryFallback
                        ? 'bg-emerald-900/80 text-emerald-100 backdrop-blur-xs'
                        : 'bg-slate-900/80 text-white backdrop-blur-xs'
                    }`}
                  >
                    {isUsingDefaultCategoryFallback ? 'Default Graphic' : 'Uploaded Photo'}
                  </span>
                </div>
              </div>

              {/* Controls and Upload Buttons */}
              <div className="flex-1 space-y-2.5 w-full">
                {/* Hidden file input */}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/gif"
                  onChange={handleImageFileChange}
                  className="hidden"
                />

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Upload Image (&le; 2 MB)</span>
                  </button>

                  {!isUsingDefaultCategoryFallback && (
                    <button
                      type="button"
                      onClick={handleClearImage}
                      className="px-3 py-2 bg-white hover:bg-rose-50 text-rose-700 border border-rose-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
                      title="Clear uploaded image and restore meaningful category default"
                    >
                      <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                      <span>Remove / Use Default</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => setShowUrlInput(!showUrlInput)}
                    className="px-2.5 py-2 text-xs text-slate-600 hover:text-slate-900 underline flex items-center gap-1"
                  >
                    <LinkIcon className="w-3 h-3" />
                    <span>{showUrlInput ? 'Hide URL input' : 'Or paste URL'}</span>
                  </button>
                </div>

                {/* File size badge or error */}
                {imageError ? (
                  <div className="p-2.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-rose-600 flex-shrink-0" />
                    <span>{imageError}</span>
                  </div>
                ) : imageSizeFormatted ? (
                  <div className="text-[11px] text-emerald-800 font-semibold flex items-center gap-1">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Custom image loaded ({imageSizeFormatted}). Safe under 2 MB limit.</span>
                  </div>
                ) : (
                  <div className="text-[11px] text-slate-500 flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                    <span>
                      Currently showing default meaningful <strong>"{category}"</strong> illustration.
                    </span>
                  </div>
                )}

                {/* Optional Web Image URL input */}
                {showUrlInput && (
                  <div className="pt-1">
                    <input
                      type="url"
                      placeholder="https://example.com/item-photo.jpg"
                      value={imageUrl}
                      onChange={(e) => {
                        setImageUrl(e.target.value);
                        setImageSizeFormatted('Web URL');
                      }}
                      className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Unit, Stock & Alert Level */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Unit Type
              </label>
              <select
                value={unit}
                onChange={(e) => setUnit(e.target.value as UnitType)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 font-semibold bg-white text-slate-800"
              >
                <option value="KG">KG (Kilogram - Selling in Grams)</option>
                <option value="GM">GM (Gram)</option>
                <option value="LTR">LTR (Litre - Selling in ML)</option>
                <option value="ML">ML (Millilitre)</option>
                <option value="PKT">PKT (Packet)</option>
                <option value="PCS">PCS (Pieces)</option>
                <option value="JAR">JAR (Jar)</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Initial Stock
              </label>
              <input
                type="number"
                step="0.5"
                min="0"
                placeholder="e.g. 50"
                value={stock}
                onChange={(e) => setStock(e.target.value === '' ? '' : parseFloat(e.target.value))}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono-code font-bold placeholder:text-slate-400 placeholder:font-normal"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Min Alert Level
              </label>
              <input
                type="number"
                step="1"
                min="1"
                placeholder="e.g. 15"
                value={minStockLevel}
                onChange={(e) => setMinStockLevel(e.target.value === '' ? '' : parseFloat(e.target.value))}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono-code placeholder:text-slate-400 placeholder:font-normal"
              />
            </div>
          </div>

          {/* Selling Price & Cost Price */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Selling Price (₹) *
              </label>
              <input
                type="number"
                step="0.5"
                min="0"
                placeholder="e.g. 100"
                value={sellingPrice}
                onChange={(e) => setSellingPrice(e.target.value === '' ? '' : parseFloat(e.target.value))}
                className="w-full px-3.5 py-2 text-xs sm:text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono-code font-bold text-emerald-800 placeholder:text-slate-400 placeholder:font-normal"
                required
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Cost Price (₹)
              </label>
              <input
                type="number"
                step="0.5"
                min="0"
                placeholder="e.g. 84"
                value={costPrice}
                onChange={(e) => setCostPrice(e.target.value === '' ? '' : parseFloat(e.target.value))}
                className="w-full px-3.5 py-2 text-xs sm:text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono-code text-slate-700 placeholder:text-slate-400 placeholder:font-normal"
              />
            </div>
          </div>

          {/* Optional Batch & Expiry */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <div>
              <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                Batch Number (Optional)
              </label>
              <input
                type="text"
                placeholder="e.g. B-2026-598"
                value={batchNo}
                onChange={(e) => setBatchNo(e.target.value)}
                className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono-code text-slate-600 placeholder:text-slate-400"
              />
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                Expiry Date (Optional)
              </label>
              <input
                type="date"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-600"
              />
            </div>
          </div>
        </form>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between flex-shrink-0">
          <div>
            {isConflictingDuplicate && (
              <span className="text-xs font-bold text-rose-600 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>Fix conflicting barcode before saving</span>
              </span>
            )}
          </div>
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-800 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSubmit}
              disabled={isConflictingDuplicate || !name.trim() || sellingPrice === '' || Number(sellingPrice) <= 0}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow transition-all"
            >
              {isEditing ? (
                <>
                  <Save className="w-4 h-4" />
                  <span>Update Product Details</span>
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4" />
                  <span>Save Product</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
