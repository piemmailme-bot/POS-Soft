import React, { useState } from 'react';
import {
  Package,
  AlertTriangle,
  Search,
  Plus,
  QrCode,
  Edit2,
  TrendingUp,
  Boxes,
  CheckCircle,
  Filter,
  Barcode,
  Sparkles
} from 'lucide-react';
import { Product, SocietyProfile } from '../types';
import { CATEGORIES } from '../data/initialData';
import { ProductFormModal } from './ProductFormModal';
import { getProductImage, getDefaultCategoryImage } from '../utils/productImages';

interface InventoryManagerProps {
  products: Product[];
  onUpdateProduct: (product: Product) => void;
  onAddProduct: (product: Omit<Product, 'id'>) => void;
  onOpenProductQr: (product: Product) => void;
  onOpenBarcodePrint: (product?: Product | null) => void;
  society: SocietyProfile;
  categories?: string[];
  onAddCategory?: (category: string) => void;
  onRenameCategory?: (oldCategory: string, newCategory: string) => void;
}

export const InventoryManager: React.FC<InventoryManagerProps> = ({
  products,
  onUpdateProduct,
  onAddProduct,
  onOpenProductQr,
  onOpenBarcodePrint,
  society,
  categories = CATEGORIES.filter((c) => c !== 'All Items'),
  onAddCategory,
  onRenameCategory,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All Items');
  const [stockFilter, setStockFilter] = useState<'all' | 'low' | 'out'>('all');
  
  // Product Form Modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Filter products
  const filteredProducts = products.filter((p) => {
    const matchesCat = selectedCategory === 'All Items' || p.category === selectedCategory;
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      p.name.toLowerCase().includes(q) ||
      p.barcode.includes(q) ||
      p.id.toString() === q;

    let matchesStock = true;
    if (stockFilter === 'low') {
      matchesStock = p.stock <= p.minStockLevel && p.stock > 0;
    } else if (stockFilter === 'out') {
      matchesStock = p.stock <= 0;
    }

    return matchesCat && matchesSearch && matchesStock;
  });

  // Inventory stats
  const totalItems = products.length;
  const totalValuation = products.reduce((acc, p) => acc + p.stock * p.costPrice, 0);
  const totalRetailValuation = products.reduce((acc, p) => acc + p.stock * p.sellingPrice, 0);
  const lowStockCount = products.filter((p) => p.stock <= p.minStockLevel && p.stock > 0).length;
  const outOfStockCount = products.filter((p) => p.stock <= 0).length;

  // Quick adjust stock
  const handleQuickAdjust = (product: Product, delta: number) => {
    const updated = {
      ...product,
      stock: Math.max(0, product.stock + delta),
    };
    onUpdateProduct(updated);
  };

  // Open modal for new product
  const handleOpenAddModal = () => {
    setEditingProduct(null);
    setIsModalOpen(true);
  };

  // Open modal for editing existing product
  const handleOpenEditModal = (product: Product) => {
    setEditingProduct(product);
    setIsModalOpen(true);
  };

  // Unified save handler from ProductFormModal
  const handleSaveProduct = (productData: Omit<Product, 'id'>, existingId?: number) => {
    if (existingId !== undefined) {
      // Editing existing
      const updated: Product = {
        ...productData,
        id: existingId,
      };
      onUpdateProduct(updated);
    } else {
      // Adding new
      onAddProduct(productData);
    }
  };

  // Get active categories list including any custom ones present in catalog
  const allActiveCategories = Array.from(
    new Set([...categories, ...products.map((p) => p.category)])
  ).filter(Boolean);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Top Banner: Inventory overview cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Total Catalog SKUs
            </span>
            <div className="text-2xl font-extrabold text-slate-900 mt-1 font-mono-code">
              {totalItems}
            </div>
            <p className="text-xs text-slate-400 mt-0.5">Active Products</p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600">
            <Boxes className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Stock Retail Value
            </span>
            <div className="text-2xl font-extrabold text-emerald-700 mt-1 font-mono-code">
              ₹{totalRetailValuation.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Cost: ₹{totalValuation.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
            </p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600">
            <TrendingUp className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Low Stock Warnings
            </span>
            <div className="text-2xl font-extrabold text-amber-600 mt-1 font-mono-code">
              {lowStockCount}
            </div>
            <p className="text-xs text-slate-400 mt-0.5">At or below threshold</p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-amber-50 border border-amber-100 flex items-center justify-center text-amber-600">
            <AlertTriangle className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Out of Stock
            </span>
            <div className="text-2xl font-extrabold text-rose-600 mt-1 font-mono-code">
              {outOfStockCount}
            </div>
            <p className="text-xs text-slate-400 mt-0.5">Require immediate indent</p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-rose-50 border border-rose-100 flex items-center justify-center text-rose-600">
            <Package className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Main Stock Table Container */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        {/* Table toolbar */}
        <div className="p-4 sm:p-5 border-b border-slate-200 space-y-3">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <div>
              <h3 className="font-extrabold text-lg text-slate-900">
                Cooperative Society Inventory &amp; Stock Details
              </h3>
              <p className="text-xs text-slate-500">
                Real-time stock balance, photo thumbnail, unique barcode mapping, and shelf QR labels
              </p>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                onClick={() => onOpenBarcodePrint(null)}
                className="w-full sm:w-auto px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow transition-colors border border-slate-700"
                title="Print Barcode stickers with option to include/skip items"
              >
                <Barcode className="w-4 h-4 text-emerald-400" />
                <span>Print Barcodes / Stickers</span>
              </button>
              <button
                onClick={handleOpenAddModal}
                className="w-full sm:w-auto px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>Add New Product</span>
              </button>
            </div>
          </div>

          {/* Search, category filter and stock status filters */}
          <div className="flex flex-col md:flex-row items-center justify-between gap-3 pt-2">
            <div className="flex flex-col sm:flex-row items-center gap-2.5 w-full md:w-auto">
              <div className="relative w-full sm:w-72">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search SKU, name, or barcode..."
                  className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              {/* Category Dropdown */}
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full sm:w-auto px-3 py-2 text-xs font-semibold bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-700"
              >
                <option value="All Items">All Categories ({products.length})</option>
                {allActiveCategories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat} ({products.filter((p) => p.category === cat).length})
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-1">
              <span className="text-xs text-slate-400 flex items-center gap-1">
                <Filter className="w-3.5 h-3.5" />
                Stock:
              </span>
              <button
                onClick={() => setStockFilter('all')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                  stockFilter === 'all'
                    ? 'bg-slate-900 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                All ({products.length})
              </button>
              <button
                onClick={() => setStockFilter('low')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                  stockFilter === 'low'
                    ? 'bg-amber-600 text-white'
                    : 'bg-amber-50 text-amber-700 hover:bg-amber-100'
                }`}
              >
                Low Stock ({lowStockCount})
              </button>
              <button
                onClick={() => setStockFilter('out')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                  stockFilter === 'out'
                    ? 'bg-rose-600 text-white'
                    : 'bg-rose-50 text-rose-700 hover:bg-rose-100'
                }`}
              >
                Out of Stock ({outOfStockCount})
              </button>
            </div>
          </div>
        </div>

        {/* Detailed Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">Product Details</th>
                <th className="py-3 px-4">Barcode / SKU</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4 text-right">Selling Price</th>
                <th className="py-3 px-4 text-center">Available Stock</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-center">Quick Stock Adjust</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    <Package className="w-10 h-10 mx-auto mb-2 text-slate-300" />
                    <p className="font-semibold text-slate-600 text-sm">No products found</p>
                    <p className="text-xs text-slate-400 mt-1">
                      Try adjusting your search query, category filter, or add a new product.
                    </p>
                  </td>
                </tr>
              ) : (
                filteredProducts.map((p) => {
                  const inStock = p.stock > 0;
                  const isLow = p.stock <= p.minStockLevel && inStock;

                  return (
                    <tr key={p.id} className="hover:bg-slate-50/70 transition-colors">
                      {/* Name & Photo */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <div className="relative w-12 h-12 rounded-xl overflow-hidden bg-slate-100 border border-slate-200 flex-shrink-0">
                            <img
                              src={getProductImage(p)}
                              alt={p.name}
                              className="w-full h-full object-cover"
                              loading="lazy"
                              onError={(e) => {
                                (e.target as HTMLImageElement).src = getDefaultCategoryImage(p.category);
                              }}
                            />
                          </div>
                          <div>
                            <div className="font-bold text-slate-900 text-sm leading-tight">
                              {p.name}
                            </div>
                            <div className="text-[11px] text-slate-500 mt-0.5 font-mono-code">
                              Batch: {p.batchNo} {p.expiryDate ? `· Exp: ${p.expiryDate}` : ''}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Barcode */}
                      <td className="py-3 px-4">
                        <div className="font-mono-code font-bold text-slate-900">
                          {p.barcode}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono-code">SKU ID: {p.id}</div>
                      </td>

                      {/* Category */}
                      <td className="py-3 px-4">
                        <span className="inline-block px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 font-semibold text-[11px]">
                          {p.category}
                        </span>
                      </td>

                      {/* Price */}
                      <td className="py-3 px-4 text-right">
                        <div className="font-bold font-mono-code text-slate-900 text-sm">
                          ₹{p.sellingPrice.toFixed(2)}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono-code">
                          Cost: ₹{p.costPrice.toFixed(2)} / {p.unit}
                        </div>
                      </td>

                      {/* Stock available */}
                      <td className="py-3 px-4 text-center">
                        <div className="font-extrabold text-sm font-mono-code text-slate-900">
                          {p.stock.toFixed(1)} {p.unit}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono-code">Min: {p.minStockLevel} {p.unit}</div>
                      </td>

                      {/* Status */}
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`inline-block px-2.5 py-1 rounded-full text-[10px] font-bold font-mono-code ${
                            !inStock
                              ? 'bg-rose-100 text-rose-800'
                              : isLow
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {!inStock ? 'OUT OF STOCK' : isLow ? 'LOW STOCK' : 'IN STOCK'}
                        </span>
                      </td>

                      {/* Quick Adjust buttons */}
                      <td className="py-3 px-4 text-center">
                        <div className="inline-flex items-center gap-1">
                          <button
                            onClick={() => handleQuickAdjust(p, -1)}
                            disabled={p.stock <= 0}
                            className="px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs disabled:opacity-30"
                            title="Reduce 1 unit"
                          >
                            -1
                          </button>
                          <button
                            onClick={() => handleQuickAdjust(p, 5)}
                            className="px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs"
                            title="Add 5 units"
                          >
                            +5
                          </button>
                          <button
                            onClick={() => handleQuickAdjust(p, 20)}
                            className="px-2 py-1 rounded bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold text-xs"
                            title="Restock 20 units"
                          >
                            +20
                          </button>
                        </div>
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right">
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            onClick={() => onOpenBarcodePrint(p)}
                            className="p-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg transition-colors"
                            title="Print Barcode &amp; QR Sticker"
                          >
                            <Barcode className="w-4 h-4 text-emerald-600" />
                          </button>
                          <button
                            onClick={() => onOpenProductQr(p)}
                            className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors"
                            title="View / Print QR Code Shelf Card"
                          >
                            <QrCode className="w-4 h-4 text-emerald-600" />
                          </button>
                          <button
                            onClick={() => handleOpenEditModal(p)}
                            className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors"
                            title="Edit details (image, barcode, category, prices)"
                          >
                            <Edit2 className="w-4 h-4 text-slate-600" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Comprehensive Product Form Modal (Handles Add and Edit with validation, category rename/add, 2MB image upload, and meaningful fallbacks) */}
      <ProductFormModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingProduct(null);
        }}
        productToEdit={editingProduct}
        existingProducts={products}
        categories={allActiveCategories}
        onSaveProduct={handleSaveProduct}
        onAddNewCategory={onAddCategory}
        onRenameCategory={onRenameCategory}
      />
    </div>
  );
};
