import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { Printer, Download, PlusCircle, CheckCircle2, X } from 'lucide-react';
import { CompleteInvoice, SocietyProfile } from '../types';
import { formatQuantityWithSubunit } from '../utils/looseBarcode';

interface ReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice: CompleteInvoice | null;
  society: SocietyProfile;
  onNewSale: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  isOpen,
  onClose,
  invoice,
  society,
  onNewSale,
}) => {
  const [digitalQrUrl, setDigitalQrUrl] = useState<string>('');

  useEffect(() => {
    if (invoice) {
      // Digital verification payload
      const payload = JSON.stringify({
        org: society.name,
        inv: invoice.invoiceNo,
        date: invoice.saleDate,
        total: invoice.grandTotal,
        mode: invoice.paymentMode,
      });

      QRCode.toDataURL(payload, { width: 140, margin: 1 })
        .then((url) => setDigitalQrUrl(url))
        .catch(() => {});
    }
  }, [invoice, society.name]);

  if (!isOpen || !invoice) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadTxt = () => {
    const lines = [
      '========================================',
      `       ${society.name.toUpperCase()}       `,
      `    ${society.address}    `,
      `Reg: ${society.regNo} | Tel: ${society.phone}`,
      '========================================',
      `Invoice No: ${invoice.invoiceNo}`,
      `Date: ${invoice.saleDate}`,
      `Cashier: ${invoice.cashier}`,
      `Customer: ${invoice.customerName}`,
      `Payment: ${invoice.paymentMode}`,
      invoice.upiTxnRef ? `UPI Ref: ${invoice.upiTxnRef}` : '',
      '----------------------------------------',
      'ITEM                       QTY    TOTAL',
      '----------------------------------------',
      ...invoice.items.map(
        (it) =>
          `${it.productName.padEnd(25).slice(0, 25)} ${it.quantity} ${it.unitType.padEnd(4)} ₹${it.lineTotal.toFixed(2)}`
      ),
      '----------------------------------------',
      `Subtotal:                    ₹${invoice.subtotal.toFixed(2)}`,
      invoice.discount > 0 ? `Discount:                   -₹${invoice.discount.toFixed(2)}` : '',
      `GRAND TOTAL:                 ₹${invoice.grandTotal.toFixed(2)}`,
      invoice.paymentMode === 'CASH' && invoice.tenderedCash
        ? `Cash Tendered:               ₹${invoice.tenderedCash.toFixed(2)}\nChange Returned:             ₹${(invoice.changeDue || 0).toFixed(2)}`
        : '',
      '========================================',
      '   THANK YOU FOR SUPPORTING COOPERATIVE  ',
      '      VISIT AGAIN · KOLKATA 700028      ',
      '========================================',
    ]
      .filter(Boolean)
      .join('\n');

    const blob = new Blob([lines], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Invoice_${invoice.invoiceNo}.txt`;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="px-5 py-3.5 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-sm">Sale Completed · Invoice Ready</h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Thermal Receipt Paper Container */}
        <div className="p-4 overflow-y-auto bg-slate-100 flex-1">
          <div
            id="printable-receipt"
            className="bg-white p-5 rounded-xl border border-slate-300 shadow-sm font-mono-code text-xs text-slate-900 mx-auto max-w-sm"
          >
            {/* Header */}
            <div className="text-center pb-3 border-b border-dashed border-slate-400">
              <h2 className="font-extrabold text-sm uppercase tracking-wider">{society.name}</h2>
              <p className="text-[11px] text-slate-700 mt-0.5">{society.address}</p>
              <p className="text-[10px] text-slate-500">Reg: {society.regNo}</p>
              <p className="text-[10px] text-slate-500">Ph: {society.phone}</p>
              <div className="mt-1 text-[11px] font-bold text-emerald-800 bg-emerald-50 py-0.5 rounded">
                RETAIL CASH / UPI MEMO
              </div>
            </div>

            {/* Bill Info */}
            <div className="py-2.5 border-b border-dashed border-slate-400 text-[11px] space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-600">Invoice:</span>
                <span className="font-bold">{invoice.invoiceNo}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Date/Time:</span>
                <span>{invoice.saleDate}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Customer:</span>
                <span className="font-bold truncate max-w-[190px]">{invoice.customerName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Payment:</span>
                <span className="font-bold text-emerald-700">
                  {invoice.paymentMode === 'UPI' ? 'ONLINE QR (7602496460@ikwik)' : 'I CASH'}
                </span>
              </div>
              {invoice.upiTxnRef && (
                <div className="flex justify-between">
                  <span className="text-slate-600">UPI Ref:</span>
                  <span className="text-[10px]">{invoice.upiTxnRef}</span>
                </div>
              )}
            </div>

            {/* Items Table */}
            <div className="py-2.5 border-b border-dashed border-slate-400">
              <table className="w-full text-[11px]">
                <thead>
                  <tr className="border-b border-slate-300 text-slate-500 text-left">
                    <th className="pb-1 font-semibold">Item</th>
                    <th className="pb-1 text-center font-semibold">Qty</th>
                    <th className="pb-1 text-right font-semibold">Rate</th>
                    <th className="pb-1 text-right font-semibold">Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {invoice.items.map((item, idx) => (
                    <tr key={idx} className="py-1">
                      <td className="py-1 pr-1 font-medium leading-tight">
                        <div>{item.productName}</div>
                        <div className="text-[9px] text-slate-400 font-normal">{item.barcode}</div>
                      </td>
                      <td className="py-1 text-center whitespace-nowrap font-bold text-slate-800">
                        {formatQuantityWithSubunit(item.quantity, item.unitType)}
                      </td>
                      <td className="py-1 text-right">₹{item.sellingPrice.toFixed(0)}</td>
                      <td className="py-1 text-right font-bold">₹{item.lineTotal.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Totals */}
            <div className="py-2.5 border-b border-dashed border-slate-400 space-y-1 text-[11px]">
              <div className="flex justify-between">
                <span className="text-slate-600">Subtotal:</span>
                <span>₹{invoice.subtotal.toFixed(2)}</span>
              </div>
              {invoice.discount > 0 && (
                <div className="flex justify-between text-emerald-700">
                  <span>Co-op Member Rebate:</span>
                  <span>-₹{invoice.discount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between font-extrabold text-sm pt-1 border-t border-slate-200">
                <span>NET PAYABLE:</span>
                <span className="text-emerald-800">₹{invoice.grandTotal.toFixed(2)}</span>
              </div>

              {invoice.paymentMode === 'CASH' && invoice.tenderedCash && (
                <div className="pt-1.5 border-t border-slate-200 text-[10px] text-slate-600 space-y-0.5">
                  <div className="flex justify-between">
                    <span>Cash Tendered:</span>
                    <span>₹{invoice.tenderedCash.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between font-bold text-slate-900">
                    <span>Change Returned:</span>
                    <span>₹{(invoice.changeDue || 0).toFixed(2)}</span>
                  </div>
                </div>
              )}
            </div>

            {/* Footer with verification QR */}
            <div className="pt-3 text-center flex flex-col items-center">
              {digitalQrUrl && (
                <img
                  src={digitalQrUrl}
                  alt="Invoice QR"
                  className="w-20 h-20 border border-slate-300 p-1 rounded"
                />
              )}
              <p className="text-[10px] text-slate-500 mt-1">Scan for digital e-invoice</p>
              <p className="text-[10px] font-bold text-slate-700 mt-2">
                Thank you for patronizing Nabkul Cooperative Society!
              </p>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors shadow"
            >
              <Printer className="w-3.5 h-3.5 text-emerald-300" />
              <span>Print Receipt</span>
            </button>
            <button
              onClick={handleDownloadTxt}
              className="px-3 py-2 bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download</span>
            </button>
          </div>

          <button
            onClick={() => {
              onClose();
              onNewSale();
            }}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shadow"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>New Sale</span>
          </button>
        </div>
      </div>
    </div>
  );
};
