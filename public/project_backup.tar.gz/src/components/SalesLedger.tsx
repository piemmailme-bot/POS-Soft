import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Download,
  Search,
  Filter,
  CreditCard,
  Banknote,
  QrCode,
  Calendar,
  Eye,
  CheckCircle2,
  TrendingUp,
  Receipt
} from 'lucide-react';
import { SaleTransactionItem, PaymentMode, CompleteInvoice } from '../types';
import { exportLedgerToCsv } from '../utils/csvExporter';

interface SalesLedgerProps {
  ledger: SaleTransactionItem[];
  onViewInvoice: (invoice: CompleteInvoice) => void;
  societyName: string;
}

export const SalesLedger: React.FC<SalesLedgerProps> = ({
  ledger,
  onViewInvoice,
  societyName,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [modeFilter, setModeFilter] = useState<string>('ALL');

  // Filter items
  const filteredLedger = ledger.filter((row) => {
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      row.invoiceNo.toLowerCase().includes(q) ||
      row.customerName.toLowerCase().includes(q) ||
      row.productName.toLowerCase().includes(q) ||
      row.barcode.includes(q);

    const matchesMode = modeFilter === 'ALL' || row.paymentMode === modeFilter;
    return matchesSearch && matchesMode;
  });

  // Calculate metrics
  const totalTurnover = ledger.reduce((sum, item) => sum + item.lineTotal, 0);
  const upiTotal = ledger
    .filter((i) => i.paymentMode === 'UPI')
    .reduce((sum, item) => sum + item.lineTotal, 0);
  const cashTotal = ledger
    .filter((i) => i.paymentMode === 'CASH')
    .reduce((sum, item) => sum + item.lineTotal, 0);

  const handleExport = () => {
    exportLedgerToCsv(ledger, societyName);
  };

  // Group ledger items into an invoice when viewing
  const handleInspectInvoice = (invoiceNo: string) => {
    const matchingRows = ledger.filter((r) => r.invoiceNo === invoiceNo);
    if (matchingRows.length === 0) return;

    const first = matchingRows[0];
    const total = matchingRows.reduce((sum, r) => sum + r.lineTotal, 0);

    const inv: CompleteInvoice = {
      saleId: first.saleId,
      invoiceNo: first.invoiceNo,
      saleDate: first.saleDate,
      customerName: first.customerName,
      paymentMode: first.paymentMode,
      items: matchingRows.map((r) => ({
        productId: r.productId,
        productName: r.productName,
        barcode: r.barcode,
        quantity: r.quantity,
        unitType: r.unitType,
        sellingPrice: r.sellingPrice,
        lineTotal: r.lineTotal,
      })),
      subtotal: total,
      discount: 0,
      grandTotal: total,
      cashier: 'Subrata Roy (Staff #402)',
      tenderedCash: first.paymentMode === 'CASH' ? total : undefined,
      changeDue: 0,
    };

    onViewInvoice(inv);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Top Banner with Financial Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Total Ledger Turnover
          </span>
          <div className="text-2xl font-extrabold text-slate-900 mt-1 font-mono-code">
            ₹{totalTurnover.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
          </div>
          <p className="text-xs text-slate-400 mt-0.5">{ledger.length} line items recorded</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
            <QrCode className="w-3.5 h-3.5 text-emerald-600" />
            Online QR / UPI Collections
          </span>
          <div className="text-2xl font-extrabold text-emerald-700 mt-1 font-mono-code">
            ₹{upiTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
          </div>
          <p className="text-xs text-slate-400 mt-0.5">Direct bank credit</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
            <Banknote className="w-3.5 h-3.5 text-amber-600" />
            Cash In Hand (I Cash)
          </span>
          <div className="text-2xl font-extrabold text-amber-700 mt-1 font-mono-code">
            ₹{cashTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
          </div>
          <p className="text-xs text-slate-400 mt-0.5">Cash register counter</p>
        </div>

      </div>

      {/* Main Table Card */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        {/* Table Header & Controls */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex flex-col md:flex-row items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5 text-emerald-600" />
              <h3 className="font-extrabold text-lg text-slate-900">
                Sales Transaction Ledger (Stock Output)
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Exact schema mapping from attached database{' '}
              <span className="font-mono-code text-slate-700 font-semibold">
                Cooperative_Society_Database_Schema_7854aedc.csv
              </span>
            </p>
          </div>

          <div className="flex items-center gap-2 w-full md:w-auto">
            <button
              onClick={handleExport}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow transition-colors flex-1 md:flex-initial justify-center"
            >
              <Download className="w-4 h-4" />
              <span>Export CSV Database</span>
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search invoice no, member, item name, barcode..."
              className="w-full pl-9 pr-4 py-2 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
            />
          </div>

          <div className="flex items-center gap-1.5 w-full sm:w-auto overflow-x-auto pb-1">
            <span className="text-xs text-slate-500 mr-1 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" />
              Mode:
            </span>
            {['ALL', 'UPI', 'CASH'].map((m) => (
              <button
                key={m}
                onClick={() => setModeFilter(m)}
                className={`px-3 py-1 rounded-lg text-xs font-semibold ${
                  modeFilter === m
                    ? 'bg-slate-900 text-white'
                    : 'bg-white text-slate-600 hover:bg-slate-200 border border-slate-200'
                }`}
              >
                {m === 'ALL' ? 'All Transactions' : m}
              </button>
            ))}
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono-code">
            <thead className="bg-slate-100/80 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider font-sans">
              <tr>
                <th className="py-3 px-3">Item ID</th>
                <th className="py-3 px-3">Invoice No</th>
                <th className="py-3 px-3">Date / Time</th>
                <th className="py-3 px-3">Member / Customer</th>
                <th className="py-3 px-3 text-center">Mode</th>
                <th className="py-3 px-3">Product Name</th>
                <th className="py-3 px-3">Barcode</th>
                <th className="py-3 px-3 text-right">Qty</th>
                <th className="py-3 px-3 text-right">Price</th>
                <th className="py-3 px-3 text-right">Line Total</th>
                <th className="py-3 px-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredLedger.map((row) => (
                <tr key={row.saleItemId} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-2.5 px-3 text-slate-500">{row.saleItemId}</td>
                  <td className="py-2.5 px-3 font-bold text-slate-900">{row.invoiceNo}</td>
                  <td className="py-2.5 px-3 text-slate-500 whitespace-nowrap">{row.saleDate}</td>
                  <td className="py-2.5 px-3 font-sans font-medium text-slate-800 max-w-[180px] truncate">
                    {row.customerName}
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <span
                      className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                        row.paymentMode === 'UPI'
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          : 'bg-amber-100 text-amber-800 border border-amber-300'
                      }`}
                    >
                      {row.paymentMode}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 font-sans font-semibold text-slate-900 max-w-[180px] truncate">
                    {row.productName}
                  </td>
                  <td className="py-2.5 px-3 text-slate-500">{row.barcode}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-slate-700">
                    {row.quantity.toFixed(3)} {row.unitType}
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-600">
                    ₹{row.sellingPrice.toFixed(2)}
                  </td>
                  <td className="py-2.5 px-3 text-right font-extrabold text-emerald-800">
                    ₹{row.lineTotal.toFixed(2)}
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <button
                      onClick={() => handleInspectInvoice(row.invoiceNo)}
                      className="p-1 rounded hover:bg-slate-200 text-slate-600 hover:text-slate-900"
                      title="View Invoice"
                    >
                      <Receipt className="w-3.5 h-3.5 text-emerald-600" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredLedger.length === 0 && (
          <div className="p-8 text-center text-slate-400 text-xs">
            No transactions match the current filter.
          </div>
        )}
      </div>
    </div>
  );
};
