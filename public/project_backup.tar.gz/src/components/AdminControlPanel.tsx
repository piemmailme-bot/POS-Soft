import React, { useState } from 'react';
import {
  ShieldAlert,
  UserPlus,
  Trash2,
  Lock,
  PauseCircle,
  PlayCircle,
  CheckCircle2,
  AlertTriangle,
  Users,
  Settings,
  History,
  Store,
  KeyRound,
  Eye,
  EyeOff,
  Building2,
  Sliders,
  X,
  CreditCard,
  Banknote,
  QrCode,
  Megaphone
} from 'lucide-react';
import { CashierUser, AdminStoreSettings, AdminAuditLog, SocietyProfile } from '../types';

interface AdminControlPanelProps {
  cashiers: CashierUser[];
  currentCashier: CashierUser;
  adminSettings: AdminStoreSettings;
  auditLogs: AdminAuditLog[];
  onAddCashier: (newCashier: Omit<CashierUser, 'id'>) => void;
  onRemoveCashier: (cashierId: string) => void;
  onToggleCashierStatus: (cashierId: string) => void;
  onResetPassword: (cashierId: string, newPass: string) => void;
  onUpdateAdminSettings: (newSettings: AdminStoreSettings) => void;
  society: SocietyProfile;
  onExitAdminToPos: () => void;
}

export const AdminControlPanel: React.FC<AdminControlPanelProps> = ({
  cashiers,
  currentCashier,
  adminSettings,
  auditLogs,
  onAddCashier,
  onRemoveCashier,
  onToggleCashierStatus,
  onResetPassword,
  onUpdateAdminSettings,
  society,
  onExitAdminToPos,
}) => {
  const [activeTab, setActiveTab] = useState<'cashiers' | 'controls' | 'audit'>('cashiers');
  const [isAddCashierModalOpen, setIsAddCashierModalOpen] = useState(false);
  const [resetPassUser, setResetPassUser] = useState<CashierUser | null>(null);
  const [newPasswordVal, setNewPasswordVal] = useState('');
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  // New Cashier Form
  const [newCashier, setNewCashier] = useState({
    loginId: '',
    passwordHash: 'nabkul@123',
    name: '',
    staffCode: `Staff #${400 + cashiers.length + 1}`,
    role: 'POS Cashier' as CashierUser['role'],
    assignedCounter: 'COUNTER-01 (KOL-NORTH)',
  });

  const showToast = (msg: string) => {
    setFeedbackMsg(msg);
    setTimeout(() => setFeedbackMsg(null), 3500);
  };

  const handleCreateCashier = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    if (!newCashier.name || !newCashier.loginId || !newCashier.passwordHash) return;

    // Check duplicate login ID
    if (cashiers.some((c) => c.loginId.toLowerCase() === newCashier.loginId.trim().toLowerCase())) {
      setFormError(`Login ID "${newCashier.loginId}" is already taken by another staff member.`);
      return;
    }

    onAddCashier({
      ...newCashier,
      isActive: true,
      createdAt: new Date().toISOString().slice(0, 10),
    });

    setIsAddCashierModalOpen(false);
    setFormError(null);
    showToast(`Staff member "${newCashier.name}" registered successfully.`);
    setNewCashier({
      loginId: '',
      passwordHash: 'nabkul@123',
      name: '',
      staffCode: `Staff #${400 + cashiers.length + 2}`,
      role: 'POS Cashier',
      assignedCounter: 'COUNTER-01 (KOL-NORTH)',
    });
  };

  const handleToggleTransactions = () => {
    const willEnable = !adminSettings.transactionsEnabled;
    const haltReason = willEnable ? '' : 'Emergency billing freeze ordered by Society Administrator.';
    onUpdateAdminSettings({
      ...adminSettings,
      transactionsEnabled: willEnable,
      haltReason,
    });
    showToast(
      willEnable
        ? '✅ POS Billing & Store Transactions RESUMED.'
        : '⚠️ EMERGENCY: Store transactions have been STOPPED.'
    );
  };

  const handleResetPasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetPassUser || !newPasswordVal) return;
    onResetPassword(resetPassUser.id, newPasswordVal);
    showToast(`Password updated for ${resetPassUser.name}`);
    setResetPassUser(null);
    setNewPasswordVal('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 shadow-xl border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-600 to-rose-600 border border-amber-400/30 flex items-center justify-center text-white shadow-lg flex-shrink-0">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black tracking-tight">Admin & Security Management</h2>
              <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono-code text-[11px] font-bold border border-amber-500/30">
                Secretary Office
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              {society.name} · Staff authorization, transaction controls & security audit
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto">
          {/* Master Transaction Halt Alert Button */}
          <button
            onClick={handleToggleTransactions}
            className={`px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 shadow-lg transition-all ${
              adminSettings.transactionsEnabled
                ? 'bg-rose-600 hover:bg-rose-500 text-white'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white animate-pulse'
            }`}
          >
            {adminSettings.transactionsEnabled ? (
              <>
                <PauseCircle className="w-4 h-4" />
                <span>STOP ALL TRANSACTIONS</span>
              </>
            ) : (
              <>
                <PlayCircle className="w-4 h-4" />
                <span>RESUME STORE TRANSACTIONS</span>
              </>
            )}
          </button>

          <button
            onClick={onExitAdminToPos}
            className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-xl text-xs font-bold transition-colors border border-slate-700"
          >
            Back to POS Billing
          </button>
        </div>
      </div>

      {feedbackMsg && (
        <div className="p-3 bg-slate-900 border border-slate-700 text-emerald-400 rounded-xl text-xs font-semibold flex items-center gap-2 shadow-lg animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          <span>{feedbackMsg}</span>
        </div>
      )}

      {/* Emergency Halt Banner if transactions are stopped */}
      {!adminSettings.transactionsEnabled && (
        <div className="p-4 bg-rose-50 border-2 border-rose-500 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-rose-900 animate-fadeIn shadow-md">
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-6 h-6 text-rose-600 flex-shrink-0" />
            <div>
              <h4 className="font-bold text-sm">Store Transactions Are Currently STOPPED</h4>
              <p className="text-xs text-rose-700 mt-0.5">
                {adminSettings.haltReason || 'Cashiers are blocked from accepting new payments until resumed by Administrator.'}
              </p>
            </div>
          </div>
          <button
            onClick={handleToggleTransactions}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow"
          >
            Resume Transactions Now
          </button>
        </div>
      )}

      {/* Admin Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('cashiers')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'cashiers'
              ? 'bg-slate-900 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-200'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Cashier Staff Management ({cashiers.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('controls')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'controls'
              ? 'bg-slate-900 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-200'
          }`}
        >
          <Sliders className="w-4 h-4" />
          <span>Transaction Controls & Policies</span>
        </button>

        <button
          onClick={() => setActiveTab('audit')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'audit'
              ? 'bg-slate-900 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-200'
          }`}
        >
          <History className="w-4 h-4" />
          <span>Security & Activity Audit Logs</span>
        </button>
      </div>

      {/* Tab 1: Cashier Management */}
      {activeTab === 'cashiers' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden space-y-4 p-5">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <h3 className="font-extrabold text-base text-slate-900">
                Authorized Cashier Roster
              </h3>
              <p className="text-xs text-slate-500">
                Register new billing staff, reset passwords, or remove cashiers from the cooperative store
              </p>
            </div>

            <button
              onClick={() => setIsAddCashierModalOpen(true)}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow"
            >
              <UserPlus className="w-4 h-4" />
              <span>Register New Cashier</span>
            </button>
          </div>

          {/* Cashiers Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">Staff Member</th>
                  <th className="py-3 px-4">Login ID</th>
                  <th className="py-3 px-4">Role</th>
                  <th className="py-3 px-4">Assigned Counter</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Security Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {cashiers.map((cashier) => {
                  const isAdmin = cashier.role === 'System Admin';

                  return (
                    <tr key={cashier.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900 text-sm leading-tight">
                          {cashier.name}
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono-code mt-0.5">
                          {cashier.staffCode} · Created {cashier.createdAt || '2026-10-26'}
                        </div>
                      </td>

                      <td className="py-3 px-4 font-mono-code font-bold text-slate-800">
                        {cashier.loginId}
                      </td>

                      <td className="py-3 px-4">
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                            isAdmin
                              ? 'bg-purple-100 text-purple-800 border border-purple-300'
                              : cashier.role === 'Senior Cashier'
                              ? 'bg-blue-100 text-blue-800 border border-blue-300'
                              : 'bg-slate-100 text-slate-800'
                          }`}
                        >
                          {cashier.role}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-slate-600 font-medium">
                        {cashier.assignedCounter}
                      </td>

                      <td className="py-3 px-4 text-center">
                        <span
                          className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            cashier.isActive !== false
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {cashier.isActive !== false ? 'ACTIVE' : 'DEACTIVATED'}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-right">
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => {
                              setResetPassUser(cashier);
                              setNewPasswordVal('');
                            }}
                            className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-semibold transition-colors flex items-center gap-1"
                            title="Reset Password"
                          >
                            <KeyRound className="w-3 h-3 text-slate-500" />
                            <span>Reset PIN</span>
                          </button>

                          {!isAdmin && (
                            <>
                              <button
                                type="button"
                                onClick={() => onToggleCashierStatus(cashier.id)}
                                className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-semibold transition-colors"
                              >
                                {cashier.isActive !== false ? 'Deactivate' : 'Activate'}
                              </button>

                              <button
                                type="button"
                                onClick={() => {
                                  if (
                                    confirm(
                                      `Are you sure you want to permanently remove cashier "${cashier.name}"?`
                                    )
                                  ) {
                                    onRemoveCashier(cashier.id);
                                    showToast(`Cashier "${cashier.name}" removed.`);
                                  }
                                }}
                                className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                                title="Remove Cashier"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 2: Transaction & Store Controls */}
      {activeTab === 'controls' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Transaction Halt Controls */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
              <ShieldAlert className="w-5 h-5 text-rose-600" />
              <h3 className="font-extrabold text-base text-slate-900">
                Emergency Transaction Freeze
              </h3>
            </div>

            <p className="text-xs text-slate-500">
              Instantly disable or enable all sales across the entire cooperative society retail terminal.
            </p>

            <div className="p-4 rounded-xl border bg-slate-50 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-slate-800 block">
                  Master Store Transaction Switch
                </span>
                <span className="text-[11px] text-slate-500">
                  {adminSettings.transactionsEnabled
                    ? 'Store is currently accepting transactions'
                    : 'TRANSACTIONS ARE CURRENTLY FROZEN'}
                </span>
              </div>

              <button
                type="button"
                onClick={handleToggleTransactions}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  adminSettings.transactionsEnabled
                    ? 'bg-emerald-600 text-white'
                    : 'bg-rose-600 text-white'
                }`}
              >
                {adminSettings.transactionsEnabled ? 'Active (Enabled)' : 'STOPPED (Frozen)'}
              </button>
            </div>

            {/* Halt Reason input */}
            <div className="pb-4">
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Freeze Reason / Cashier Notice
              </label>
              <input
                type="text"
                placeholder="e.g. Physical inventory counting in progress..."
                value={adminSettings.haltReason || ''}
                onChange={(e) =>
                  onUpdateAdminSettings({
                    ...adminSettings,
                    haltReason: e.target.value,
                  })
                }
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

          </div>

          {/* Payment Mode Toggles */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
              <CreditCard className="w-5 h-5 text-emerald-600" />
              <h3 className="font-extrabold text-base text-slate-900">
                Payment Channel Policies
              </h3>
            </div>

            <div className="space-y-3">
              {/* Online QR / UPI Toggle */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <QrCode className="w-4 h-4 text-purple-600" />
                  <div>
                    <span className="text-xs font-bold text-slate-800 block">
                      PhonePe & Online UPI (7602496460@ikwik)
                    </span>
                    <span className="text-[10px] text-slate-500">
                      Enable or pause QR scan payments
                    </span>
                  </div>
                </div>

                <input
                  type="checkbox"
                  checked={adminSettings.upiPaymentsEnabled}
                  onChange={(e) =>
                    onUpdateAdminSettings({
                      ...adminSettings,
                      upiPaymentsEnabled: e.target.checked,
                    })
                  }
                  className="w-5 h-5 accent-emerald-600 rounded cursor-pointer"
                />
              </div>

              {/* Cash Toggle */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Banknote className="w-4 h-4 text-amber-600" />
                  <div>
                    <span className="text-xs font-bold text-slate-800 block">
                      I Cash (Physical Cash Payments)
                    </span>
                    <span className="text-[10px] text-slate-500">
                      Allow tender in currency notes
                    </span>
                  </div>
                </div>

                <input
                  type="checkbox"
                  checked={adminSettings.cashPaymentsEnabled}
                  onChange={(e) =>
                    onUpdateAdminSettings({
                      ...adminSettings,
                      cashPaymentsEnabled: e.target.checked,
                    })
                  }
                  className="w-5 h-5 accent-emerald-600 rounded cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Security & Activity Audit Logs */}
      {activeTab === 'audit' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div>
              <h3 className="font-extrabold text-base text-slate-900">
                System Security & Admin Audit Log
              </h3>
              <p className="text-xs text-slate-500">
                Immutable trace of staff registrations, password changes, and transaction halts
              </p>
            </div>
            <span className="text-xs font-mono-code text-slate-500">
              {auditLogs.length} events logged
            </span>
          </div>

          <div className="space-y-2">
            {auditLogs.map((log) => (
              <div
                key={log.id}
                className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
              >
                <div className="flex items-start gap-2.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 mt-1.5 flex-shrink-0"></span>
                  <div>
                    <div className="font-bold text-slate-900 font-mono-code">{log.action}</div>
                    <div className="text-slate-600 mt-0.5">{log.details}</div>
                  </div>
                </div>

                <div className="text-right text-[11px] text-slate-400 font-mono-code flex-shrink-0">
                  <div>By: {log.performedBy}</div>
                  <div>{log.timestamp}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modal: Register New Cashier */}
      {isAddCashierModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="font-bold text-sm">Register New Cashier Staff</h3>
              <button
                onClick={() => setIsAddCashierModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateCashier} className="p-6 space-y-3.5 text-xs">
              {formError && (
                <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 rounded-lg font-semibold flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-600 flex-shrink-0" />
                  <span>{formError}</span>
                </div>
              )}
              <div>
                <label className="font-bold text-slate-700 block mb-1">Full Name *</label>
                <input
                  type="text"
                  placeholder="e.g. Debabrata Roy"
                  value={newCashier.name}
                  onChange={(e) => setNewCashier({ ...newCashier, name: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-semibold focus:ring-2 focus:ring-emerald-500 outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Login Username *</label>
                  <input
                    type="text"
                    placeholder="e.g. debu406"
                    value={newCashier.loginId}
                    onChange={(e) => setNewCashier({ ...newCashier, loginId: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono-code focus:ring-2 focus:ring-emerald-500 outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Staff ID Code</label>
                  <input
                    type="text"
                    value={newCashier.staffCode}
                    onChange={(e) => setNewCashier({ ...newCashier, staffCode: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono-code focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Access Password / PIN *</label>
                <input
                  type="text"
                  value={newCashier.passwordHash}
                  onChange={(e) => setNewCashier({ ...newCashier, passwordHash: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono-code focus:ring-2 focus:ring-emerald-500 outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Role</label>
                  <select
                    value={newCashier.role}
                    onChange={(e) =>
                      setNewCashier({
                        ...newCashier,
                        role: e.target.value as CashierUser['role'],
                      })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none font-medium"
                  >
                    <option value="POS Cashier">POS Cashier</option>
                    <option value="Senior Cashier">Senior Cashier</option>
                    <option value="Society Manager">Society Manager</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Assigned Counter</label>
                  <select
                    value={newCashier.assignedCounter}
                    onChange={(e) =>
                      setNewCashier({ ...newCashier, assignedCounter: e.target.value })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none font-medium"
                  >
                    <option value="COUNTER-01 (KOL-NORTH)">COUNTER-01 (Main)</option>
                    <option value="COUNTER-02 (KOL-NORTH)">COUNTER-02 (Express)</option>
                    <option value="CENTRAL DESK">CENTRAL DESK</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsAddCashierModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:text-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg shadow"
                >
                  Save & Authorize
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Reset Password */}
      {resetPassUser && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full shadow-2xl border border-slate-200 overflow-hidden">
            <div className="px-5 py-3.5 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="font-bold text-sm">Reset Password for {resetPassUser.name}</h3>
              <button onClick={() => setResetPassUser(null)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleResetPasswordSubmit} className="p-5 space-y-3.5 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  New Password / PIN for {resetPassUser.loginId}
                </label>
                <input
                  type="text"
                  placeholder="Enter new password..."
                  value={newPasswordVal}
                  onChange={(e) => setNewPasswordVal(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono-code focus:ring-2 focus:ring-emerald-500 outline-none"
                  required
                  autoFocus
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setResetPassUser(null)}
                  className="px-3 py-1.5 text-slate-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg shadow"
                >
                  Update Password
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
