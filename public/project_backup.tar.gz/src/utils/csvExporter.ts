import { SaleTransactionItem } from '../types';

export function exportLedgerToCsv(ledger: SaleTransactionItem[], societyName = 'Nabkul Cooperative Society'): void {
  // Title row
  const titleRow = `Sales Transaction Ledger (Stock Output),,,,,,,,,,,,`;
  
  // Header row matching exact schema
  const headers = [
    'sale_item_id',
    'sale_id',
    'invoice_no',
    'sale_date',
    'member_no / Customer',
    'payment_mode',
    'product_id',
    'product_name',
    'barcode',
    'quantity',
    'unit_type',
    'selling_price',
    'line_total'
  ].join(',');

  // Data rows
  const rows = ledger.map(item => {
    return [
      item.saleItemId,
      item.saleId,
      `"${item.invoiceNo}"`,
      `"${item.saleDate}"`,
      `"${item.customerName}"`,
      item.paymentMode,
      item.productId,
      `"${item.productName.replace(/"/g, '""')}"`,
      `"${item.barcode}"`,
      item.quantity.toFixed(3),
      item.unitType,
      `₹${item.sellingPrice.toFixed(2)}`,
      `₹${item.lineTotal.toFixed(2)}`
    ].join(',');
  });

  const csvContent = [titleRow, headers, ...rows].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  const dateStr = new Date().toISOString().slice(0, 10);
  link.setAttribute('href', url);
  link.setAttribute('download', `${societyName.replace(/\s+/g, '_')}_Sales_Ledger_${dateStr}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
